# Hybrid-Hub2u
Javascript based application


* To clone the dev branch to your local machine:  
`git clone -b dev https://github.comcast.com/ERP-Finsys/Hybrid-Hub2u.git`

* After setting up the repo, edit **.bowerrc** file and change proxy settings.  
Open a command prompt/terminal in the directory and run:  
`npm install`  
`bower install`

* Once the node and bower components are installed, you can run the application by running:  
`grunt serve`
