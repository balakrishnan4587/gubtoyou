var auth0 = {
    client_id: "hub2u",

    auth_uris: {
        dev: "https://websec-dev.cable.comcast.com/as/authorization.oauth2",
        test: "https://websec-qa.cable.comcast.com/as/authorization.oauth2",
        uat: "https://websec-stg.cable.comcast.com/as/authorization.oauth2",
        production: "https://websec-oic.cable.comcast.com/as/authorization.oauth2"
    },

    revoke_uri: "https://sso-login-test.cable.comcast.com/unprotect/logout/logout.asp?target=",
    revoke_uri_production: "https://extsso.cable.comcast.com/unprotect/logout/logout.asp?target=",

    getLogoutUri: function() {
        if (config.mode === "production") {
            return this.revoke_uri_production;
        } else {
            return this.revoke_uri;
        }
    },

    redirect_uris: {
        local: "http%3A%2F%2Flocalhost%3A9000%2F",
        dev: "http%3A%2F%2Fcifasoa-dt-a1d.ula.comcast.net%3A7777%2Fhub2u%2F",
        test: "http%3A%2F%2Fcifasoa-dt-a1q.ula.comcast.net%3A7777%2Fhub2u%2F",
        cloud: 'https%3A%2F%2Fhub2u.u1.app.cloud.comcast.net%2F',
        uat: "https%3A%2F%2Fhub2u.g4.app.cloud.comcast.net%2F",

        production: {
            g1: "https%3A%2F%2Fhub2u.g1.app.cloud.comcast.net%2F",
            g2: "https%3A%2F%2Fhub2u.g2.app.cloud.comcast.net%2F",
            g3: "https%3A%2F%2Fhub2u.g3.app.cloud.comcast.net%2F",
            erpapps: "https%3A%2F%2Fhub2u.erpapps.comcast.com%2F",
        },

        mobile: {
            dev: {
                uri: "com.comcast.mdm.hub2-u%3A%2Fcallback",
                base: "com.comcast.mdm.hub2-u"
            },
            production: {
                uri: "com.comcast.mdm.hub2-u%3A%2Fcallback",
                base: "com.comcast.mdm.hub2-u"
            }
        }
    },


    getProductionRedirectUri: function() {
        if (location.href.indexOf("hub2u.g1.app.cloud.comcast.net") != -1) {
            return this.redirect_uris.production.g1;
        } else if (location.href.indexOf("hub2u.g2.app.cloud.comcast.net") != -1) {
            return this.redirect_uris.production.g2;
        } else if (location.href.indexOf("hub2u.g3.app.cloud.comcast.net") != -1) {
            return this.redirect_uris.production.g3;
        } else if (location.href.indexOf("hub2u.erpapps.comcast.com") != -1) {
            return this.redirect_uris.production.erpapps;
        }
    },

    getUriPair: function() {
        if (isPhoneGap()) {
            if (config.mode === "production") {
                return {
                    "auth_uri": auth0.auth_uris["production"],
                    "redirect_uri": auth0.redirect_uris.mobile.production.uri
                }
            } else {
                return {
                    "auth_uri": auth0.auth_uris["test"],
                    "redirect_uri": auth0.redirect_uris.mobile.dev.uri
                }
            }
        }

        var uriPair = {
            "auth_uri": auth0.auth_uris[config.mode],
            "redirect_uri": auth0.redirect_uris["dev"]
        }

        switch (config.mode) {
            case "local":
                uriPair.auth_uri = auth0.auth_uris["test"];
                uriPair.redirect_uri = auth0.redirect_uris["local"];
                break;
            case "dev":
            case "dev-https":
                uriPair.auth_uri = auth0.auth_uris["test"];
                uriPair.redirect_uri = auth0.redirect_uris["dev"];
                break;
            case "test":
                uriPair.auth_uri = auth0.auth_uris["test"];
                uriPair.redirect_uri = auth0.redirect_uris["test"];
                break;
            case "uat":
            case "uat-https":
                uriPair.auth_uri = auth0.auth_uris["uat"];
                uriPair.redirect_uri = auth0.redirect_uris["uat"];
                break;
            case "cloud":
                uriPair.auth_uri = auth0.auth_uris["test"];
                uriPair.redirect_uri = auth0.redirect_uris["cloud"];
                break;

            case "production":
                uriPair.auth_uri = auth0.auth_uris["production"];
                uriPair.redirect_uri = auth0.getProductionRedirectUri();
                break;
        }
        return uriPair;
    },

    isLoggedIn: function() {
        var status = sessionStorage.getItem("loggedIn");
        if (status == null || status === "false") {
            return false;
        } else {
            return true;
        }
    },

    logout: function() {
        var user = getUsername();
        var path = this.getLogoutUri() + this.getUriPair().redirect_uri + "#logout_success";
        this.deleteAllCookies();
        sessionStorage.clear();
        localStorage.clear();
        if (getUsername() != null) {
            localStorage.setItem("lastUsedBy", getUsername());
        }
        //auth0.is_logged = false;
        sessionStorage.setItem("loggedIn", false);

        if(isPhoneGap()){
            openSafariVC(path, false);
        }else{
            window.location.href = path;
        }
    },

    deleteAllCookies: function() {
        var cookies = document.cookie.split(";");

        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i];
            var eqPos = cookie.indexOf("=");
            var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
            document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
        }
    },

    getParameterByName: function(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    },

    parseJwt: function(token) {
        var base64Url = token.split('.')[1];
        var base64 = base64Url.replace('-', '+').replace('_', '/');
        return JSON.parse(window.atob(base64));
    },



    //** call this method for authorization_code
    authorize: function(useSafariVC) {
        var path = this.getUriPair().auth_uri;
        var adapterId = (isPhoneGap()) ? 'kerberos' : 'loginform';
        if(useSafariVC){
            adapterId = "loginform";
        }
        var queryParams = [
            'client_id=' + this.client_id,
            'redirect_uri=' + this.getUriPair().redirect_uri,
            'pfidpadapterid=' + adapterId,
            'scope=openid+profile',
            //'response_type=code'
            'response_type=token'
        ];
        var query = queryParams.join('&');
        var url = path + '?' + query;
        console.log(url);
        if (isPhoneGap()) {
            if(useSafariVC){
                openSafariVC(url, false);
                return;
            }
            openUrl(url, false);
        } else {
            window.location.replace(url);
        }
    },

    decodeToken: function(token) {
        var id = this.parseJwt(token);
        id.sub = id.COMCAST_USERNAME;
        sessionStorage.setItem("token", token);
        sessionStorage.setItem("_id", JSON.stringify(id));
        if (isOnline && offlineDB) {
            offlineDB.clearData("PROFILE", id.sub);
            offlineDB.addData("PROFILE", id.sub, JSON.stringify(id));
        }
        //auth0.is_logged = true;
        sessionStorage.setItem("loggedIn", true)
        window.location.href = "#home";
        $('#span_user_id').html(id.sub);
    },

    //** pass authorization_code here to get access_token

    //** NOT REQUIRED FOR IMPLICIT TYPE
    /*
    getToken: function(code) {
        sessionStorage.setItem("authcode", code);
        var path = this.token_uri;
        var queryParams = [
            'client_id=' + this.client_id,
            'client_secret=' + this.client_secret,
            'redirect_uri=' + this.getRedirectUri(),
            'scope=openid',
            'grant_type=authorization_code',
            'code=' + code
        ];
        var query = queryParams.join('&');
        var url = path + '?' + query;
        $.ajax({
            type: "GET",
            beforeSend: function(request) {
                request.setRequestHeader("Cache-Control", "no-cache");
                request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            },
            url: url,
            processData: false,
            success: function(response) {
                //console.log(response);
                var id = auth0.parseJwt(response.id_token);
                globalize.user_id = id.sub;
                sessionStorage.setItem("tokens", JSON.stringify(response));
                sessionStorage.setItem("_id", JSON.stringify(id));
                auth0.is_logged = true;
                window.location.href = "#home";
                $('#span_user_id').html(id.sub);
            }
        });
    }
    */
};

//to open url in SafariViewController
function openUrl(url, readerMode) {
    var mobile_base;

    if (config.mode === "production") {
        mobile_base = auth0.redirect_uris.mobile.production.base;
    } else {
        mobile_base = auth0.redirect_uris.mobile.dev.base;
    }

    var ssoOptions = {
        "ssoUrl": url,
        "targetUrl": mobile_base,
        "cookieCheckRequired": false,
        "cookieName": ""
    }
    setTimeout(function() {
        cordova.plugins.sso.loadWebView(ssoOptions, mobileAuthSuccess, mobileAuthFail);
    }, 100)

    return;
}

function openSafariVC(url, readerMode) {
    var mobile_base;

    if (config.mode === "production") {
        mobile_base = auth0.redirect_uris.mobile.production.base;
    } else {
        mobile_base = auth0.redirect_uris.mobile.dev.base;
    }
    SafariViewController.isAvailable(function(available) {
        if (available) {
            SafariViewController.show({
                    url: url,
                    hidden: false, // default false. You can use this to load cookies etc in the background (see issue #1 for details).
                    animated: false, // default true, note that 'hide' will reuse this preference (the 'Done' button will always animate though)
                    transition: 'curl', // (this only works in iOS 9.1/9.2 and lower) unless animated is false you can choose from: curl, flip, fade, slide (default)
                    enterReaderModeIfAvailable: readerMode, // default false
                    tintColor: "#00ffff", // default is ios blue
                    barColor: "#0000ff", // on iOS 10+ you can change the background color as well
                    controlTintColor: "#ffffff" // on iOS 10+ you can override the default tintColor
                },
                // this success handler will be invoked for the lifecycle events 'opened', 'loaded' and 'closed'
                function(result) {
                    if (result.event === 'opened') {
                        console.log('opened');
                    } else if (result.event === 'loaded') {
                        console.log('loaded');
                    } else if (result.event === 'closed') {
                        console.log('closed');
                    }
                },
                function(msg) {
                    console.log("KO: " + msg);
                })
        } else {
            // potentially powered by InAppBrowser because that (currently) clobbers window.open
            //window.open(url, '_blank', 'location=yes');
            var authWindow = window.open(url, '_blank', 'location=yes');
            authWindow.addEventListener('loadstart', function(event) {
                console.log(event.url);
                if (event.url.lastIndexOf(mobile_base, 0) === 0) {
                    var code = event.url.split("access_token=")[1];
                    auth0.decodeToken(code);
                    authWindow.close();
                }else if(event.url.indexOf("logout">-1)){
                    authWindow.close();
                }
            });
        }
    });
}

function mobileAuthSuccess() {
    //console.log("success");
}

function mobileAuthFail() {
    console.log("cancelled");
}

function dismissSafari() {
    SafariViewController.hide()
}