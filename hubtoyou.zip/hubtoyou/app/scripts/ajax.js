define(['jquery',
    'underscore',
    'backbone',
], function($, _, backbone) {
    'use strict';

    /*
     * Store a version of Backbone.sync to call from the
     * modified version we create
     */
    var backboneSync = Backbone.sync;
    //backboneSync.ajaxCounter = 0;
    Backbone.sync = function(method, model, options) {
        var params = _.clone(options);

        params.success = function(model) {
            // Write code to hide the loading symbol
            // setTimeout(function(){
            //     hideLoadingIndicator();
            // },1000);
            if (options.success) {
                options.success(model);
            }
        };
        params.failure = function(model) {
            // Write code to hide the loading symbol
            hideLoadingIndicator();
            modalMsg("Unable to connect. Please check your internet connection.", "error");
            if (options.failure) {
                options.failure(model);
            }
        };
        params.error = function(xhr, errText) {
            // Write code to hide the loading symbol
            hideLoadingIndicator();
            modalMsg("Unable to connect to the server. Please try again.", "error");
            if (options.error) {
                options.error(xhr, errText);
            }
        };
        // Write code to show the loading symbol
        if (getUsername() !== "") {
            //showLoadingIndicator();
        }
        params.crossDomain = true;
        //startTimerunner();
        backboneSync(method, model, params);
    };
});


// Backbone._sync = Backbone.sync;
// Backbone.sync = function(method, model, options) {
//     // Clone the all options
//     var params = _.clone(options);

// params.success = function(model) {
//     // Write code to hide the loading symbol
//      $('#spinner_canvas').fadeOut({
//         duration: 100
//     });
//     $('body').removeClass('masked');
//     if (options.success)
//         options.success(model);
// };
// params.failure = function(model) {
//     // Write code to hide the loading symbol
//      $('#spinner_canvas').fadeOut({
//         duration: 100
//     });
//     $('body').removeClass('masked');
//     if (options.failure)
//         options.failure(model);
// };
// params.error = function(xhr, errText) {
//     // Write code to hide the loading symbol
//     $('#spinner_canvas').fadeOut({
//         duration: 100
//     });
//     $('body').removeClass('masked');
//     if (options.error)
//         options.error(xhr, errText);
// };
// // Write code to show the loading symbol
//         if (getUsername() !== "") {
//                 $('#spinner_canvas').fadeIn({
//                     duration: 100
//                 });
//                 $('body').addClass('masked');
//         }
// Backbone._sync(method, model, params);
// };