define([
    'jquery',
    'underscore',
    'backbone',
    'jqueryui',
    'templates',
    'views/userpreferences',
    'views/regionemployees',
    'models/userpreferences',
    'views/searchntusernamepopup'
], function($, _, Backbone, jqueryui, JST, UserPreferencesView, RegionEmployeesView, UserPreferencesModel,
    SearchNTUserPopupView) {
    'use strict';

    var BUAdminView = Backbone.View.extend({
        template: JST['app/scripts/templates/buadministration.ejs'],
        regionEmployeeTemplate: JST['app/scripts/templates/regionemployees.ejs'],
        userPreferencesTemplate: JST['app/scripts/templates/buadministration.ejs'],
        userPreferencesMain: JST['app/scripts/templates/userpreferencesmain.ejs'],
        //model: '',
        el: '#container',
        id: '',
        viewName: 'buAdminView',
        inputData: {},
        events: {
            'click #regEmp': 'loadRegionEmployees',
            'click #userPref': 'loadUserPreferences',
            'click #user_pref_go': 'searchPreferencesData',
            'click #selectuserNTUsernameInput': 'searchNTUserNamePopup',
            'change .user-name-validation': 'updateUserName',
            //'focus .user-name-validation': 'getAutoComplete',
            // 'input .user-name-validation': 'fetchData'
        },
        initialize: function() {
            this.userModel = new UserPreferencesModel();
            this.listenTo(this.userModel, 'sync', this.validationResultUserName);
            //this.render();
        },
        render: function() {
            this.deliveryLocation = JSON.parse(sessionStorage.getItem("preferences")).DELIVERY_TO_LOCATION;
            if (!isValid(this.deliveryLocation)) {
                modalMsg("Please set delivery location in Prefernces", "info", "Message");
                window.location.href = "#settings";
                return;
            }
            this.region = JSON.parse(sessionStorage.getItem("preferences")).REGION_NAME;
            this.buNumber = JSON.parse(sessionStorage.getItem("preferences")).ATTRIBUTE9;
            this.$el.html(this.template(this.region));
            this.regionEmpView = new RegionEmployeesView({ bu: this.buNumber });

            this.delegateEvents(this.events);
            return this;
        },

        loadRegionEmployees: function() {
            $('.bu-admin-content').empty();
            //this.personalFavorites = false;
            $('#userPref').removeClass('btn-selected');
            $('#regEmp').addClass('btn-selected');
            this.regionEmpView = new RegionEmployeesView({ bu: this.buNumber });
            hideHeaderButtons();
            // $('.bu-admin-content').html(this.regionEmployeeTemplate());
        },
        loadUserPreferences: function() {
            $('.bu-admin-content').empty();
            this.regionEmpView.close();
            //this.personalFavorites = false;
            $('#userPref').addClass('btn-selected');
            $('#regEmp').removeClass('btn-selected');
            $('.bu-admin-content').html(this.userPreferencesMain());
            showHeaderButtons(false, true, "Reset", "Save");
            disableDone();
            //this.childView = new UserPreferencesView();
            //this.childView.model.fetchData();
            //$('.bu-admin-content').html(this.userPreferencesTemplate());
        },
        validateGoButton: function(value) {
            if (isValid(value.UserNameValue)) {
                this.$el.find('#user_pref_go').removeClass('button-disable-opacity');
                return;
            } else {
                this.$el.find('#user_pref_go').addClass('button-disable-opacity');
            }
        },
        searchPreferencesData: function() {
            if (this.childView) {
                this.childView.close();
            }
            showLoadingIndicator();
            this.childView = new UserPreferencesView({
                userName: this.validUserNameValue
            });

        },
        backButtonAction: function() {
            this.toggleView();
        },
        updateUserName: function(element, data) {
            this.inputData.UserNameValue = element.currentTarget.value;
            this.validateGoButton(this.inputData);

            if (data == undefined) {
                this.validUserNameValue = element.currentTarget.value;
            } else {
                this.validUserNameValue = data.data;
                //$('#user_pref_go').removeClass('button-disable-opacity');
            }

        },
        validationResultUserName: function(data) {
            // var data = this.userModel.response;
            if (data.toJSON().EXC_DB_FETCH_USER_NAMEOutput != undefined && data.toJSON().EXC_DB_FETCH_USER_NAMEOutput.length > 0) {
                if ($(globalize.userNameInput).hasClass('contain-error')) {
                    $(globalize.userNameInput).removeClass('contain-error');
                }
                var sample = data.toJSON().EXC_DB_FETCH_USER_NAMEOutput;
                // $('#update_submit').removeClass('button-disable-opacity');
                this.validUserName = true;
                this.validUserNameValue = data.toJSON().EXC_DB_FETCH_USER_NAMEOutput[0].user_name;
                enableDone();
                var finallist = [];
                for (var i = 0; i < sample.length; i++) {
                    finallist.push(sample[i].user_name);
                }
                $(".user-name-validation").autocomplete({
                    source: finallist
                });
                //$(".user-name-validation").trigger('change');

                //this.validateSettingsBtn();
            }

        },
        getAutoComplete: function() {
            var sample = ['Ram', 'shyamm'];
            // $(".user-name-validation").autocomplete({
            //     source: sample
            // });
        },
        fetchData: function(element) {
            var data = $(element.target).val();
            if (data.length > 3) {
                this.userModel.fetchUserName(data);
            } else {
                return element.currentTarget.value;
            }

        },
        searchNTUserNamePopup: function(element) {
            globalize.NTUsernameInputBox = element.currentTarget.previousElementSibling;
            $('#bu_page').hide();
            var searchNTUserView = new SearchNTUserPopupView();
            breadCrumbs.push({ href: '#', name: 'Search NT User Name' });
            showHeaderButtons(false, true, "Reset", "Done");
            updateBreadCrumbs();
            showBackButton();
            globalView = this;
        }


    });

    return BUAdminView;
});