/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'views/header',
    'views/footer',
    'ajax',
    'globalise'
], function($, _, Backbone, HeaderView, FooterView, ajax, globalize) {
    'use strict';
    var LayoutView = Backbone.View.extend({
        el: '#layout',
        id: '',

        className: '',

        events: {

        },

        render: function() {
            this.$("#header").html((this.header = new HeaderView()).render().el);
            this.$("#footer").html((this.footer = new FooterView()).render().el);
            return this;
        },
        renderChild: function(view, collect) {
            if (view.viewName === "loginView" || view.viewName === "logoutView" || view.viewName === "OfflineLoginView") {
                $("#header").hide();
                $("#footer").hide();
                //$('body').removeClass('view-container');
            } else {
                $("#header").show();
                $("#footer").show();
                //$('body').addClass('view-container');
            }

            if (this.child)
                this.child.remove();
            if (view.viewName == "homeView") {
                collect.fetch({
                    success: function(data) {
                        view.render(data);
                        //localStorage.set('prefences',data);
                        //this.$("#container").html((this.child = view).render(data).el);
                    }
                });
            } else {
                //this.$("#container").html((this.child = view).render(collect).el);
                view.render(collect);
            }
        },


        close: function() {
            this.remove();
            this.unbind();
            // handle other unbinding needs, here
            _.each(this.child, function(childView) {
                if (childView.close) {
                    childView.close();
                }
            })
        },

        // slideClose: function() {
        //     $('.slide-menu').animate({
        //         left: "-250px"
        //     }, 200, function() { $(this).hide() });

        //     $('body').animate({
        //         left: "0px"
        //     }, 200);

        //     $('.navbar-fixed-top').animate({
        //         left: "0px",
        //         right: "0px"
        //     }, 200);

        //     $('#page_mask').fadeOut();
        //     $('body').removeClass('masked');
        //     //$('.slide-menu').css("display", "none");
        // }


        swipeIt: function(e) {
            if (e.direction == 'right') {
                console.log("You swiped right");
            } else if (e.direction == 'left') {
                console.log("You swiped left");
            }
        }
    });



    return LayoutView;
});