/*globalize*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/projectstatus',
    'models/projecttype',
    'models/projectclass',
    'models/searchprojectdetails',
    'models/searchwarehouse',
    'models/searchinventory'
], function($, _, Backbone, JST, ProjectStatusModel, ProjectTypeModel, ProjectClassModel, SearchProjectDetailsModel, SearchWarehouseModel, SerachInventoryModel) {
    'use strict';

    var SelectSourceView = Backbone.View.extend({
        template: JST['app/scripts/templates/selectprojectnumber.ejs'],
        searchTemplate: JST['app/scripts/templates/searchresults.ejs'],
        searchWarehouseTemplate: JST['app/scripts/templates/searchwarehouse.ejs'],
        searchInventoryTemplate: JST['app/scripts/templates/searchinventory.ejs'],
        //el:'#projectNoSearch',
        el: '#projectNoSearch',
        id: '',

        className: '',

        events: {
            'click #search': 'search',
            'click .backBtnSettings': 'closeSearchWindow',
            'click .selectRecordRow': 'selectRecord',
            'click #PopulateProjectNumber': 'populateProjectNumber',
            'change #ssProjectNO': 'updateProjectNumber',
            'change #ssProjectName': 'updateProjectName',
            'change #ssProjectType': 'updateProjectType',
            'change #ssType': 'updateType',
            'change #ssStatus': 'updateStatus',
            'change #ssBu': 'updateBU',
            'change #ssDesc': 'updateDesc',

            'change #orgCodeInput': 'updateOrgCode',
            'change #locCodeInput': 'updateLocCode',
            'change #descInput': 'updateDesc',
            'change #inventoryInput': 'updateInventory'


        },

        initialize: function() {
            if (AppView.currentView !== undefined) {
                globalPreviousView = AppView.currentView;
            }
            AppView.currentView = this;
            this.status = new ProjectStatusModel();
            this.projectType = new ProjectTypeModel();
            this.projectClass = new ProjectClassModel();
            this.projectDetails = new SearchProjectDetailsModel();
            this.wareHouseDetails = new SearchWarehouseModel();
            this.searchInventory = new SerachInventoryModel();
            if (globalize.selectedWIndow == "selectProjectNo") {
                // When User has default BU as yes, we must set the BU number defaulted in the application.
                this.DefaultBU = localStorage.getItem("defaultBU");
                if (this.DefaultBU == "Y") {
                    this.buNumber = localStorage.getItem("buNumber");
                } else {
                    this.buNumber = "";
                }
                //code ends
                showLoadingIndicator();
                this.status.fetchData();
            } else {
                this.render();
            }
            disableDone();
            this.listenTo(this.status, 'sync', this.gotoProjectTypeCall);
            this.listenTo(this.projectType, 'sync', this.gotoProjectClassCall);
            this.listenTo(this.projectClass, 'sync', this.renderProjectDetails);
            this.listenTo(this.projectDetails, 'sync', this.renderTable); //Search Service for project details
            this.listenTo(this.wareHouseDetails, 'sync', this.renderTable); //search for locations
            this.listenTo(this.searchInventory, 'sync', this.renderTable); //search for locations
            this.inputData = {};
        },

        renderProjectDetails: function() {
            this.projectTypeDropdown = this.projectClass.toJSON();
            var data = {}
            data.projectTypeDropdown = this.projectTypeDropdown;
            data.statusDropdown = this.statusDropdown;
            data.typeDropdown = this.typeDropdown;
            data.bu = this.buNumber; //setting if Bu value exists (If Defaulted BU is YES)
            this.$el.html(this.template(data));
            if (isValid(data.bu)) {
                this.inputData.bu = this.buNumber;
                this.validateSearchButton(this.inputData);
            }
            hideLoadingIndicator();
            return this;
        },
        render: function() {
            this.$el.html(this.template());
        },
        gotoProjectTypeCall: function() {
            this.statusDropdown = this.status.toJSON();
            this.projectType.fetchData();
        },
        gotoProjectClassCall: function() {
            this.typeDropdown = this.projectType.toJSON();
            this.projectClass.fetchData();
        },
        inputData: {},
        /*Search button validating the input fields*/
        validateSearchButton: function(value) {
            if (isValid(value.projectNo) || isValid(value.bu) || isValid(value.projectName) ||
                isValid(value.projectType) || isValid(value.status) || isValid(value.type) || isValid(value.orgCodeValue) || isValid(value.locCodeValue) || isValid(value.descCodeValue) || isValid(value.subInventoryValue)) {
                //this.$el.find('.button-white').removeClass('button-disable-opacity');
                return;
            } else {
                //this.$el.find('.button-white').addClass('button-disable-opacity');
            }
        },
        /*USer input updation in project details window*/
        updateProjectNumber: function(event) {
            this.inputData.projectNo = event.currentTarget.value;
            this.validateSearchButton(this.inputData);
        },
        updateProjectName: function(event) {
            this.inputData.projectName = event.currentTarget.value;
            this.validateSearchButton(this.inputData);
        },
        updateProjectType: function(event) {
            this.inputData.projectType = event.currentTarget.value;
            this.validateSearchButton(this.inputData);
        },
        updateStatus: function(event) {
            this.inputData.status = event.currentTarget.value;
            this.validateSearchButton(this.inputData);
        },
        updateBU: function(event) {
            this.inputData.bu = event.currentTarget.value;
            this.validateSearchButton(this.inputData);
        },
        updateType: function(event) {
            this.inputData.type = event.currentTarget.value;
            this.validateSearchButton(this.inputData);
        },
        /*USer input updation in location/warehouse window*/
        updateOrgCode: function(event) {
            this.inputData.orgCodeValue = event.currentTarget.value;
            this.validateSearchButton(this.inputData);
        },
        updateLocCode: function(event) {
            this.inputData.locCodeValue = event.currentTarget.value;
            this.validateSearchButton(this.inputData);
        },
        updateDesc: function(event) {
            this.inputData.descCodeValue = event.currentTarget.value;
            this.validateSearchButton(this.inputData);
        },
        /*User input sub inventory*/
        updateInventory: function(element) {
            this.inputData.subInventoryValue = element.currentTarget.value;
            this.validateSearchButton(this.inputData);
        },
        search: function() {
            this.$el.find('.load-results').empty();
            if (globalize.selectedWIndow == "selectProjectNo") {
                var dataInput = {
                    "ProjectNumber": this.inputData.projectNo,
                    "ProjectName": this.inputData.projectName,
                    "ProjectDescription": this.inputData.descCodeValue,
                    "ProjectType": this.inputData.type,
                    "ProjectClassCode": this.inputData.projectType,
                    "ProjectStatusName": this.inputData.status,
                    "BusinessUnit": this.inputData.bu
                }
                showLoadingIndicator();
                this.projectDetails.fetchData(dataInput);
            }
            if (globalize.selectedWIndow == "selectSourceWarehouse" || globalize.selectedWIndow == "selectDeliveryLocation") {
                var dataInput = {
                    "ORGANIZATION_CODE": this.inputData.orgCodeValue,
                    //  "LOCATION_DISPLAY" : data.orgCodeValue,
                    "DESCRIPTION": this.inputData.descValue,
                    "LOCATION_CODE": this.inputData.locCodeValue
                }
                showLoadingIndicator();
                this.wareHouseDetails.fetchData(dataInput);
            }
            if (globalize.selectedWIndow == "selectSubInventory") {
                var dataInput = {
                    "ORGANIZATION_CODE": this.inputData.orgCodeValue,
                    "SUBINVENTORY_NAME": this.inputData.subInventoryValue
                }
                showLoadingIndicator();
                this.searchInventory.fetchData(dataInput);
            }
        },
        renderTable: function(data) {

            if (globalize.selectedWIndow == "selectProjectNo") {
                this.$el.find('.load-results').html(this.searchTemplate(data.detailsResponse));
                hideLoadingIndicator();
            }
            if (globalize.selectedWIndow == "selectSourceWarehouse" || globalize.selectedWIndow == "selectDeliveryLocation") {
                this.$el.find('.load-results').html(this.searchWarehouseTemplate(data.warehouseResponse));
                hideLoadingIndicator();
            }
            if (globalize.selectedWIndow == "selectSubInventory") {
                this.$el.find('.load-results').html(this.searchInventoryTemplate(data.inventoryResponse));
                hideLoadingIndicator();
            }
            $('[data-toggle="tooltip"]').tooltip();
        },
        /* Record selection from table */
        selectRecord: function(element) {
            var selectedTemplate;
            var selectId = $(element.currentTarget).prop('id');
            var cur_row = selectId.split("_");
            $("#radioBtn_" + cur_row[1]).prop("checked", true);
            $(".mobile-select-btn").addClass("hidden");
            $("#mob-row_" + cur_row[1]).removeClass("hidden");
            enableDone();
            if (globalize.selectedWIndow == "selectProjectNo") {
                var projectNO = $("#projectNumber_" + cur_row[1]).text();
                var list = this.projectDetails.toJSON().ProjectsDetailsOutput;
                selectedTemplate = _.find(list, function(item) {
                    return item.ProjectNumber === projectNO;
                });
                this.selectedTemplate = selectedTemplate;
                this.selectedProjectNumber = selectedTemplate.ProjectNumber;
            }
            if (globalize.selectedWIndow == "selectSourceWarehouse") {
                var orgNO = $("#orgCode_" + cur_row[1]).text();
                var list = this.wareHouseDetails.toJSON().EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput;
                selectedTemplate = _.find(list, function(item) {
                    return item.ORGANIZATION_CODE === orgNO;
                });
                this.selectedTemplate = selectedTemplate;
                this.selectedCode = selectedTemplate.ORGANIZATION_CODE;
            }
            if (globalize.selectedWIndow == "selectDeliveryLocation") {
                var orgNO = $("#orgCode_" + cur_row[1]).text();
                var list = this.wareHouseDetails.toJSON().EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput;
                selectedTemplate = _.find(list, function(item) {
                    return item.ORGANIZATION_CODE === orgNO;
                });
                this.selectedTemplate = selectedTemplate;
                this.selectedCode = selectedTemplate.LOCATION_CODE;
            }
            if (globalize.selectedWIndow == "selectSubInventory") {
                var subInventorName = $("#subInventorName_" + cur_row[1]).text();
                var list = this.searchInventory.toJSON().EXC_DB_SELECT_SUBINVENTORYOutput;
                selectedTemplate = _.find(list, function(item) {
                    return item.SUBINVENTORY_NAME === subInventorName;
                });
                this.selectedTemplate = selectedTemplate;
                this.selectedCode = selectedTemplate.SUBINVENTORY_NAME;
            }

        },
        populateProjectNumber: function() {


            if (globalize.selectedWIndow == "selectProjectNo") {
                $(globalize.projectNoInputBox).val(this.selectedProjectNumber);
                $(globalize.projectNoInputBox).removeClass('contain-error');
                $(globalize.projectNoInputBox).trigger('change', [{ data: this.selectedTemplate }]);
            }
            if (globalize.selectedWIndow == "selectSourceWarehouse") {
                $(globalize.srcInputBox).val(this.selectedCode);
                $(globalize.srcInputBox).removeClass('contain-error');
                $(globalize.srcInputBox).trigger('change', [{ data: this.selectedTemplate }]);

            }
            if (globalize.selectedWIndow == "selectDeliveryLocation") {
                $(globalize.deliveryLocInputBox).val(this.selectedCode);
                $(globalize.deliveryLocInputBox).removeClass('contain-error');
                $(globalize.deliveryLocInputBox).trigger('change', [{ data: this.selectedTemplate }]);
            }
            if (globalize.selectedWIndow == "selectSubInventory") {
                $(globalize.subInventoryInputBox).val(this.selectedCode);
                $(globalize.subInventoryInputBox).removeClass('contain-error');
                $(globalize.subInventoryInputBox).trigger('change', [{ data: this.selectedTemplate }]);
            }
            if (breadCrumbs[0].name == "ShoppingCart") {
                this.$el.empty();
                this.close();
                if ($('.mobile-update-cart-lines').children().length > 0) {
                    AppView.currentView = globalView; //setting for usage in mobile view for getting bakc the parent view
                    $('.mobile-update-cart-lines').show();
                    if (globalize.selectedWIndow == "selectProjectNo") {
                        $($('.project-details-update-field-mobile')[1]).removeClass('button-disable-opacity');
                        $('#sc_update_projectNo_mob').removeClass('contain-error');
                        disableDone();
                    }
                    return;
                }
                AppView.currentView = globalView;
                showHeaderButtons(false, true, "Reset", "Submit");
                removeBackButton();
                $('.shoppingcart-page').show();
            } else if (breadCrumbs[0].name == "BU Administration") {
                this.$el.empty();
                this.close();
                AppView.currentView = globalView;
                showHeaderButtons(false, true, "Reset", "Save");
                removeBackButton();
                $('#bu_page').show();
            } else {
                removeBackButton();
                this.$el.empty();
                showHeaderButtons(false, true, "Reset", "Save");
                AppView.currentView = globalView;
                this.close(); //to kill the current view
                $('.settings-page').show();

            }
            updateBreadcrumbsToParent() //to update the parent page breadcrumb
        },
        closeSearchWindow: function(element) {
            var url = window.location.href;
            //console.log("url.." + url);
            if (url.indexOf("#shoppingcart") > -1) {
                $('.shoppingcart-page').show();
            } else {
                $('.settings-page').show();
            }

            this.$el.empty();
            this.inputData = {};
            this.close(); //to kill the current view
            var len = breadCrumbs.length;
            breadCrumbs.splice(len - 1, 1);
            updateBreadCrumbs();
        },
        backButtonAction: function(element) {
            var url = window.location.href;
            //console.log("url.." + url);
            if (url.indexOf("#shoppingcart") > -1) {
                if (globalize.updateCartLine != undefined && globalize.updateCartLine == true) {
                    $('.mobile-update-cart-lines').show();
                    AppView.currentView = globalView;
                } else {
                    $('.shoppingcart-page').show();
                    removeBackButton();
                    hideHeaderButtons();
                }
            } else if (url.indexOf("#buadmin") > -1) {
                AppView.currentView = globalView;
                showHeaderButtons(false, true, "Reset", "Save");
                removeBackButton();
                $('#bu_page').show();

            } else {
                $('.settings-page').show();
                removeBackButton();
                showHeaderButtons(false, true, "Reset", "Save");
                AppView.currentView = globalView;
                enableDone();
            }
            this.close(); //to kill the current view
            var len = breadCrumbs.length;
            breadCrumbs.splice(len - 1, 1);
            updateBreadCrumbs();
        },
        rightbuttonAction: function() {
            this.populateProjectNumber();
        }
    });

    return SelectSourceView;
});