/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/intransitinput',
], function($, _, Backbone, JST, intransitModel) {
    'use strict';

    var IntransitView = Backbone.View.extend({
        template: JST['app/scripts/templates/intransit.ejs'],
        noRecords: JST['app/scripts/templates/norecords.ejs'],
        viewName: 'viewIntransit',
        el: '#container',
        tagName: 'div',
        model: new intransitModel(),
        id: '',
        className: '',
        events: {
            'click .gotobackBtn': 'goToBack'

        },
        initialize: function() {
            AppView.currentView = this;
            this.listenTo(this.model, 'change', this.render);
        },
        render: function(data) {
            if (typeof data.responseData.InTransitOutput !== "undefined") {
                this.$el.html(this.template(data.responseData));
                this.delegateEvents(this.events);
            } else {
                this.$el.html(this.noRecords()); //Display No records View
            }
            hideLoadingIndicator();
            return this;
        },
        goToBack: function() {
            var len = breadCrumbs.length;
            breadCrumbs.splice(len - 1, 1);
            updateBreadCrumbs();
            window.history.back();
        },
        backButtonAction: function() {
            var len = breadCrumbs.length;
            breadCrumbs.splice(len - 1, 1);
            updateBreadCrumbs();
            toggleBackButton();
            window.history.back();
        }



    });

    return IntransitView;
});