/**/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/regionalfavorites',
    'collections/regionalfavorites',
    'collections/regionlist',
    'collections/templatelist',
    'views/itemDetails',
    'models/addtocart'
], function($, _, Backbone, JST, RegionalFavModel, RegionalFavoritesCollection, RegionListCollection, TemplateListCollection, ItemDetailsView, CartModel) {
    'use strict';

    var PersonalFavoritesView = Backbone.View.extend({
        template: JST['app/scripts/templates/regionalfavorites.ejs'],
        emptyTemplate: JST['app/scripts/templates/norecords.ejs'],
        searchTemplate: JST['app/scripts/templates/norecordssearch.ejs'],
        collection: new RegionalFavoritesCollection(),
        regionList: new RegionListCollection(),
        templateList: new TemplateListCollection(),

        el: '#favouriteList',
        model: new RegionalFavModel(),
        viewName: 'regionalfavoritesView',
        events: {
            'click .reg_select_source': 'loadSelectSource',
            'click .add_favorite': 'createFavorite',
            'click .item-number': 'goToItemDetails',
            'click .reg_addto_cart': 'addToCart',
            //'change #regionList': 'getTemplates'
        },

        initialize: function(options) {
            this.cartmodel = new CartModel();
            this.collection.each(function(model) {
                if (model != undefined) {
                    model.destroy();
                }
            });
            this.listenTo(this.collection, 'reset sort', this.render);
            this.listenTo(this.regionList, 'reset', this.populateRegion);
            this.listenTo(this.templateList, 'reset', this.pouplateTemplate);
            this.$el.append(this.searchTemplate());
        },

        render: function(data) {
            var _this = this;
            this.$el.empty();
            if (data.isEmpty()) {
                this.$el.append(this.emptyTemplate());
                return;
            }
            data.models.forEach(function(model) {
                var item = model.toJSON();
                _this.$el.append(_this.template(item));

                var spin_id = "#numspinner_" + item.CIFA_ITEM_NUMBER;

                var min_val = (item.MinimumOrder === null) ? 1 : item.MinimumOrder;
                var max_val = (item.MaximumOrder === null) ? 2147483647 : item.MaximumOrder;
                var interval = (item.FixedLot === null) ? 1 : item.FixedLot;

                var options = {
                    initval: min_val,
                    min: min_val,
                    max: max_val,
                    step: interval,
                }
                $(spin_id).TouchSpin(options);
            });
            if (isPhoneGap()) {
                $('.dateinput').focus(function() {
                    //console.log("focus firing");
                    var options = {
                        date: new Date(),
                        mode: 'date'
                    };

                    datePicker.show(options, function(date) {
                        $(options.target).val(date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate());
                    });
                });
            } else {
                $('.dateinput').datepicker({
                    autoclose: true,
                    format: "yyyy-mm-dd",
                    startDate: new Date()
                });
            }
            hideLoadingIndicator();
        },

        modelSet: function(data) {
            this.model.set('REQUESTOR_USER_NAME', getUsername());
        },

        createFavorite: function(element) {
            var selectedTemplate;
            var recordId = $(element.currentTarget).attr("data-id"); //parent().parent().find('.item-number').prop('id')
            globalize.temp = {};
            globalize.temp.selectedRecord = recordId;
            var list = this.collection.toJSON();
            selectedTemplate = _.find(list, function(item) {
                return item.CIFA_ITEM_NUMBER === recordId;
            });
            var data = {
                "REQUESTOR_USER_NAME": getUsername(),
                "INVENTORY_ITEM_ID": selectedTemplate.INVENTORY_ITEM_ID,
                "CIFA_ITEM_NUMBER": selectedTemplate.CIFA_ITEM_NUMBER,
                "CATEGORY": selectedTemplate.ITEM_CATEGORY,
                "MFG_PART_NUMBER": selectedTemplate.MFG_PART_NUMBER,
                "ITEM_DESCRIPTION": selectedTemplate.ITEM_DESCRIPTION,
                "REGION_NAME": selectedTemplate.REGION_NAME,
                "TEMPLATE_NAME": selectedTemplate.TEMPLATE_NAME
            };

            this.model.insertFavorite(data);
        },

        goToItemDetails: function(element) {
            var itemId = element.currentTarget.id;
            var favItem = this.collection.find(function(model) { return model.get('CIFA_ITEM_NUMBER') === itemId; }).toJSON();

            //favItem.quantity = $(element.currentTarget).closest('section').find('.selectQuantity').val();
            //favItem.needByDate = $(element.currentTarget).closest('section').find('.needByDate').val();

            favItem.quantity = $("#numspinner_" + itemId).val();
            favItem.needByDate = $("#date_needby_" + itemId).val();

            localStorage.setItem("currentFavItem", JSON.stringify(favItem));
            window.location.href = "#item_details?=" + itemId;
            //new ItemDetailsView().model.fetchData(itemId);
        },

        loadSelectSource: function(element) {
            var itemId = $(element.currentTarget).attr("data-id");
            var favItem = this.collection.find(function(model) { return model.get('CIFA_ITEM_NUMBER') === itemId; }).toJSON();

            //favItem.quantity = $("#numspinner_" + favItem.CIFA_ITEM_NUMBER).val();
            //favItem.needByDate = $(element.currentTarget).closest('section').find('.needByDate').val();

            favItem.quantity = $("#numspinner_" + itemId).val();
            favItem.needByDate = $("#date_needby_" + itemId).val();

            localStorage.setItem("currentFavItem", JSON.stringify(favItem));
            this.close();
            this.unbind();
            window.location.href = "#select_source?=" + itemId;
        },

        populateRegion: function() {
            console.log("populate region");
            $('#regionList').empty();
            this.regionList.models.forEach(function(model) {
                $('<option>').val(model.get("Lookup_Code")).text(model.get("Meaning")).appendTo('#regionList');
            });

            var data = {
                "Region_Name": $('#regionList').val()
            }
            this.templateList.fetchData(data);
        },

        pouplateTemplate: function() {
            $('#selectTemplateList').empty();
            $('<option>').val("0").text(globalize.pleaseSelect).attr({ "selected": true, "disabled": true, "hidden": true }).appendTo('#selectTemplateList');
            this.templateList.models.forEach(function(model) {
                $('<option>').val(model.get("Lookup_Code")).text(model.get("Meaning")).appendTo('#selectTemplateList');
            });
        },

        getTemplates: function(el) {
            var data = {
                "Region_Name": el.currentTarget.value
            }
            this.templateList.fetchData(data);
        },


        cleanup: function() {
            this.undelegateEvents();
            $(this.el).empty();
        },

        addToCart: function(element) {
            var itemId = $(element.currentTarget).attr("data-id");
            var favItem = this.collection.find(function(model) { return model.get('CIFA_ITEM_NUMBER') === itemId; }).toJSON();

            var userData = JSON.parse(sessionStorage.getItem('_id'));
            var username = userData.sub;
            var needbydatevalue = $("#date_needby_" + itemId).val() + "T00:00:00";
            //var needbyDate = localStorage.getItem('needbyDate') + "T00:00:00";

            var cartInputData = {
                "ShoppingCartUpsertData": [{
                    "CIFA_ITEM_NUMBER": favItem.CIFA_ITEM_NUMBER,
                    "ITEM_DESC": favItem.ITEM_DESCRIPTION,
                    "ITEM_CATEGORY": favItem.ITEM_CATEGORY,
                    "QUANTITY": $("#numspinner_" + favItem.CIFA_ITEM_NUMBER).val(),
                    "NEED_BY_DATE": needbydatevalue,
                    "USER_NAME": username,
                    "REGION_TEMPLATE": favItem.TEMPLATE_NAME,
                    "REGION_NAME": favItem.REGION_NAME
                }]
            }
            showLoadingIndicator();
            this.cartmodel.addToCartRequest(cartInputData);
        }

    });
    return PersonalFavoritesView;
});