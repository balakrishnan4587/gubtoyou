/**/

define([
    'jquery',
    'underscore',
    'backbone',
    'datepicker',
    'templates',
    'globalise',
    'collections/catalogsearch',
    'models/addtocart',
    'models/regionalfavorites'
], function($, _, Backbone, datepicker, JST, globalize, CatalogSearchCollection, CartModel, favModel) {
    'use strict';

    var SearchView = Backbone.View.extend({
        template: JST['app/scripts/templates/catalogsearch.ejs'],
        resultTemplate: JST['app/scripts/templates/catalogsearchresult.ejs'],
        emptyTemplate: JST['app/scripts/templates/norecords.ejs'],
        searchTemplate: JST['app/scripts/templates/norecordssearch.ejs'],
        collection: new CatalogSearchCollection(),
        childView: null,
        currentType: "basic",
        el: '#container',
        resultEl: '#searchResultList',
        viewName: 'searchView',
        cartmodel: new CartModel(),
        model: new favModel(),
        events: {
            'click #btnCatalogSearch': 'basicSearch',
            'click #btnCatalogAdvancedSearch': 'advancedSearch',
            'keyup #filter_result_field': 'searchList',
            'change #select_sort_filter': 'sortList',
            'click #btnSearchBasic': 'showBasicSearch',
            'click #btnSearchAdv': 'showAdvancedSearch',
            'click #searchMobile': 'basicSearch',
            'click #search-filter-btn': 'toggleFilter',
            'keyup #inputSearchText': 'searchList',
            'change #select_search_filter': 'sortList',
            'click .search-favorite': 'createFavorite',
            'click .search-select-source': 'goToSelectSource',
            "click .search-addto-cart": "addToCart",
            'click .item-number': 'goToItemDetails'
        },

        initialize: function(options) {
            this.listenTo(this.collection, 'reset sort', this.renderResults);
            $(this.resultEl).append(this.searchTemplate());
        },
        toggleFilter: function() {
            if ($('#searchPage').css('display') === "none") {
                $('#searchPage').show();
                $('#searchFilter').hide();
                hideHeaderButtons();
                toggleBackButton();
            } else {
                $('#searchFilter').show();
                $('#searchPage').hide();
                showHeaderButtons(false, true, "Reset", "Done");
                toggleBackButton();
            }
        },
        backButtonAction: function() {
            this.toggleFilter();
        },

        rightbuttonAction: function() {
            this.toggleFilter();
        },
        render: function(options) {
            this.$el.html(this.template());
            this.delegateEvents(this.events);

            $('#advancedSearchContainer').hide();
            $('#basicSearchContainer').show();

            var searchArray = [];

            if (options) {
                var params = options.split('&');
                params.forEach(function(item) {
                    var temp = item.split("=");
                    var searchObj = {};
                    searchObj.type = temp[0];
                    searchObj.query = temp[1];
                    searchArray.push(searchObj);
                });
            }

            if (searchArray.length == 1) {
                $('#selectSearchType').val(searchArray[0].type);
                $('#input_search_value').val(searchArray[0].query);
                this.doSearch(searchArray);
            } else if (searchArray.length > 1) {
                this.showAdvancedSearch();
                this.doSearch(searchArray);
            } else {
                this.showBasicSearch();
            }
            return this;
        },

        basicSearch: function(element) {
            //this.goTo("#search?" + $('#selectSearchType').val() + "=" + $('#input_search_value').val());
            var data = {
                "Cifa_Item_Number": "",
                "Category": "",
                "Description": "",
                "ManufacturerPartNumber": "",
                "Manufacturer": "",
                "Supplier": "",
                "Project": "",
                "Task": "",
                "LastUpdateDate": "",
                "RequestorUserName": getUsername(),
                "RegionName": "",
                "TemplateName": ""
            };


            if (element.currentTarget.id === "btnCatalogSearch") {
                data[$('#selectSearchType').val()] = $('#input_search_value').val();
            } else {
                data[$('#selectSearchType_mobile').val()] = $('#input_search_value_mobile').val();
            }
            this.collection.fetchData(data);
        },

        advancedSearch: function() {
            var data = {
                "Cifa_Item_Number": $("#input_cifa_item_no").val(),
                "Category": $("#input_cat").val(),
                "Description": $("#input_desc").val(),
                "ManufacturerPartNumber": $("#input_man_part").val(),
                "Manufacturer": "",
                "Supplier": "",
                "Project": $("#input_proj_no").val(),
                "Task": $("#input_task_no").val(),
                "LastUpdateDate": "",
                "RequestorUserName": getUsername(),
                "RegionName": "",
                "TemplateName": ""
            };
            this.collection.fetchData(data);
            // var url = "#search?" +
            //     "Cifa_Item_Number=" + $("#input_cifa_item_no").val() +
            //     "&Category=" + $("#input_cat").val() +
            //     "&Description=" + $("#input_desc").val() +
            //     "&ManufacturerPartNumber=" + $("#input_man_part").val() +
            //     "&Manufacturer=" + $("#input_line_bu").val() +
            //     //"&Supplier=" + $("input_cifa_item_no").val() +
            //     "&Project=" + $("#input_proj_no").val() +
            //     "&Task=" + $("#input_task_no").val()
            //     //"&LastUpdateDate=" + $("input_cifa_item_no").val() +
            //     //"&RequestorUserName=" + $("input_cifa_item_no").val() +
            //     //"&TemplateName=" + $("input_cifa_item_no").val()
            // this.goTo(url);
        },

        doSearch: function(searchArray) {

            var data = {
                "Cifa_Item_Number": "",
                "Category": "",
                "Description": "",
                "ManufacturerPartNumber": "",
                "Manufacturer": "",
                "Supplier": "",
                "Project": "",
                "Task": "",
                "LastUpdateDate": "",
                "RequestorUserName": getUsername(),
                "RegionName": "",
                "TemplateName": ""
            };

            searchArray.forEach(function(item) {
                data[item.type] = item.query;
            }, this);

            this.collection.fetchData(data);
        },

        renderResults: function(data) {
            var _this = this;
            if (data.isEmpty()) {
                $(this.resultEl).empty();
                $(this.resultEl).append(this.emptyTemplate());
            } else {
                $(this.resultEl).empty();
                data.models.forEach(function(model) {
                    var item = model.toJSON();
                    $(_this.resultEl).append(_this.resultTemplate(item));
                    var spin_id = "#numspinner_" + item.CIFA_ITEM_NUMBER;

                    var min_val = (item.MinimumOrder === null) ? 1 : item.MinimumOrder;
                    var max_val = (item.MaximumOrder === null) ? 2147483647 : item.MaximumOrder;
                    var interval = (item.FixedLot === null) ? 1 : item.FixedLot;

                    var options = {
                        initval: min_val,
                        min: min_val,
                        max: max_val,
                        step: interval
                    }
                    $(spin_id).TouchSpin(options);
                });

                if (isPhoneGap()) {
                    $('.dateinput').click(function() {
                        //console.log("focus firing");
                        var options = {
                            date: new Date(),
                            mode: 'date',
                            target: this
                        };

                        datePicker.show(options, function(date) {
                            $(options.target).val(date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate());
                        });
                    });
                } else {
                    $('.dateinput').datepicker({
                        autoclose: true,
                        format: "yyyy-mm-dd",
                        startDate: new Date()
                    });
                }
            }
            hideLoadingIndicator();
        },

        searchList: function(el) {
            var value = el.currentTarget.value;
            this.renderResults(this.collection.search(value));
        },
        sortList: function(el) {
            $('#filter_result_field').val("");

            /* Uncomment to enable sort */

            var value = el.currentTarget.value;
            this.collection.changeSort(value);
        },

        showBasicSearch: function(el) {
            $('#basicSearchContainerMobile').show();
            $('#advancedSearchContainer').hide();
            $('#basicSearchContainer').show();
            $('#btnSearchAdv').removeClass('btn-selected');
            $('#btnSearchBasic').addClass('btn-selected');
            this.currenttype = "basic";
        },

        showAdvancedSearch: function(el) {
            $('#basicSearchContainerMobile').hide();
            $('#basicSearchContainer').hide();
            $('#advancedSearchContainer').show();
            $('#btnSearchBasic').removeClass('btn-selected');
            $('#btnSearchAdv').addClass('btn-selected');
            this.currenttype = "advanced";
        },

        createFavorite: function(element) {
            var selectedTemplate;
            var recordId = $(element.currentTarget).attr("data-id"); //parent().parent().find('.item-number').prop('id')
            //globalize.temp = {};
            //globalize.temp.selectedRecord = recordId;
            var list = this.collection.toJSON();
            selectedTemplate = _.find(list, function(item) {
                return item.CIFA_ITEM_NUMBER === recordId;
            });
            var data = {
                "REQUESTOR_USER_NAME": getUsername(),
                "INVENTORY_ITEM_ID": selectedTemplate.INVENTORY_ITEM_ID,
                "CIFA_ITEM_NUMBER": selectedTemplate.CIFA_ITEM_NUMBER,
                "CATEGORY": selectedTemplate.CATEGORY,
                "MFG_PART_NUMBER": selectedTemplate.MFG_PART_NUMBER,
                "ITEM_DESCRIPTION": selectedTemplate.ITEM_DESCRIPTION,
                "REGION_NAME": selectedTemplate.REGION_NAME,
                "TEMPLATE_NAME": selectedTemplate.TEMPLATE_NAME
            };

            this.model.insertFavorite(data);
        },

        // deleteItem: function(element) {
        //     var selectedTemplate;
        //     var recordId = $(element.currentTarget).attr("data-id");
        //     var _this = this;
        //     var list = this.collection.toJSON();
        //     selectedTemplate = _.find(list, function(item) {
        //         return item.CIFA_ITEM_NUMBER === recordId;
        //     });
        //     var input = {
        //         REQUESTOR_USER_NAME: selectedTemplate.REQUESTOR_USER_NAME,
        //         CIFA_ITEM_NUMBER: selectedTemplate.CIFA_ITEM_NUMBER
        //     };
        //     this.model.fetch({
        //         data: JSON.stringify(input),
        //         type: 'POST',
        //         success: function(model, respose, options) {
        //             modalMsg(respose.DeleteFavoriteOutput.STATUS_MESSAGE, "success");
        //             _this.collection.fetchData();
        //         },
        //         error: function(model, xhr, options) {
        //             modalMsg(respose.DeleteFavoriteOutput.STATUS_MESSAGE, "error");
        //             console.log("Something went wrong while saving the model");
        //         }
        //     });
        // },

        goToSelectSource: function(element) {
            var itemId = $(element.currentTarget).attr("data-id");
            var favItem = this.collection.find(function(model) { return model.get('CIFA_ITEM_NUMBER') === itemId; }).toJSON();

            favItem.quantity = $(element.currentTarget).closest('section').find('.selectQuantity').val();
            favItem.needByDate = $(element.currentTarget).closest('section').find('.needByDate').val();

            localStorage.setItem("currentFavItem", JSON.stringify(favItem));
            window.location.href = "#select_source?=" + itemId;
        },

        addToCart: function(element) {
            var itemId = $(element.currentTarget).attr("data-id");
            var favItem = this.collection.find(function(model) { return model.get('CIFA_ITEM_NUMBER') === itemId; }).toJSON();

            var userData = JSON.parse(sessionStorage.getItem('_id'));
            var username = userData.sub;
            // var needbyDate = localStorage.getItem('needbyDate') + "T00:00:00";
            var needbydatevalue = $("#date-needby_" + itemId).val() + "T00:00:00";

            var cartInputData = {
                "ShoppingCartUpsertData": [{
                    "CIFA_ITEM_NUMBER": favItem.CIFA_ITEM_NUMBER,
                    "ITEM_DESC": favItem.ITEM_DESCRIPTION,
                    "ITEM_CATEGORY": favItem.CATEGORY,
                    "QUANTITY": $("#numspinner_" + favItem.CIFA_ITEM_NUMBER).val(),
                    "NEED_BY_DATE": needbydatevalue,
                    "USER_NAME": getUsername()
                }]
            }
            showLoadingIndicator();
            this.cartmodel.addToCartRequest(cartInputData);
        },

        goToItemDetails: function(element) {
            var itemId = element.currentTarget.id;
            var favItem = this.collection.find(function(model) { return model.get('CIFA_ITEM_NUMBER') === itemId; }).toJSON();

            favItem.quantity = $(element.currentTarget).closest('section').find('.selectQuantity').val();
            favItem.needByDate = $(element.currentTarget).closest('section').find('.needByDate').val();

            localStorage.setItem("currentFavItem", JSON.stringify(favItem));
            window.location.href = "#item_details?=" + itemId;
            //new ItemDetailsView().model.fetchData(itemId);
        },

    });

    return SearchView;
});