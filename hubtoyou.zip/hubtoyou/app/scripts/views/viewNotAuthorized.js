/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'helper'
], function($, _, Backbone, JST, helper) {
    'use strict';

    var viewNotAuthorized = Backbone.View.extend({
        template: JST['app/scripts/templates/notauthorized.ejs'],

        el: '#container',

        //tagName: 'div',

        viewName: 'notAuthorizedView',

        id: '',

        className: '',

        events: {

        },

        // initialize: function () {
        //   //this.router = this.options.router;
        //   //this.listenTo(this.model, 'change', this.render);
        //   this.render();
        // },

        render: function() {
            this.$el.html(this.template());
            this.delegateEvents(this.events);
            hideLoadingIndicator();
            return this;
        },
    });

    return viewNotAuthorized;
});