/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'helper'
], function($, _, Backbone, JST, helper) {
    'use strict';

    var OfflineLoginView = Backbone.View.extend({
        template: JST['app/scripts/templates/loginoffline.ejs'],

        el: '#container',

        //tagName: 'div',

        viewName: 'OfflineLoginView',

        id: '',

        className: '',

        events: {
            'click #loginBtn': 'goOffline',
            //'click #btnCheckAjax': 'checkAjax'
        },

        // initialize: function () {
        //   //this.router = this.options.router;
        //   //this.listenTo(this.model, 'change', this.render);
        //   this.render();
        // },

        render: function() {
            var lastUser = localStorage.getItem("lastUsedBy");
            this.$el.html(this.template());
            if (lastUser != null) {
                //userProfile = JSON.parse(lastUser);
                $("#txt_username").val(lastUser);
            }
            this.delegateEvents(this.events);
            return this;
        },



        goOffline: function() {
            var username = $('#txt_username').val().trim().toLowerCase();
            if (username != "") {
                offlineDB.getAllData("profile", username, function(items) {
                    if (items.length > 0) {
                        sessionStorage.setItem("offlineUser", username);
                        sessionStorage.setItem("loggedIn", true);
                        window.location.href = "#home";
                    } else {
                        //alert("No offline data available for the user");
                        modalMsg("No offline data available for the user", "error");
                    }
                });
            } else {
                //alert("Please enter a valid username");
                modalMsg("Please enter a valid username", "error");
                return;
            }
        }

    });
    return OfflineLoginView;
});