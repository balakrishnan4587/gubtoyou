/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/searchntusername',
    'models/addntusername',
], function($, _, Backbone, JST, SearchNTUsernameModel, AddNTUserNameModel) {
    'use strict';

    var ResponseAddUserView = Backbone.View.extend({
        template: JST['app/scripts/templates/adminresponseadduser.ejs'],
        resultsntusertemplate: JST['app/scripts/templates/adminsearchadduser.ejs'],
        viewName: 'viewAddNTUserName',
        el: '#container',
        tagName: 'div',
        id: '',
        className: '',
        inputData: {},
        applicationid: 1,
        events: {
            'click #addusersearch': 'searchNTUserName',
            'change #ntusernameinput': 'updateNTUserNameINput',
            'click .selectRecordRow': 'selectRecord',
            'click #NTUserAddBtn': 'AddNTUserName',
            'click .gotoback': 'backToAdmin'
        },
        initialize: function() {
            if (AppView.currentView !== undefined) {
                globalPreviousView = AppView.currentView;
            }
            AppView.currentView = this;
            this.loginUserName = getUsername();
            this.searchntusermodel = new SearchNTUsernameModel();
            this.addntusermodel = new AddNTUserNameModel();
            this.listenTo(this.searchntusermodel, 'sync', this.renderSearchNTUserResult);
            this.listenTo(this.addntusermodel, 'sync', this.renderAfterAddNTUsername);
            this.render();

        },
        render: function() {
            this.$el.html(this.template());
            disableDone();
            this.delegateEvents(this.events);
            return this;
        },
        updateNTUserNameINput: function(event) {
            this.inputData.NTUsernameValue = event.currentTarget.value;
            this.validateSearchButton(this.inputData);
        },
        validateSearchButton: function(value) {
            if (isValid(value.NTUsernameValue)) {
                this.$el.find('#addusersearch').removeClass('button-disable-opacity');
                return;
            } else {
                this.$el.find('#addusersearch').addClass('button-disable-opacity');
            }
        },
        searchNTUserName: function() {
            var dataInput = {
                "USER_NAME": this.inputData.NTUsernameValue
            }
            showLoadingIndicator();
            this.searchntusermodel.fetchNTUserName(dataInput);
        },
        renderSearchNTUserResult: function(data) {
            var searchdata = data.responseNTUserData;
            enableDone();
            this.$el.find('#loadNTUsernameData').html(this.resultsntusertemplate(searchdata));
            hideLoadingIndicator();
        },
        /* Record selection from table */
        selectRecord: function(element) {

            var selectId = $(element.currentTarget).prop('id');
            var cur_row = selectId.split("_");
            $("#radioBtn_" + cur_row[1]).prop("checked", true);
            $(".mobile-select-btn").addClass("hidden");
            $("#mob-row_" + cur_row[1]).removeClass("hidden");
            enableDone();
            var NTuserid = cur_row[1];
            var NTusername = $("#ntusername_" + cur_row[1]).text();

            this.NTuserid = NTuserid;
            this.NTusername = NTusername;

        },
        AddNTUserName: function() {
            var funid = sessionStorage.getItem('selectedFunctionID');
            var dataInput = {
                "XxcmstAdfFunctionAccess": [{
                    "functionId": funid,
                    "UserName": this.NTusername,
                    "applicationId": this.applicationid,
                    "RequestorName": this.loginUserName
                }]
            }
            showLoadingIndicator();
            this.addntusermodel.addNTUserName(dataInput);

        },
        renderAfterAddNTUsername: function(data) {
            var response = data.addNTUserData;
            hideLoadingIndicator();
            if (response.STATUS == "SUCCESS") {
                modalMsg(response.STATUS_MESSAGE, "success");
                window.location.href = "#administration";
            } else {
                modalMsg(response.STATUS_MESSAGE, "error");
            }
        },
        backToAdmin: function() {
            var len = breadCrumbs.length;
            breadCrumbs.splice(len - 1, 1);
            updateBreadCrumbs();
            window.location.href = "#administration";

        },
        backButtonAction: function() {
            var len = breadCrumbs.length;
            breadCrumbs.splice(len - 1, 1);
            updateBreadCrumbs();
            window.location.href = "#administration";
            removeBackButton();
            hideHeaderButtons();
        },
        rightbuttonAction: function() {
            this.AddNTUserName();
        }

    });

    return ResponseAddUserView;
});