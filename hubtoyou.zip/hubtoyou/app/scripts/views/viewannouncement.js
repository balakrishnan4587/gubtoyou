/*globalize*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/viewannouncement'
], function($, _, Backbone, JST, AnnouncementModel) {
    'use strict';

    var ViewAnnouncementView = Backbone.View.extend({
        template: JST['app/scripts/templates/viewannouncement.ejs'],
        el: '.render-container',
        id: '',

        className: '',

        events: {
            'click #allCHK': 'annoucementSelectAll',
            'click .select-item': 'selectRecordToDelete',
            'click #deleteUnpublished': 'deleteUnpublishedAnnouncement',
            'click .acknowledge-click': 'acknowldgeAnnouncement'
        },

        initialize: function() {
            this.model = new AnnouncementModel();
            //this.regionsModel = new RegionList();
            this.modelDelete = new AnnouncementModel(); //delete button service
            this.modelAcknowledge = new AnnouncementModel(); //delete button service
            //this.revokeAnnouncementModel = new CreateAlertModel(); //revoke service
            this.listenTo(this.model, 'sync', this.render);
            //this.listenTo(this.regionsModel, 'sync', this.renderAfterRegionList);
            this.listenTo(this.modelDelete, 'sync', this.renderAfterDelete);
            //this.listenTo(this.newAlertModel, 'sync', this.resultAfterCreation);
            //this.listenTo(this.revokeAnnouncementModel, 'sync', this.resultAfterRevoke);
            var data = {
                "NTAccount": getUsername(),
                "APPLICATION_ID": 1
            };
            showLoadingIndicator()
            this.model.getAlertList(data);
            //this.render();

        },
        deleteAnnouncementInput: [],
        render: function(data) {
            this.$el.html(this.template(this.model.responseData));
            if (isPhoneGap()) {
                $('.dateinput').click(function() {
                    var options = {
                        date: new Date(),
                        mode: 'date',
                        target: this
                    };

                    datePicker.show(options, function(date) {
                        $(options.target).val(date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate());
                    });
                });
            } else {
                $('.dateinput').datepicker({
                    autoclose: true,
                    format: "yyyy-mm-dd",
                    startDate: new Date()
                });
            }
            hideLoadingIndicator();
            this.deleteAnnouncementInput = [];
        },


        annoucementSelectAll: function(element) {
            //sample code to select all checkbox and iterate list for data
            var list = this.model.toJSON().AnnouncementsForUserListOutput;
            if (!isValid(list)) {
                return false;
            }
            if ($(element.currentTarget).prop('checked')) {

                this.deleteAnnouncementInput = [];

                for (var i = 0; i < list.length; i++) {
                    $("#select_" + list[i].RECORD_ID).prop("checked", element.currentTarget.checked);
                    $('.delete-style').removeClass('button-disable-opacity');
                    var tempObj = {};
                    // if (list[i].CREATED_BY == "edipperfuser05") {
                    tempObj.RECORD_ID = list[i].RECORD_ID;
                    tempObj.APPLICATION_ID = list[i].APPLICATION_ID;
                    tempObj.CREATED_BY = list[i].REQUESTOR_NTID;
                    tempObj.MESSAGE_TYPE = list[i].MESSAGE_TYPE;
                    tempObj.OPERATION = "DELETE";
                    this.deleteAnnouncementInput.push(tempObj);
                    //}
                }
            } else {
                this.deleteAnnouncementInput = [];
                for (var i = 0; i < list.length; i++) {
                    $("#select_" + list[i].RECORD_ID).prop("checked", element.currentTarget.checked);
                    $('.delete-style').addClass('button-disable-opacity');
                }
            }
            console.log(this.deleteAnnouncementInput);
        },

        selectRecordToDelete: function(element) {
            var selectedTemplate;
            var selectId = $(element.currentTarget).prop('id');
            var cur_row = selectId.split("_");
            var list = this.model.toJSON().AnnouncementsForUserListOutput;
            selectedTemplate = _.find(list, function(item) {
                return item.RECORD_ID === cur_row[1];
            });
            var tempObj = {};
            tempObj.RECORD_ID = selectedTemplate.RECORD_ID;
            tempObj.APPLICATION_ID = selectedTemplate.APPLICATION_ID;
            tempObj.CREATED_BY = selectedTemplate.REQUESTOR_NTID;
            tempObj.MESSAGE_TYPE = selectedTemplate.MESSAGE_TYPE;
            tempObj.OPERATION = "DELETE";

            if ($(element.currentTarget).prop('checked')) {
                this.deleteAnnouncementInput.push(tempObj);
            } else {
                var _this = this;
                $('#allCHK').prop('checked', false);
                this.deleteAnnouncementInput.forEach(function(item, index) {
                    if (item.RECORD_ID == cur_row[1]) {
                        _this.deleteAnnouncementInput.splice(index, 1);
                    }
                });

            }
            if (this.deleteAnnouncementInput.length > 0) {
                $('.delete-style').removeClass('button-disable-opacity');
            } else {
                $('.delete-style').addClass('button-disable-opacity');
            }
        },
        deleteUnpublishedAnnouncement: function() {
            var dataInput = {
                    "DeleteAnnouncementsDetails": this.deleteAnnouncementInput
                }
                //console.log(dataInput);
            showLoadingIndicator();
            this.modelDelete.deleteAnnouncement(dataInput);
        },
        renderAfterDelete: function(response) {
            modalMsg(response.responseData.STATUS_MESSAGE, "success");
            this.deleteAnnouncementInput = [];
            var data = {
                "NTAccount": getUsername(),
                "APPLICATION_ID": 1
            };
            this.model.getAlertList(data); //reload list
        },

        selectRecordInmobile: function(element) {
            //yet to do
        },
        acknowldgeAnnouncement: function(element) {
            var selectedTemplate;
            var selectId = $(element.currentTarget).prop('id');
            var cur_row = selectId.split("_");
            var list = this.model.toJSON().AnnouncementsForUserListOutput;
            selectedTemplate = _.find(list, function(item) {
                return item.RECORD_ID === cur_row[1];
            });
            var dataInput = {
                "AcknowledgeAnnouncementsInput": [{
                    "RECORD_ID": selectedTemplate.RECORD_ID,
                    "APPLICATION_ID": selectedTemplate.APPLICATION_ID,
                    "OPERATION": "ACKNOWLEDGE"
                }]
            };
            showLoadingIndicator();
            var model = new AnnouncementModel();
            model.acknowledgeAnnouncement(dataInput);
        }

    });

    return ViewAnnouncementView;
});