/**/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'collections/report',
    'models/report',
    'routes/app_router',
    'views/reportrequisitiondetails'
], function($, _, Backbone, JST, HomeCollection, ReportModel, Router, ReportRequisitionView) {
    'use strict';

    var HomeView = Backbone.View.extend({
        template: JST['app/scripts/templates/reports.ejs'],
        requisitionList: JST['app/scripts/templates/reportrequisitions.ejs'],
        noRecords: JST['app/scripts/templates/norecords.ejs'],
        filterTemplate: JST['app/scripts/templates/filterrequisition.ejs'],
        //el: $('#page'),
        collection: new HomeCollection(),
        el: '#container',
        viewName: 'reportView',
        serviceData: {},
        events: {
            'click .select-all': 'selectAllFilters',
            'click .select-all-mobile': 'selectAllFilters',
            'click .home-checkbox': 'filterList',
            'click .home-checkbox-mobile': 'selectParticularFilter',
            'click #loadHomeFilter': 'routeTOFilter',
            'click #doneFilter': 'filterListMobile',
            'click #btnReportSearch': 'searchReport',
            'change #rt_reqNO': 'updateReqNo',
            'change #rt_isoNo': 'updateISONo',
            'change #rt_Desc': 'updateDesc',
            'change #rt_status': 'updateStatus',
            'changeDate #rt_sdate': 'updateSD',
            'change #rt_sdate': 'updateSDMobile',
            'changeDate #rt_edate': 'updateED',
            'change #rt_edate': 'updateEDMobile',
            'click .req-list-item': 'goToRequisitionDetails',

            "scroll": "detect_scroll",
            'click #btn_scroll_top': function() {
                $("html, body").animate({ scrollTop: 0 }, 300);
                return false;
            }
        },

        initialize: function(options) {
            //AppView.setCurrentView(this);
            globalView = this;
        },

        showData: function(data) {
            //console.log('showdata');
        },
        renderMain: function() {
            this.$el.html(this.template());
            this.searchReqInput = {};
            $('.filter-group').hide();
            this.$el.find('.reports-page').find('#requition-list').append(this.noRecords());
            $('#filterviewPage').hide();
            this.model = new ReportModel();
            this.listenTo(this.model, 'change', this.render);
            //this.collection.on('sort', this.render, this);
            // this.collection.on('reset', this.render, this);
            _.bindAll(this, 'detect_scroll');
            $(window).scroll(this.detect_scroll);
            if (isPhoneGap()) {
                $('.dateinput').focus(function() {
                    var options = {
                        date: new Date(),
                        mode: 'date',
                        target: this
                    };

                    datePicker.show(options, function(date) {
                        $(options.target).val(date.getDate() + '-' + (date.getMonth() + 1) + '-' + date.getFullYear());
                        $(options.target).trigger("change");
                    });
                });
            } else {
                $('.dateinput').datepicker({
                    autoclose: true,
                    format: "mm/dd/yyyy"
                });
            }
            this.delegateEvents(this.events);
        },

        render: function(data) {
            var _this = this;
            this.$list = this.$el.find('.reports-page').find('#requition-list');
            this.$list.empty();
            if (!_.isUndefined(data) && !_.isUndefined(data.reportResponse) && data.reportResponse.length > 0) {
                var responsearray = data.reportResponse;
                var user = getUsername();
                if (isOnline) {
                    offlineDB.clearData("requisitions", user);
                }
                responsearray.forEach(function(model) {
                    $(_this.$list).append(_this.requisitionList(model));
                    // if (isOnline && offlineDB) {
                    //     var item = model.toJSON();
                    //     item.username = user;
                    //     offlineDB.addData("requisitions", user, item);
                    // }
                });
                $('.filter-group').show();
            } else {
                this.$el.find('.reports-page').find('#requition-list').append(this.noRecords());
            }
            this.delegateEvents(this.events);
            hideLoadingIndicator();
            if (isOnline) {
                offlineDB.syncOfflineCart("sjayan001c", this.syncOfflineCartItems, this);
            }

        },
        searchReport: function() {
            var sd = new Date(this.searchReqInput.sd);
            var ed = new Date(this.searchReqInput.ed);
            if (ed <= sd) {
                modalMsg("Start Date should be less than End Date", "error");
                return;
            } else {
                showLoadingIndicator();
                this.model.fetchData(this.searchReqInput);
            }
        },
        updateReqNo: function(element) {
            this.searchReqInput.reqNo = element.currentTarget.value;
            this.validateSearchButton(this.searchReqInput);
        },
        updateISONo: function(element) {
            this.searchReqInput.iso = element.currentTarget.value;
            this.validateSearchButton(this.searchReqInput);
        },
        updateStatus: function(element) {
            this.searchReqInput.status = element.currentTarget.value;
            this.validateSearchButton(this.searchReqInput);
        },
        updateSD: function(element) {
            this.searchReqInput.sd = element.currentTarget.value;

            // $('#rt_edate').datepicker({
            //     autoclose: true,
            //     format: "mm/dd/yyyy",
            //     startDate: new Date(element.currentTarget.value)

            // });
            this.validateSearchButton(this.searchReqInput);
        },
        updateED: function(element) {
            this.searchReqInput.ed = element.currentTarget.value;
            this.validateSearchButton(this.searchReqInput);
        },
        updateSDMobile: function(element) {
            this.searchReqInput.sd = $('#rt_sdate').val();
            this.validateSearchButton(this.searchReqInput);
        },
        updateEDMobile: function() {
            this.searchReqInput.ed = $('#rt_edate').val();
            this.validateSearchButton(this.searchReqInput);
        },
        updateDesc: function(element) {
            this.searchReqInput.desc = element.currentTarget.value;
            this.validateSearchButton(this.searchReqInput);
        },
        validateSearchButton: function(value) {
            if (isValid(value.reqNo) || isValid(value.iso) || isValid(value.sd) ||
                isValid(value.ed) || isValid(value.desc) || isValid(value.status)) {
                this.$el.find('#btnReportSearch').removeClass('button-disable-opacity');
                return;
            } else {
                this.$el.find('#btnReportSearch').addClass('button-disable-opacity');
            }
        },
        syncOfflineCartItems: function(items, me) {
            if (items.length > 0) {
                var data = {
                    "ShoppingCartUpsertData": []
                }
                modalMsg("Items added to cart while you were offline will be added to your cart", "success");
                items.forEach(function(item) {
                    data.ShoppingCartUpsertData.push(item[0]);
                }, this);
                //console.log(data);
                me.cartmodel.addToCartRequest(data, me.addToCartCallback);
            }
        },

        addToCartCallback: function(status) {
            if (status === "success") {
                var user = getUsername();
                offlineDB.clearData("CARTOFFLINE", user);
            }
        },
        routeTOFilter: function() {
            //window.location.href = "#homeFilter"; //changed to not to go thrugh router.
            $('#homeviewPage').hide();
            $('#filterviewPage').show();
            setTitle("Filter", "");
            //AppView.currentView = this;
            toggleBackButton();
        },
        displayString: "All",
        displayFilterArray: [],
        filterObjMobile: {},
        //Select particular filer in mobile
        selectParticularFilter: function(element) {
            this.filterObjMobile = {
                approved: $('#mob_approvedCHK').prop('checked'),
                pending: $('#mob_pendingCHK').prop('checked'),
                declined: $('#mob_declinedCHK').prop('checked')
            };
            if (this.filterObjMobile.approved && this.filterObjMobile.declined && this.filterObjMobile.pending) {
                $('#mob_allCHK').prop('checked', true);
                this.filterObjMobile.all = true;
            } else if (!this.filterObjMobile.approved && !this.filterObjMobile.declined && !this.filterObjMobile.pending) {
                $('#mob_allCHK').prop('checked', false);
                this.filterObjMobile.all = false;
            } else {
                $('#mob_allCHK').prop('checked', false);
            }
        },
        //filter confirm in mobile view
        filterListMobile: function() {
            if (this.filterObjMobile.all) {
                this.render(this.collection);
                $('.current-filter-text').text("All");
            } else {
                this.displayFilterArray = [];
                if (this.filterObjMobile.approved) {
                    this.displayFilterArray.push("Approved");
                }
                if (this.filterObjMobile.pending) {
                    this.displayFilterArray.push("Pending");
                }
                if (this.filterObjMobile.declined) {
                    this.displayFilterArray.push("Declined");
                }
                this.render(this.collection.search(this.filterObjMobile));
                this.displayString = this.displayFilterArray.join(", ");
                $('.current-filter-text').text(this.displayString);
            }

            $('#filterviewPage').hide();
            $('#homeviewPage').show();
            toggleBackButton();
            setTitle(globalize.home, "icon-home");
            //this.goTo("home",this.collection);
            //this.render(this.collection.search(filterObj));
        },
        //Mobile view select all checkbox logic
        selectAllFilters: function(element) {
            if ($(window).width() > 767) {
                if (element.currentTarget.checked) {
                    $('.home-checkbox').each(function() {
                        this.checked = true;
                    });
                    this.render(this.collection);
                } else {
                    $('.home-checkbox').each(function() {
                        this.checked = false;
                    });
                    this.$list.empty();
                    this.$el.find('.home-page').find('#requition-list').append(this.noRecords());
                }
            } else {
                if (element.currentTarget.checked) {
                    $('.home-checkbox-mobile').each(function() {
                        this.checked = true;
                    });
                } else {
                    $('.home-checkbox-mobile').each(function() {
                        this.checked = false;
                    });
                }
                this.filterObjMobile = {
                    approved: $('#mob_approvedCHK').prop('checked'),
                    pending: $('#mob_pendingCHK').prop('checked'),
                    declined: $('#mob_declinedCHK').prop('checked'),
                    all: $('#mob_allCHK').prop('checked')
                }
            }
        },
        //Desktop filter action
        filterList: function(element) {
            var filterObj = {
                approved: $('#approvedCHK').prop('checked'),
                pending: $('#pendingCHK').prop('checked'),
                declined: $('#declinedCHK').prop('checked')
            };
            if (filterObj.approved && filterObj.declined && filterObj.pending) {
                $('#allCHK').prop('checked', true);
                this.render(this.collection);
            } else {
                if (!filterObj.approved && !filterObj.declined && !filterObj.pending) {
                    $('#allCHK').prop('checked', false);
                    this.$list.empty();
                    this.$el.find('.home-page').find('#requition-list').append(this.noRecords());
                } else {
                    $('#allCHK').prop('checked', false);
                    this.render(this.collection.search(filterObj));
                }
            }
        },
        goToRequisitionDetails: function(event) {
            event.stopPropagation();
            globalize.reportsPage = true;
            var selectId = $(event.currentTarget).prop('id');
            var cur_row = selectId.split("_");
            var selectedTemplate = _.find(this.model.toJSON().ReportOutput, function(item) {
                return item.REQUISITION_NUMBER === cur_row[1];
            });
            //code changes for mahesh requriement
            $('.reports-page').hide();
            showBackButton();
            localStorage.setItem("reqHeaderItemData", JSON.stringify(selectedTemplate));
            breadCrumbs.push({
                "name": "Requisition Details",
                "href": "#reports"
            });

            updateBreadCrumbs();
            setTitle("Line Details", "");
            var requisitionDetailsView = new ReportRequisitionView();
            this.childView = requisitionDetailsView;
            //AppView.setCurrentView(requisitionDetailsView);
            showLoadingIndicator();
            requisitionDetailsView.model.fetchData(cur_row[1]);
            //ends

            //old code
            // localStorage.setItem("reqHeaderItemData", JSON.stringify(selectedTemplate));
            // this.goTo("#requisitionDetail?=" + cur_row[1])
            // setTitle("Line Details", "");
            // previousView = "reports"; //navigation to report after back btn in req deatils screen
            // showBackButton();
        },
        backButtonAction: function() {
            if (globalize.feedbackView) {
                $('.load-feedback').empty();
                $('.requisition-details-page').show();
                setTitle("Line Details", "");
                globalize.feedbackView = false;
                return;
            }
            if (globalize.reportsPage) {
                $('#filterviewPage').hide();
                $('#homeviewPage').show();
                hideHeaderButtons();
                setTitle("Reports", "");
                removeBackButton();
            }
        },
        detect_scroll: function(event) {
            if ($(window).scrollTop() > 0) {
                $('#btn_scroll_top').fadeIn();
            } else {
                $('#btn_scroll_top').fadeOut();
            }
        },

        onClose: function() {
            //console.log("closing reports");
        }
    });

    return HomeView;
});