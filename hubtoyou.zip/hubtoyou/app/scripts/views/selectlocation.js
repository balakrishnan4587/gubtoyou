/*globalize*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/searchwarehouse'
], function($, _, Backbone, JST, SearchWarehouseModel) {
    'use strict';

    var SelectSourceView = Backbone.View.extend({
        template: JST['app/scripts/templates/selectlocation.ejs'],
        searchWarehouseTemplate: JST['app/scripts/templates/searchwarehouse.ejs'],
        el: '#projectNoSearch',
        id: '',

        className: '',

        events: {
            'click #search': 'search',
            'click .backBtnSettings': 'closeSearchWindow',
            'click .selectRecordRow': 'selectRecord',
            'click #PopulateProjectNumber': 'populateProjectNumber',
            'change #orgCodeInput': 'updateOrgCode',
            'change #locCodeInput': 'updateLocCode',
            'change #descInput': 'updateDesc'
        },

        initialize: function() {
            if (AppView.currentView !== undefined) {
                globalPreviousView = AppView.currentView;
            }
            AppView.currentView = this;
            this.wareHouseDetails = new SearchWarehouseModel();
            this.render();
            disableDone();
            this.listenTo(this.wareHouseDetails, 'change', this.renderTable); //search for locations      
        },

        render: function() {
            this.$el.html(this.template());
        },
        inputData: {},
        /*Search button validating the input fields*/
        validateSearchButton: function(value) {
            if (isValid(value.orgCodeValue) || isValid(value.locCodeValue) || isValid(value.descCodeValue)) {
                //this.$el.find('.button-white').removeClass('button-disable-opacity');
                return;
            } else {
                //this.$el.find('.button-white').addClass('button-disable-opacity');
            }
        },
        /*USer input updation in location/warehouse window*/
        updateOrgCode: function(event) {
            this.inputData.orgCodeValue = event.currentTarget.value;
            this.validateSearchButton(this.inputData);
        },
        updateLocCode: function(event) {
            this.inputData.locCodeValue = event.currentTarget.value;
            this.validateSearchButton(this.inputData);
        },
        updateDesc: function(event) {
            this.inputData.descCodeValue = event.currentTarget.value;
            this.validateSearchButton(this.inputData);
        },

        search: function() {
            if (globalize.selectedWIndow == "selectSourceWarehouse" || globalize.selectedWIndow == "selectDeliveryLocation") {
                var dataInput = {
                    "ORGANIZATION_CODE": this.inputData.orgCodeValue,
                    //  "LOCATION_DISPLAY" : data.orgCodeValue,
                    "DESCRIPTION": this.inputData.descValue,
                    "LOCATION_CODE": this.inputData.locCodeValue
                }
                showLoadingIndicator();
                this.wareHouseDetails.fetchData(dataInput);
            }
        },
        renderTable: function() {
            if (globalize.selectedWIndow == "selectSourceWarehouse" || globalize.selectedWIndow == "selectDeliveryLocation") {
                this.$el.find('.load-results').html(this.searchWarehouseTemplate(this.wareHouseDetails.toJSON()));
                hideLoadingIndicator();
                $('[data-toggle="tooltip"]').tooltip();
            }
        },
        /* Record selection from table */
        selectRecord: function(element) {
            var selectedTemplate;
            var selectId = $(element.currentTarget).prop('id');
            var cur_row = selectId.split("_");
            $("#radioBtn_" + cur_row[1]).prop("checked", true);
            $(".mobile-select-btn").addClass("hidden");
            $("#mob-row_" + cur_row[1]).removeClass("hidden");


            if (globalize.selectedWIndow == "selectSourceWarehouse") {
                var orgNO = $("#orgCode_" + cur_row[1]).text();
                var list = this.wareHouseDetails.toJSON().EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput;
                selectedTemplate = _.find(list, function(item) {
                    return item.ORGANIZATION_CODE === orgNO;
                });
                this.selectedTemplate = selectedTemplate;
                this.selectedCode = selectedTemplate.ORGANIZATION_CODE;
            }
            if (globalize.selectedWIndow == "selectDeliveryLocation") {
                var orgNO = $("#orgCode_" + cur_row[1]).text();
                var list = this.wareHouseDetails.toJSON().EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput;
                selectedTemplate = _.find(list, function(item) {
                    return item.ORGANIZATION_CODE === orgNO;
                });
                this.selectedTemplate = selectedTemplate;
                this.selectedCode = selectedTemplate.LOCATION_CODE;
            }
            enableDone(); //added for enabling the heder done method 

        },
        populateProjectNumber: function() {
            if (globalize.selectedWIndow == "selectSourceWarehouse") {
                $(globalize.srcInputBox).removeClass('contain-error');
                $(globalize.srcInputBox).val(this.selectedCode);
                /* update cart details json */
                var keyparam = $(globalize.srcInputBox).data("keyparam");
                var lineno = $(globalize.srcInputBox).data("lineno");
                var updatevalue = this.selectedCode;
                saveCartDetails(keyparam, updatevalue, lineno);
                /* update cart details json */

            }
            if (globalize.selectedWIndow == "selectDeliveryLocation") {
                $(globalize.deliveryLocInputBox).removeClass('contain-error');
                $(globalize.deliveryLocInputBox).val(this.selectedCode);
                /* update cart details json */
                var keyparam = $(globalize.deliveryLocInputBox).data("keyparam");
                var lineno = $(globalize.deliveryLocInputBox).data("lineno");
                var updatevalue = this.selectedCode;
                saveCartDetails(keyparam, updatevalue, lineno);
                /* update cart details json */

            }

            this.$el.empty(); //to empty the current loaded page element
            this.close(); //to kill the current view
            updateBreadcrumbsToParent() //to update the parent page breadcrumb
            showHeaderButtons(false, true, "Reset", "Submit");
            if ($('.mobile-update-cart-lines').children().length > 0) {
                $('.mobile-update-cart-lines').show();
                showHeaderButtons(false, true, "", "Done")
                enableDone();
                AppView.currentView = globalView;
                return;
            }
            AppView.currentView = globalView;
            $('#update_submit').removeClass('button-disable-opacity');
            $('.shoppingcart-page').show();
        },
        closeSearchWindow: function(element) {
            $('.shoppingcart-page').show();
            this.$el.empty();
            this.close(); //to kill the current view
            updateBreadcrumbsToParent() //to update the parent page breadcrumb
        },
        backButtonAction: function(element) {
            if (globalize.updateCartLine != undefined && globalize.updateCartLine == true) {
                $('.mobile-update-cart-lines').show();
            } else {
                $('.shoppingcart-page').show();
                showHeaderButtons(false, true, "Reset", "Submit");
                removeBackButton();
            }
            AppView.currentView = globalView;
            //globalHeaderView.delegateEvents(globalHeaderView.events);
            this.$el.empty();
            this.close(); //to kill the current view
            updateBreadcrumbsToParent() //to update the parent page breadcrumb

        },

        rightbuttonAction: function() {
            this.populateProjectNumber();
        }
    });

    return SelectSourceView;
});