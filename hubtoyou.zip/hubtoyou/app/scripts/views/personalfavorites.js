/**/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'globalise',
    'models/personalfavorites',
    'views/itemDetails',
    'collections/personalfavorites',
    'models/addtocart'
], function($, _, Backbone, JST, globalize, PersonalFavModel, ItemDetailsView, PersonalFavoritesCollection, CartModel) {
    'use strict';

    var PersonalFavoritesView = Backbone.View.extend({
        template: JST['app/scripts/templates/personalfavorites.ejs'],
        emptyTemplate: JST['app/scripts/templates/norecords.ejs'],
        collection: new PersonalFavoritesCollection(),
        el: '#favouriteList',
        model: new PersonalFavModel(),
        viewName: 'personalfavoritesView',
        events: {
            'click .select_source': 'loadSelectSource',
            'click .delete_favorite': 'deleteFavorite',
            'click .pers_addto_cart': 'addToCart',
            'click .item-number': 'goToItemDetails'
        },

        initialize: function(options) {
            this.cartmodel = new CartModel();
            this.listenTo(this.collection, 'reset sort', this.render);
        },



        render: function(data) {
            var _this = this;
            this.$el.empty();
            //var objstore = db.transaction([STORE], "readwrite").objectStore(STORE);
            if (data.isEmpty()) {
                this.$el.append(this.emptyTemplate());
                return;
            }
            var user = getUsername();
            if (isOnline) {
                offlineDB.clearData("favorites", user);
            }
            data.models.forEach(function(model) {
                var item = model.toJSON();
                _this.$el.append(_this.template(item));

                if (isOnline && offlineDB) {
                    offlineDB.addData("favorites", user, item);
                }

                var spin_id = "#numspinner_" + item.CIFA_ITEM_NUMBER;

                var min_val = (item.MinimumOrder === null) ? 1 : item.MinimumOrder;
                var max_val = (item.MaximumOrder === null) ? 2147483647 : item.MaximumOrder;
                var interval = (item.FixedLot === null) ? 1 : item.FixedLot;

                var options = {
                    initval: min_val,
                    min: min_val,
                    max: max_val,
                    step: interval
                }
                $(spin_id).TouchSpin(options);
            });


            // for (i = 0; i < data.length; i++) {
            //     objstore.put(data[i]);
            // }
            if (isPhoneGap()) {
                $('.dateinput').click(function() {
                    console.log("focus firing");
                    var options = {
                        date: new Date(),
                        mode: 'date',
                        target: this
                    };

                    datePicker.show(options, function(date) {
                        $(options.target).val(date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate());
                    });
                });
            } else {
                $('.dateinput').datepicker({
                    autoclose: true,
                    format: "yyyy-mm-dd",
                    startDate: new Date()
                });
            }
            hideLoadingIndicator();
        },

        loadSelectSource: function(element) {
            var itemId = $(element.currentTarget).attr("data-id");
            var favItem = this.collection.find(function(model) { return model.get('CIFA_ITEM_NUMBER') === itemId; }).toJSON();

            //favItem.quantity = $("#numspinner_" + favItem.CIFA_ITEM_NUMBER).val();
            //favItem.needByDate = $(element.currentTarget).closest('section').find('.needByDate').val();
            favItem.quantity = $("#numspinner_" + itemId).val();
            favItem.needByDate = $("#date-needby_" + itemId).val();

            localStorage.setItem("currentFavItem", JSON.stringify(favItem));
            this.close();
            this.unbind();
            window.location.href = "#select_source?=" + itemId;
        },

        deleteFavorite: function(element) {
            showLoadingIndicator();
            var selectedTemplate;
            var recordId = $(element.currentTarget).attr("data-id");
            var _this = this;
            var list = this.collection.toJSON();
            selectedTemplate = _.find(list, function(item) {
                return item.CIFA_ITEM_NUMBER === recordId;
            });
            var input = {
                REQUESTOR_USER_NAME: selectedTemplate.REQUESTOR_USER_NAME,
                CIFA_ITEM_NUMBER: selectedTemplate.CIFA_ITEM_NUMBER
            };
            this.model.fetch({
                data: JSON.stringify(input),
                type: 'POST',
                success: function(model, respose, options) {
                    hideLoadingIndicator();
                    modalMsg(respose.DeleteFavoriteOutput.STATUS_MESSAGE, "success");
                    _this.collection.fetchData();
                },
                error: function(model, xhr, options) {
                    hideLoadingIndicator();
                    modalMsg(respose.DeleteFavoriteOutput.STATUS_MESSAGE, "error");
                    console.log("Something went wrong while saving the model");
                }
            });

        },
        goToItemDetails: function(element) {
            var itemId = element.currentTarget.id;
            var favItem = this.collection.find(function(model) { return model.get('CIFA_ITEM_NUMBER') === itemId; }).toJSON();

            favItem.quantity = $("#numspinner_" + itemId).val();
            favItem.needByDate = $("#date-needby_" + itemId).val();

            localStorage.setItem("currentFavItem", JSON.stringify(favItem));
            window.location.href = "#item_details?=" + itemId;
            //new ItemDetailsView().model.fetchData(itemId);
        },


        addToCart: function(element) {
            var itemId = $(element.currentTarget).attr("data-id");
            var favItem = this.collection.find(function(model) { return model.get('CIFA_ITEM_NUMBER') === itemId; }).toJSON();

            var userData = JSON.parse(sessionStorage.getItem('_id'));
            var username = "";
            if (userData != null) {
                username = userData.sub;
            }

            if ($("#date-needby_" + itemId).val() === "") {
                modalMsg("Please select Need By date", "error");
                return;
            }

            var needbydatevalue = $("#date-needby_" + itemId).val() + "T00:00:00";
            //var needbyDate = localStorage.getItem('needbyDate') + "T00:00:00";

            var cartInputData = {
                "ShoppingCartUpsertData": [{
                    "CIFA_ITEM_NUMBER": favItem.CIFA_ITEM_NUMBER,
                    "ITEM_DESC": favItem.ITEM_DESCRIPTION,
                    "ITEM_CATEGORY": favItem.ITEM_CATEGORY,
                    "QUANTITY": $("#numspinner_" + favItem.CIFA_ITEM_NUMBER).val(),
                    "NEED_BY_DATE": needbydatevalue,
                    "USER_NAME": getUsername(),
                    "REGION_TEMPLATE": favItem.TEMPLATE_NAME,
                    "REGION_NAME": favItem.REGION_NAME
                }]
            }
            if (!isOnline) {
                var user = getUsername();
                if (offlineDB) {
                    offlineDB.addData("CARTOFFLINE", user, cartInputData.ShoppingCartUpsertData[0]);
                    modalMsg("Item added to offline cart", "success");
                }
                return;
            }
            showLoadingIndicator();
            this.cartmodel.addToCartRequest(cartInputData);
        },

        onClose: function() {
            console.log(this + "pfav is closed");
        }
    });
    return PersonalFavoritesView;
});