/*globalize*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/announcement',
    'models/adminavailableregions',
    'models/insertannouncement',
    'models/availablemessagetypes'

], function($, _, Backbone, JST, AnnouncementModel, RegionList, CreateAlertModel, MessageTypeList) {
    'use strict';

    var ManageAnnouncementView = Backbone.View.extend({
        template: JST['app/scripts/templates/manageannouncement.ejs'],
        newAlertTemplate: JST['app/scripts/templates/announcementCreate.ejs'],
        editAlertTemplate: JST['app/scripts/templates/announcementedit.ejs'],
        el: '.render-container',
        id: '',

        className: '',

        events: {
            'click #addNewAnnouncement': 'getMessageTypes',
            'click #cancel_publish': 'showMainContent',
            'click #allCHK': 'annoucementSelectAll',
            'click .select-item': 'selectRecordToDelete',
            'click .revoke-click': 'revokeAnnouncement',
            'change #change_msgType': 'chooseMessageType',
            'change #region_name': 'updateRegionName',
            'click #save_announcement': 'createAnnouncement',
            'click #publishAnnouncement': 'createAnnouncement',
            'changeDate #announce_sd': 'updateStartDate',
            'changeDate #announce_ed': 'updateExpiryDate',
            'change #msg_txt': 'updateMessage',
            'change .no-margin': 'updateAckRequried',
            'click #deleteUnpublished': 'deleteUnpublishedAnnouncement',
            'click .edit-click': 'editAnnouncement',
            'click .selectRecordRow': 'selectRecordInmobile',
            'click #closeEdit': 'showMainContent'
        },

        initialize: function() {
            this.model = new AnnouncementModel();
            this.regionsModel = new RegionList();
            this.messageTypeModel = new MessageTypeList(); //added for dynamic messge type fetch
            this.modelDelete = new AnnouncementModel(); //delete button service
            this.newAlertModel = new CreateAlertModel(); //save/publish
            this.revokeAnnouncementModel = new CreateAlertModel(); //revoke service
            this.listenTo(this.model, 'sync', this.render);
            this.listenTo(this.regionsModel, 'sync', this.renderAfterRegionList);
            this.listenTo(this.messageTypeModel, 'sync', this.showNewItemContent);
            this.listenTo(this.modelDelete, 'sync', this.renderAfterDelete);
            this.listenTo(this.newAlertModel, 'sync', this.resultAfterCreation);
            this.listenTo(this.revokeAnnouncementModel, 'sync', this.resultAfterRevoke);
            var data = {
                "NTAccount": getUsername(),
                "APPLICATION_ID": 1
            };
            showLoadingIndicator()
            this.model.getAlertList(data);
            //this.render();

        },
        createAnnouncementInput: {},
        deleteAnnouncementInput: [],
        editContent: false,
        render: function(data) {
            this.$el.html(this.template(data.responseData));
            if (isPhoneGap()) {
                $('.dateinput').click(function() {
                    var options = {
                        date: new Date(),
                        mode: 'date',
                        target: this
                    };

                    datePicker.show(options, function(date) {
                        $(options.target).val(date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate());
                    });
                });
            } else {
                $('.dateinput').datepicker({
                    autoclose: true,
                    format: "yyyy-mm-dd",
                    startDate: new Date()
                });
            }
            hideLoadingIndicator();
        },
        getMessageTypes: function() {
            $('.admin-notification-content').hide();
            showLoadingIndicator();
            var data = {};
            this.messageTypeModel.fetchAvailableTypes(data);
        },
        showNewItemContent: function(data) {
            this.messageDropdownList = data.toJSON().GETAnnouncementTypesOutput;
            //$('.admin-notification-content').hide();
            //serve to load region in dropdown
            var dataInput = {
                "BIND_APPLICATIONID": 1,
                "FUNCTIONID": 13
            };
            // showLoadingIndicator();
            this.regionsModel.fetchAvailableRegions(dataInput);
        },
        renderAfterRegionList: function(data) {
            var dataToTemplate = {};
            if (data.toJSON().EXC_DB_GET_AVAILABLE_REGIONSOutput != undefined) {
                dataToTemplate.regions = data.toJSON().EXC_DB_GET_AVAILABLE_REGIONSOutput;
            }
            dataToTemplate.messageTypes = this.messageDropdownList;
            hideLoadingIndicator();
            dataToTemplate.sd = DateFormatterHyphen(new Date());
            dataToTemplate.ed = DateFormatterHyphen(this.calculateEndDate());
            //Render New Template or Edit Template based on Flag
            if (this.editContent) {
                dataToTemplate.editData = this.editAnnouncementData;
                $('.new-announcement').html(this.editAlertTemplate(dataToTemplate));
                $('#change_msgType').val(this.editAnnouncementData.MESSAGE_TYPE);
                if (this.editAnnouncementData.ACKNOWLEDGEMENT_REQ == "Y") {
                    $('#radioBtn_ack_yes').prop('checked', 'checked');
                } else {
                    $('#radioBtn_ack_no').prop('checked', 'checked');
                }

                if (this.editAnnouncementData.MESSAGE_TYPE == "ENHANCEMENT" || this.editAnnouncementData.MESSAGE_TYPE == "MAINTENANCE") {
                    $('#region_Component').hide();
                } else {
                    $('#region_name').val(this.editAnnouncementData.REGION_NAME);
                }
            } else {
                $('.new-announcement').html(this.newAlertTemplate(dataToTemplate));
                this.createAnnouncementInput = {};
                this.createAnnouncementInput.sd = new Date();
                this.createAnnouncementInput.ed = this.calculateEndDate();
                this.createAnnouncementInput.ackReqflag = "N";
                $('#radioBtn_ack_no').prop('checked', 'checked');
            }
            //For Regional Users
            if (globalize.user == "regional") {
                this.createAnnouncementInput.msgType = "Regional";
                var regionName = JSON.parse(sessionStorage.getItem("preferences")).REGION_NAME;
                if (regionName != undefined) {
                    this.createAnnouncementInput.region = (regionName.split("-")[1].trim()) + "_REGION";
                }
            }
            if (isPhoneGap()) {
                $('.dateinput').click(function() {
                    var options = {
                        date: new Date(),
                        mode: 'date',
                        target: this
                    };

                    datePicker.show(options, function(date) {
                        $(options.target).val(date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate());
                    });
                });
            } else {
                var endDate = this.calculateEndDate();
                $('.dateinput').datepicker({
                    autoclose: true,
                    format: "yyyy-mm-dd",
                    startDate: new Date(),
                    endDate: endDate
                });
            }
        },
        calculateEndDate: function() {
            var e = new Date();
            e.setDate(e.getDate() + 90);
            return e;
        },
        showMainContent: function(element) {
            $('.new-announcement').empty();
            $('.admin-notification-content').show();
            this.createAnnouncementInput = {};
            this.editContent = false;
        },
        annoucementSelectAll: function(event) {
            var count = 2
            for (var i = 0; i < count; i++) {
                $("#id_chk_" + i).prop("checked", event.currentTarget.checked);
            }
        },
        createAnnouncement: function(element) {
            if ($(element.currentTarget).prop('id') == "publishAnnouncement") {
                this.createAnnouncementInput.published = "Y";
            } else {
                this.createAnnouncementInput.published = "N";
            }
            var dataInput = {
                "SaveAnnouncementsInput": [{
                    "APPLICATION_ID": "1",
                    "CREATED_BY": getUsername(),
                    "MESSAGE_ID": this.createAnnouncementInput.msgId,
                    "MESSAGE_TYPE": this.createAnnouncementInput.msgType,
                    "REGION_NAME": this.createAnnouncementInput.region,
                    "MESSAGE_TEXT": this.createAnnouncementInput.msg,
                    "START_DATE": this.createAnnouncementInput.sd,
                    "EXPIRES_ON": this.createAnnouncementInput.ed,
                    "PUBLISHED": this.createAnnouncementInput.published,
                    "ACKNOWLEDGEMENT_REQ": this.createAnnouncementInput.ackReqflag,
                    "OPERATION": "SAVE"
                }]
            };
            showLoadingIndicator();
            this.newAlertModel.insertAnnouncement(dataInput);

        },
        resultAfterCreation: function(response) {
            modalMsg(response.responseData.STATUS_MESSAGE, "success");
            $('.new-announcement').empty();
            var data = {
                "NTAccount": getUsername(),
                "APPLICATION_ID": 1
            };
            this.model.getAlertList(data); //reload list
        },
        revokeAnnouncement: function(element) {
            var selectedTemplate;
            var selectId = $(element.currentTarget).prop('id');
            var cur_row = selectId.split("_");
            var list = this.model.toJSON().AnnouncementsForAdminListOutput;
            selectedTemplate = _.find(list, function(item) {
                return item.MESSAGE_ID === cur_row[1];
            });
            var dataInput = {
                "RevokeAnnouncementsInput": [{
                    "APPLICATION_ID": "1",
                    "CREATED_BY": getUsername(),
                    "MESSAGE_ID": selectedTemplate.MESSAGE_ID,
                    "MESSAGE_TYPE": selectedTemplate.MESSAGE_TYPE,
                    "MESSAGE_TEXT": selectedTemplate.MESSAGE_TEXT,
                    "START_DATE": selectedTemplate.START_DATE,
                    "EXPIRES_ON": selectedTemplate.EXPIRES_ON,
                    "PUBLISHED": selectedTemplate.PUBLISHED,
                    "ACKNOWLEDGEMENT_REQ": "N",
                    "OPERATION": "REVOKE"
                }]
            };
            showLoadingIndicator();
            this.revokeAnnouncementModel.revokeAnnouncement(dataInput); //revoke service call
        },
        resultAfterRevoke: function(response) {
            modalMsg(response.responseData.STATUS_MESSAGE, "success");
            var data = {
                "NTAccount": getUsername(),
                "APPLICATION_ID": 1
            };
            this.model.getAlertList(data); //reload list
        },
        chooseMessageType: function(element) {
            this.createAnnouncementInput.msgType = element.currentTarget.value;
            if (element.currentTarget.value == "ENHANCEMENT" || element.currentTarget.value == "MAINTENANCE") {
                $('#region_Component').hide();
                this.createAnnouncementInput.region = null;
            } else {
                $('#region_Component').show();
            }
            this.validateSaveBtn(this.createAnnouncementInput);
        },
        updateRegionName: function(element) {
            this.createAnnouncementInput.region = element.currentTarget.value;
            this.validateSaveBtn(this.createAnnouncementInput);

        },
        updateStartDate: function(element) {
            this.createAnnouncementInput.sd = element.currentTarget.value + "T00:00:00";
            this.validateSaveBtn(this.createAnnouncementInput);

        },
        updateExpiryDate: function(element) {
            this.createAnnouncementInput.ed = element.currentTarget.value + "T00:00:00";
            this.validateSaveBtn(this.createAnnouncementInput);

        },
        updateMessage: function(element) {
            this.createAnnouncementInput.msg = element.currentTarget.value;
            this.validateSaveBtn(this.createAnnouncementInput);

        },
        updateAckRequried: function(element) {
            if ($(element.currentTarget).prop('id') == "radioBtn_ack_yes") {
                this.createAnnouncementInput.ackReqflag = "Y";
            } else {
                this.createAnnouncementInput.ackReqflag = "N";
            }
            this.validateSaveBtn(this.createAnnouncementInput);
        },
        editAnnouncement: function(element) {
            var selectedTemplate;
            var selectId = $(element.currentTarget).prop('id');
            var cur_row = selectId.split("_");
            var list = this.model.toJSON().AnnouncementsForAdminListOutput;
            selectedTemplate = _.find(list, function(item) {
                return item.MESSAGE_ID === cur_row[1];
            });
            this.setInputDataForSave(selectedTemplate);
            this.editContent = true;
            this.editAnnouncementData = selectedTemplate;
            //this.showNewItemContent();
            this.getMessageTypes();
        },
        setInputDataForSave: function(data) {
            this.createAnnouncementInput.msgType = data.MESSAGE_TYPE;
            this.createAnnouncementInput.msg = data.MESSAGE_TEXT;
            this.createAnnouncementInput.ackReqflag = data.ACKNOWLEDGEMENT_REQ;
            this.createAnnouncementInput.sd = data.START_DATE;
            this.createAnnouncementInput.ed = data.EXPIRES_ON;
            this.createAnnouncementInput.published = data.PUBLISHED;
            this.createAnnouncementInput.msgId = data.MESSAGE_ID;
            if (data.REGION_NAME != undefined) {
                this.createAnnouncementInput.region = data.REGION_NAME;
            }
        },
        selectRecordToDelete: function(element) {
            var selectedTemplate;
            var selectId = $(element.currentTarget).prop('id');
            var cur_row = selectId.split("_");
            var list = this.model.toJSON().AnnouncementsForAdminListOutput;
            selectedTemplate = _.find(list, function(item) {
                return item.MESSAGE_ID === cur_row[1];
            });
            var tempObj = {};
            tempObj.MESSAGE_ID = selectedTemplate.MESSAGE_ID;
            tempObj.APPLICATION_ID = selectedTemplate.APPLICATION_ID;
            tempObj.CREATED_BY = selectedTemplate.CREATED_BY;
            tempObj.MESSAGE_TYPE = selectedTemplate.MESSAGE_TYPE;
            tempObj.OPERATION = "DELETE";

            if ($(element.currentTarget).prop('checked')) {
                this.deleteAnnouncementInput.push(tempObj);
            } else {
                var _this = this;
                this.deleteAnnouncementInput.forEach(function(item, index) {
                    if (item.MESSAGE_ID == cur_row[1]) {
                        _this.deleteAnnouncementInput.splice(index, 1);
                    }
                });

            }
            if (this.deleteAnnouncementInput.length > 0) {
                $('.delete-style').removeClass('button-disable-opacity');
            } else {
                $('.delete-style').addClass('button-disable-opacity');
            }

        },
        deleteUnpublishedAnnouncement: function() {
            var dataInput = {
                "DeleteAnnouncementsDetails": this.deleteAnnouncementInput
            }
            showLoadingIndicator();
            this.modelDelete.deleteAnnouncement(dataInput);
        },
        renderAfterDelete: function(response) {
            this.deleteAnnouncementInput = [];
            modalMsg(response.responseData.STATUS_MESSAGE, "success");
            var data = {
                "NTAccount": getUsername(),
                "APPLICATION_ID": 1
            };
            this.model.getAlertList(data); //reload list
        },
        validateSaveBtn: function(value) {
            if (globalize.user == "admin") {
                if (value.msgType == "ENHANCEMENT" || value.msgType == "MAINTENANCE") {
                    if (isValid(value.msgType) && isValid(value.msg) && isValid(value.ackReqflag) &&
                        isValid(value.sd) && isValid(value.ed)) {
                        this.$el.find('#save_announcement').removeClass('button-disable-opacity');
                        this.$el.find('#publishAnnouncement').removeClass('button-disable-opacity');
                        return;
                    } else {
                        this.$el.find('#publishAnnouncement').addClass('button-disable-opacity');
                        this.$el.find('#save_announcement').addClass('button-disable-opacity');
                    }
                } else {
                    if (isValid(value.msgType) && isValid(value.msg) && isValid(value.ackReqflag) &&
                        isValid(value.sd) && isValid(value.ed) && isValid(value.region)) {
                        this.$el.find('#save_announcement').removeClass('button-disable-opacity');
                        this.$el.find('#publishAnnouncement').removeClass('button-disable-opacity');
                        return;
                    } else {
                        this.$el.find('#publishAnnouncement').addClass('button-disable-opacity');
                        this.$el.find('#save_announcement').addClass('button-disable-opacity');
                    }
                }
            } else {
                if (isValid(value.msg) && isValid(value.ackReqflag) &&
                    isValid(value.sd) && isValid(value.ed) && isValid(value.region)) {
                    this.$el.find('#save_announcement').removeClass('button-disable-opacity');
                    this.$el.find('#publishAnnouncement').removeClass('button-disable-opacity');
                    return;
                } else {
                    this.$el.find('#publishAnnouncement').addClass('button-disable-opacity');
                    this.$el.find('#save_announcement').addClass('button-disable-opacity');
                }
            }


        },
        selectRecordInmobile: function(element) {
            //yet to do
        }

    });

    return ManageAnnouncementView;
});