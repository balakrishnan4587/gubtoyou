/**/

define([
    'jquery',
    'underscore',
    'backbone',
    'datepicker',
    'numberspinner',
    'templates',
    'globalise',
    'views/personalfavorites',
    'views/regionalfavorites',
    'collections/regionlist'
], function($, _, Backbone, datepicker, numberspinner, JST, globalize, PersonalFavoritesView, RegionalFavoritesView) {
    'use strict';

    var FavoritesView = Backbone.View.extend({
        template: JST['app/scripts/templates/favorites.ejs'],

        childView: null,
        el: '#container',
        viewName: 'favoritesView',
        events: {
            'click #regFav': function() {
                this.goTo("#favorites?regional");
            },
            'click #perFav': function() {
                this.goTo("#favorites?personal");
            },
            'change #select_fav_filter': 'sortFavCollection',
            'change #select_fav_filter1': 'sortFavCollection',
            'keyup #fav_search_field': 'searchList',
            'keyup #favFilterText': 'searchList',
            'click #btnSearchByRegion': 'loadRegionalData',
            'click .large-img': 'largeImageModal',
            /*Search button event*/
            'click #fav-filter-btn': 'toggleFilter',
            'click #doneFavFilter': 'toggleFilter',
            'change #selectTemplateList': function() {
                if (window.innerWidth < 768) {
                    this.loadRegionalData();
                }
            }
        },

        initialize: function(options) {},

        renderFavoritesMain: function(viewType) {
            if (this.childView) {
                this.childView.remove();
                this.childView.unbind();
            }
            this.$el.html(this.template());
            this.delegateEvents(this.events);
            if (viewType == "personal") {
                this.loadPersonalFavorites();
            } else if (viewType == "regional") {
                this.loadRegionalFavorites();
            }
            //hideLoadingIndicator();
        },

        loadRegionalFavorites: function(element) {
            $('.search_group').show();
            this.personalFavorites = false;
            $('#perFav').removeClass('btn-selected');
            $('#regFav').addClass('btn-selected');
            $('#favouriteList').empty();
            if (this.childView) {
                this.childView.remove();
                this.childView.unbind();
            }
            this.childView = new RegionalFavoritesView();
            this.childView.regionList.fetchData();
            //this.childView.collection.fetchData();
        },

        loadRegionalData: function() {
            if ($('#regionList').val() === null) {
                modalMsg("Please select a Region", "error");
                return;
            }
            if ($('#selectTemplateList').val() === null) {
                modalMsg("Please select a Template", "error");
                return;
            }
            var userdata = JSON.parse(sessionStorage.getItem("_id"));
            var data = {
                "Requestor_User_Name": userdata.sub,
                /*****TO CHANGE IMPORTANT*****/
                "REGION_NAME": $('#regionList').val(),
                "TEMPLATE_NAME": $('#selectTemplateList').val()
            }
            this.childView.collection.fetchData(data);
        },

        loadPersonalFavorites: function(element) {
            $('.search_group').hide();
            this.personalFavorites = true;
            $('#perFav').addClass('btn-selected');
            $('#regFav').removeClass('btn-selected');
            $('#favouriteList').empty();
            if (this.childView) {
                this.childView.remove();
                this.childView.unbind();
            }
            this.childView = new PersonalFavoritesView();
            if (isOnline) {
                this.childView.collection.fetchData();
            } else {
                this.childView.collection.fetchOfflineData(); //For loading offline data
            }
        },

        sortFavCollection: function(el) {
            $('#fav_search_field').val("");

            /* Uncomment to enable sort */

            var value = el.currentTarget.value;
            this.childView.collection.changeSort(value);
        },

        // afterSort: function() {
        //   var pfview = new PersonalFavoritesView();
        //   pfview.render(this);
        // },

        searchList: function(el) {
            var value = el.currentTarget.value;
            this.childView.render(this.childView.collection.search(value));
        },

        toggleFilter: function() {
            if ($('#favPage').css('display') === "none") {
                $('#favPage').show();
                $('#favFilter').hide();
                hideHeaderButtons();
                toggleBackButton();
            } else {
                $('#favPage').hide();
                $('#favFilter').show();
                showHeaderButtons(false, true, "Reset", "Done");
                enableDone();
                toggleBackButton();
            }
        },

        backButtonAction: function() {
            this.toggleFilter();
        },

        rightbuttonAction: function() {
            this.toggleFilter();
        },
        largeImageModal: function(element) {
            modalImage($(element.currentTarget).data("imgsrc"))
        }

    });

    return FavoritesView;
});