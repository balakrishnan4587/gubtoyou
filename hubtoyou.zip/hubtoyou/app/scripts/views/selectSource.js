/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'collections/inquiryoutput',
    'models/addtocart',
    'models/intransitinput',
], function($, _, Backbone, JST, InquiryOutputCollection, CartModel, InTransitModel) {
    'use strict';

    var SelectSourceView = Backbone.View.extend({
        template: JST['app/scripts/templates/selectsource.ejs'],
        noRecords: JST['app/scripts/templates/norecords.ejs'],
        collection: new InquiryOutputCollection(),
        el: '#container',
        id: '',
        className: '',
        events: {
            'click #selectsource_back': 'backToPrevious',
            'click .add-to-cart-SelectSrc': 'addToCartSelectSrc',
            'click .large-img': 'largeImageModal',
            'click .intransit-service': 'intransitService'
        },

        initialize: function() {
            //console.log("select source init");
            //AppView.currentView = this;
            this.cartmodel = new CartModel();
            this.inTransitModel = new InTransitModel();
            this.listenTo(this.collection, 'sync', this.render);
            //this.collection.bind("sync", this.render, this);
        },

        render: function(data) {
            if (typeof data.toJSON()[0].inquiryOutput !== "undefined") {
                this.$el.html(this.template(data.toJSON()[0]));
            } else {
                this.$el.html(this.noRecords()); //Display No records View
            }
            hideLoadingIndicator();
            this.delegateEvents(this.events);
            return this;
        },

        loadData: function(item) {
            var data = {
                "Cifa_Item_Number": item,
                "username": getUsername()
            }
            this.collection.fetchData(data);
        },

        backToPrevious: function(event) {
            var len = breadCrumbs.length;
            var previous = breadCrumbs[breadCrumbs.length - 2];
            breadCrumbs.splice(len - 1, 1);
            updateBreadCrumbs();
            //console.log("im executing");
            if (previous) {
                this.undelegateEvents();
                this.remove();
                window.location.href = previous.href;
                event.stopPropagation();
                return;
            } else {
                this.undelegateEvents();
                this.remove();
                window.history.back();
                return;
            }
        },
        backButtonAction: function() {
            // // var len = breadCrumbs.length;
            // // breadCrumbs.splice(len - 1, 1);
            // // updateBreadCrumbs();
            // var current = breadCrumbs.pop();
            // var previous = breadCrumbs.pop();
            // if (previous) {
            //     breadCrumbs.pop();
            //     updateBreadCrumbs();
            //     window.location.href = previous.href;
            //     this.close();
            // } else {
            //     window.history.back();
            // }
            // toggleBackButton();
            // //window.history.back();
            var len = breadCrumbs.length;
            var previous = breadCrumbs[breadCrumbs.length - 2];
            breadCrumbs.splice(len - 1, 1);
            updateBreadCrumbs();
            //console.log("im executing");
            if (previous) {
                this.undelegateEvents();
                this.remove();
                window.location.href = previous.href;
                event.stopPropagation();
                return;
            } else {
                this.undelegateEvents();
                this.remove();
                window.history.back();
                return;
            }
        },

        addToCartSelectSrc: function(element) {
            var selectId = $(element.currentTarget).prop('id');
            var cur_row = selectId.split("_");
            var orgCode = $("#orgCode_" + cur_row[1]).text();
            var userData = JSON.parse(sessionStorage.getItem('_id'));
            var username = userData.sub;
            var currentFavItem = JSON.parse(localStorage.getItem('currentFavItem'));
            //var ndate = currentFavItem.needByDate + "T00:00:00";
            var qty = 1;
            var needbydate = localStorage.getItem('needbyDate') + "T00:00:00";
            if (_.findWhere(breadCrumbs, { name: 'ShoppingCart' })) {
                qty = sessionStorage.getItem("currentitemquantity");
                needbydate = sessionStorage.getItem("currentitemneedByDate") + "T00:00:00";
            } else {
                qty = currentFavItem.quantity;
                needbydate = currentFavItem.needByDate + "T00:00:00";
            }
            qty = (qty == null) ? '1' : qty;

            var cartInputData = {
                "ShoppingCartUpsertData": [{
                    "CIFA_ITEM_NUMBER": currentFavItem.CIFA_ITEM_NUMBER,
                    "ITEM_DESC": currentFavItem.ITEM_DESCRIPTION,
                    "ITEM_CATEGORY": currentFavItem.ITEM_CATEGORY,
                    "QUANTITY": qty,
                    "NEED_BY_DATE": needbydate,
                    "REGION_TEMPLATE": currentFavItem.TEMPLATE_NAME,
                    "REGION_NAME": currentFavItem.REGION_NAME,
                    "SOURCE_ORGANIZATION_CODE": orgCode,
                    "USER_NAME": getUsername()
                }]
            }
           //console.log(cartInputData);
            showLoadingIndicator();
            this.cartmodel.addToCartRequest(cartInputData);
        },

        largeImageModal: function(element) {
            //console.log($(element.currentTarget).data("imgsrc"));
            modalImage($(element.currentTarget).data("imgsrc"))
        },

        intransitService: function(element) {
            var selectId = $(element.currentTarget).prop('id');
            var cur_row = selectId.split("_");
            var orgCode = $("#orgCode_" + cur_row[1]).text();
            var currentFavItem = JSON.parse(localStorage.getItem('currentFavItem'));
            var intransitInputData = {
                "CIFA_ITEM_NUMBER": currentFavItem.CIFA_ITEM_NUMBER,
                "ORG_CODE": orgCode
            }
            //console.log(intransitInputData);
            localStorage.setItem("currentIntransit", JSON.stringify(intransitInputData));
            //this.inTransitModel.inTransitRequest(intransitInputData);
            window.location.href = "#intransit";
        },

        onClose: function() {
            //console.log(this + "select source is closed");
        }

    });

    return SelectSourceView;
});