/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'helper'
], function($, _, Backbone, JST, helper) {
    'use strict';

    var LoginView = Backbone.View.extend({
        template: JST['app/scripts/templates/logout.ejs'],

        el: '#container',

        //tagName: 'div',

        viewName: 'logoutView',

        id: '',

        className: '',

        events: {
            'click #loginBtn': 'doLogin'
        },

        // initialize: function () {
        //   //this.router = this.options.router;
        //   //this.listenTo(this.model, 'change', this.render);
        //   this.render();
        // },

        render: function() {
            this.$el.html(this.template());
            this.delegateEvents(this.events);
            hideLoadingIndicator();
            return this;
        },
        doLogin: function() {
            auth0.authorize();
        },
    });

    return LoginView;
});