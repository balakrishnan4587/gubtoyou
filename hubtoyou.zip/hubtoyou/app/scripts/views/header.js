/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates'
], function($, _, Backbone, JST) {
    'use strict';

    var HeaderView = Backbone.View.extend({
        template: JST['app/scripts/templates/header.ejs'],
        //el: '#header',
        tagName: 'div',

        id: '',

        className: '',

        events: {
            // 'click .nav a': function(source) {
            //     $(source.target).parent().addClass('active').siblings().removeClass('active');
            // },

            'click .span_user': function(source) {
                $('#logout-box').toggle();
            },
            'click .logout-box a': function() {
                $('#logout-box').toggle();
            },
            'click #mb_button_right': function(event) {
                AppView.currentView.rightbuttonAction(event);
            },
            'click #hamburger_menu': 'menuAction',
            'keydown #header_search_input': 'searchTriggered',
            'click #mob-btn-cart': function() {
                this.goTo("#shoppingcart");
            },
            'focus #header_search_input': 'focusSearch',
            'click #header-search-button': 'headerSearchButtonClick'
        },

        // initialize: function () {
        //   this.listenTo(this.model, 'change', this.render);
        // },

        focusSearch: function() {
            if ($("#catSearchList").val() === "" || $("#catSearchList").val() === null) {
                $("#catSearchList").val("Cifa_Item_Number");
            }
        },

        render: function() {
            this.$el.html(this.template());
            //$('#cartItemCount').hide();
            return this;
        },

        menuAction: function(event) {
            if ($(event.currentTarget).hasClass('icon-backbtn')) {
                if (AppView.currentView.childView) {
                    if (AppView.currentView.childView.backButtonAction) {
                        AppView.currentView.childView.backButtonAction();
                        AppView.currentView.childView = null;
                        return;
                    }
                }
                AppView.currentView.backButtonAction(event);
            } else {
                if ($('#page-container').hasClass('menu-visible')) {
                    closeNav();
                } else {
                    openNav();
                }
            }
        },



        searchTriggered: function(event) {
            if (event.keyCode === 13) {
                var param = $('#catSearchList').val();
                var value = event.currentTarget.value;
                this.goTo('#search?' + param + '=' + value);
            }
        },

        headerSearchButtonClick: function() {
            var param = $('#catSearchList').val();
            var value = $('#header_search_input').val();
            if (value === "") {
                this.goTo('#search');
            } else {
                this.goTo('#search?' + param + '=' + value);
            }
        }

        // slideOpen: function() {
        //     $('.slide-menu').css("display", "block");
        //     $('.slide-menu').animate({
        //         left: "0px"
        //     }, 200);

        //     $('body').animate({
        //         left: "250px"
        //     }, 200);

        //     $('.navbar-fixed-top').animate({
        //         left: "250px",
        //         right: "-250px"
        //     }, 200);

        //     $('#page_mask').fadeIn();
        //     $('body').addClass('masked');
        // }
    });

    return HeaderView;
});

$(document).mouseup(function(e) {
    var container = $("#logout-box");

    if (!container.is(e.target) // if the target of the click isn't the container...
        &&
        container.has(e.target).length === 0) // ... nor a descendant of the container
    {
        container.hide();
    }
});