/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/responsibiltylist',
    'models/responsibilityenabledusers',
    'models/adminavailableregions',
    'models/adminselectedregions',
    'models/deletentusername',
    'views/adminresponseadduser',
    'models/admingrantedresponsibility',
    'views/searchntusernamepopup',
    'models/adminsaveuserreponsibility',
    'models/adminaddregion',
    'models/admindeleteregion'
], function($, _, Backbone, JST, ResponseChoiceListModel, ResponseEnabledUserModel, AdminAvailableRegionsModel, AdminSelectedRegionsModel, DeleteNTUserNameModel, AdminResponseAdduserView, UserGrantedResModel, SearchNTUserPopupView, SaveUserResponsibilityModel, AddRegionsModel, DeleteRegionsModel) {
    'use strict';

    var AdministrationView = Backbone.View.extend({
        template: JST['app/scripts/templates/administration.ejs'],
        responsibilitytemplate: JST['app/scripts/templates/adminresponsibilty.ejs'],
        responsisubtemplate: JST['app/scripts/templates/adminresponsisubtab.ejs'],
        selectedregionstemplate: JST['app/scripts/templates/adminselectedregions.ejs'],
        availableregionstemplate: JST['app/scripts/templates/adminavailableregions.ejs'],
        adminusertemplate: JST['app/scripts/templates/adminusertemplate.ejs'],
        admingrantedresptemplate: JST['app/scripts/templates/admingrantedusertemplate.ejs'],
        viewName: 'viewAdministration',
        el: '#container',
        tagName: 'div',
        model: '',
        id: '',
        className: '',
        choiceSelected: {},
        renderData: {},
        enabledUserEmpty: false,
        applicationid: 1,
        events: {
            'click #admin-responsibility-tab': 'goToGetChoiceList',
            'click #selected-regions-tab': 'selectedRegionsTab',
            'click #available-regions-tab': 'availableRegionsTab',
            'change #responseChoiceSelect': 'responseChoiceSelect',
            'click #admin-user-tab': 'renderAdminUserTab',
            'click #responsibilityadduser': 'loadResponseAddUser',
            'click .deleteUserFromEnabled': 'deleteUserFromEnabled',
            'click #gouserNTUsernameInput': 'goNTUserNameUserTab',
            'click #selectuserNTUsernameInput': 'searchNTUserNamePopup',
            'click #NTUserSaveBtn': 'saveUserResponsibility',
            'click .addregionbtn': 'addRegiontoResponsibility',
            'click .deleteregionbtn': 'deleteRegiontoResponsibility'
        },
        initialize: function() {
            //AppView.currentView = this;
            this.loginUserName = getUsername();
            this.responsechoicelist = new ResponseChoiceListModel();
            this.responseenabledusers = new ResponseEnabledUserModel();
            this.availableregions = new AdminAvailableRegionsModel();
            this.selectedregions = new AdminSelectedRegionsModel();
            this.selectedregionstab = new AdminSelectedRegionsModel();
            this.deletentusername = new DeleteNTUserNameModel();
            this.granteduserresponsibility = new UserGrantedResModel();
            this.saveuserresponsibility = new SaveUserResponsibilityModel();
            this.addregion = new AddRegionsModel();
            this.deleteregion = new DeleteRegionsModel();

            this.listenTo(this.responsechoicelist, 'sync', this.goToResponseEnabledUsers);
            this.listenTo(this.responseenabledusers, 'sync', this.goTopSelectedRegionsTab);
            this.listenTo(this.selectedregions, 'sync', this.renderResponsibiltyTab);

            this.listenTo(this.availableregions, 'sync', this.renderAvailableRegionsTab);
            this.listenTo(this.selectedregionstab, 'sync', this.renderSelectedRegionsTab);
            this.listenTo(this.deletentusername, 'sync', this.goToGetChoiceList);
            this.listenTo(this.granteduserresponsibility, 'sync', this.renderGrantedUserResp);
            this.listenTo(this.saveuserresponsibility, 'sync', this.AfterSaveUserResponsibility);
            this.listenTo(this.addregion, 'sync', this.AfterAddRegions);
            this.listenTo(this.deleteregion, 'sync', this.AfterDeleteRegions);

            this.choiceSelected = { "FUNCTION_ID": 7, "FUNCTION_NAME": "" };
            //this.$el.html(this.template());
            this.goToGetChoiceList();
            //this.renderAdminUserTab();
        },
        render: function(data) {
            this.$el.html(this.template());
            this.delegateEvents(this.events);
            return this;
        },
        renderAdminUserTab: function() {
            showHeaderButtons(false, true, "Reset", "Save");
            disableDone();
            $("#admin-responsibility-tab").removeClass("btn-selected");
            $("#admin-user-tab").addClass("btn-selected");
            this.$el.find("#admin-tab-container").html(this.adminusertemplate());
            $("#userNTUsernameInput").focus();
            this.delegateEvents(this.events);
            return this;
        },
        loadResponseAddUser: function() {
            globalize.selectedFunctionID = this.choiceSelected.FUNCTION_ID;
            sessionStorage.setItem('selectedFunctionID', this.choiceSelected.FUNCTION_ID);
            window.location.href = "#addntusername";

        },
        goToGetChoiceList: function() {
            var dataInput = {
                "BIND_APPLICATIONID": this.applicationid
            };
            showLoadingIndicator();
            this.responsechoicelist.fetchData(dataInput);
        },
        goToResponseEnabledUsers: function(data) {
            var self = this;
            this.responseDropdownlist = this.responsechoicelist.responseChoiceData;

            this.renderData.responseDropdown = this.responseDropdownlist;
            var dataInput = {
                "BIND_APPLICATIONID": this.applicationid,
                "FUNCTIONID": this.choiceSelected.FUNCTION_ID
            };
            this.responseenabledusers.fetchData(dataInput);
        },
        goTopSelectedRegionsTab: function() {
            var self = this;
            this.resnableduserslist = this.responseenabledusers.responseEnabledUsersData;
            this.renderData.resnabledusers = this.resnableduserslist;

            var dataInput = {
                "BIND_APPLICATIONID": this.applicationid,
                "FUNCTIONID": this.choiceSelected.FUNCTION_ID
            };
            this.selectedregions.fetchSelectedRegions(dataInput);

        },
        renderResponsibiltyTab: function(data) {
            var self = this;
            $("#admin-user-tab").removeClass("btn-selected");
            $("#admin-responsibility-tab").addClass("btn-selected");
            this.selectedAvailableregions = this.selectedregions.responseSelectedData;
            this.renderData.selectedAvailableregions = this.selectedAvailableregions;
            var dropdownlist = this.renderData.responseDropdown;
            if (typeof dropdownlist.EXC_DB_RESP_CHOICE_LISTOutput != "undefined") {
                dropdownlist.EXC_DB_RESP_CHOICE_LISTOutput.forEach(function(item, index) {
                    if (self.choiceSelected.FUNCTION_ID == item.FUNCTION_ID) {
                        self.choiceSelected.FUNCTION_NAME = item.FUNCTION_NAME;
                    }
                });
            }

            this.renderData.choiceSelected = this.choiceSelected.FUNCTION_ID;
            this.renderData.choiceSelectedName = this.choiceSelected.FUNCTION_NAME;
            this.renderData.enabledUserEmpty = this.enabledUserEmpty;

            this.$el.find("#admin-tab-container").html(this.responsibilitytemplate(this.renderData));
            if (this.choiceSelected.FUNCTION_ID == 7 || this.choiceSelected.FUNCTION_ID == 8) {
                $("#admin-response-users-section").hide();
                this.$el.find("#admin-sub-tab").html(this.responsisubtemplate(this.renderData));
                this.$el.find("#selected-available-container").html(this.selectedregionstemplate(this.renderData));
            } else {
                $("#admin-response-users-section").show();
            }
            hideLoadingIndicator();
            this.delegateEvents(this.events);
            return this;
        },
        responseChoiceSelect: function(element) {
            var eleval = element.currentTarget.value;
            this.choiceSelected.FUNCTION_ID = eleval;
            var dataInput = {
                "BIND_APPLICATIONID": this.applicationid,
                "FUNCTIONID": eleval
            };
            showLoadingIndicator();
            this.responseenabledusers.fetchData(dataInput);
        },
        selectedRegionsTab: function() {
            var dataInput = {
                "BIND_APPLICATIONID": this.applicationid,
                "FUNCTIONID": this.renderData.choiceSelected
            };
            showLoadingIndicator();
            this.selectedregionstab.fetchSelectedRegions(dataInput);

        },
        renderSelectedRegionsTab: function(data) {
            $("#available-regions-tab").removeClass("btn-selected");
            $("#selected-regions-tab").addClass("btn-selected");
            this.renderData.selectedAvailableregions = data.responseSelectedData;
            this.$el.find("#selected-available-container").html(this.selectedregionstemplate(this.renderData));
            hideLoadingIndicator();
            this.delegateEvents(this.events);
            return this;
        },
        availableRegionsTab: function() {
            var dataInput = {
                "BIND_APPLICATIONID": this.applicationid,
                "FUNCTIONID": this.renderData.choiceSelected
            };
            showLoadingIndicator();
            this.availableregions.fetchAvailableRegions(dataInput);

        },
        renderAvailableRegionsTab: function(data) {
            $("#selected-regions-tab").removeClass("btn-selected");
            $("#available-regions-tab").addClass("btn-selected");
            this.renderData.selectedAvailableregions = data.responseAvailableData;
            this.$el.find("#selected-available-container").html(this.availableregionstemplate(this.renderData));
            hideLoadingIndicator();
            this.delegateEvents(this.events);
            return this;
        },
        deleteUserFromEnabled: function(element) {

            var selectId = $(element.currentTarget).prop('id');
            var userIDAry = selectId.split("_");
            var userID = userIDAry[1];
            var list = this.renderData.resnabledusers.EXC_DB_RESP_ENABLED_USERSOutput;
            var selectedTemplate = _.find(list, function(item) {
                return item.USER_ID == userID;
            });
            var dataInput = {
                "XxcmstAdfFunctionAccess": [{
                    "applicationId": selectedTemplate.APPLICATION_ID,
                    "functionId": selectedTemplate.FUNCTION_ID,
                    "RequestorName": this.loginUserName,
                    "UserName": selectedTemplate.USER_NAME
                }]

            };
            showLoadingIndicator();
            this.deletentusername.deleteNTUserName(dataInput);
        },
        goNTUserNameUserTab: function() {
            var inputusername = $("#userNTUsernameInput").val();
            if (isValid(inputusername)) {
                this.$el.find("#grantedusercontent").empty();
                var dataInput = {
                    "BIND_APPLICATIONID": this.applicationid,
                    "USER_NAME": inputusername
                };
                showLoadingIndicator();
                this.granteduserresponsibility.getUserGrantedResponsibility(dataInput);
            } else {
                $("#checkuservalidmsg").html("Enter Valid User Name");
            }

        },
        renderGrantedUserResp: function(data) {
            var data = data.UserResponsibilityData;
            this.renderData.usergrantedavailable = data;
            if (data.STATUS == "ERROR") {
                $("#userNTUsernameInput").addClass("border-red");
                $("#checkuservalidmsg").html(data.STATUS_MESSAGE);
            } else {
                $("#checkuservalidmsg").html("");
                $("#userNTUsernameInput").removeClass("border-red");
                enableDone();
                this.$el.find("#grantedusercontent").html(this.admingrantedresptemplate(data));
            }
            hideLoadingIndicator();
            this.delegateEvents(this.events);
            return this;
        },
        searchNTUserNamePopup: function(element) {
            globalize.NTUsernameInputBox = element.currentTarget.previousElementSibling;
            $('.adminstration-page').hide();
            this.$el.find("#grantedusercontent").empty();
            $("#checkuservalidmsg").html("");
            var searchNTUserView = new SearchNTUserPopupView();
            if (!_.findWhere(breadCrumbs, { name: 'Search NT User Name' })) {
                breadCrumbs.push({
                    "name": "Search NT User Name",
                    "href": "#"
                });
            }

            showHeaderButtons(false, true, "Reset", "Done");
            updateBreadCrumbs();
            showBackButton();
            globalView = this;
        },

        saveUserResponsibility: function() {
            var self = this;
            console.log(this.renderData.usergrantedavailable);
            var grantedavailbledata = this.renderData.usergrantedavailable;
            var checkedIDS = $("#grantedusercontent input:checkbox:checked").map(function() {
                return $(this).attr("id");
            }).get();
            //console.log(checkedIDS);

            var functionIDS = [];
            checkedIDS.forEach(function(item) {
                var funid = item.split("_");
                functionIDS.push(parseInt(funid[1]));
            });
            console.log("selected functionIDS.." + functionIDS);
            var granted = "";
            var grantedIDS = [];
            if (typeof grantedavailbledata.EXC_DB_FETCH_USER_RESPOutput !== "undefined") {
                granted = grantedavailbledata.EXC_DB_FETCH_USER_RESPOutput;
                granted.forEach(function(item) {
                    grantedIDS.push(item.FUNCTION_ID);
                });
            }
            var existsGrantedIDS = grantedIDS;
            var removeIDS = [];
            functionIDS.forEach(function(val) {
                var position = grantedIDS.indexOf(val);
                if (position >= 0) {
                    grantedIDS.splice(position, 1); // remove ids to find unchecked value
                }

            });
            removeIDS = grantedIDS;
            console.log("removeIDS.." + removeIDS);

            var available = "";
            var availableIDS = [];
            if (typeof grantedavailbledata.EXC_GET_AVILABLE_RESPONSIBILITIESOutput !== "undefined") {
                available = grantedavailbledata.EXC_GET_AVILABLE_RESPONSIBILITIESOutput;
                available.forEach(function(item) {
                    availableIDS.push(item.FUNCTION_ID);
                });
            }
            var existsAvailableIDS = availableIDS;
            var addIDS = [];
            functionIDS.forEach(function(val) {
                var position = availableIDS.indexOf(val);
                if (position >= 0) {
                    addIDS.push(val); // add ids to find new checked value
                }
            });
            console.log("addIDS.." + addIDS);

            var buildData = [];
            if (removeIDS.length > 0) {
                removeIDS.forEach(function(val) {
                    var foundObject = "";
                    foundObject = $.grep(granted, function(e) { return e.FUNCTION_ID == val; });
                    if (foundObject.length > 0) {
                        var obj = {
                            "applicationId": self.applicationid,
                            "functionId": val,
                            "userId": foundObject[0].USER_ID,
                            "UserName": foundObject[0].USER_NAME,
                            "actiontype": "REMOVE"
                        };
                        buildData.push(obj);
                    }
                });
            }

            if (addIDS.length > 0) {
                addIDS.forEach(function(val) {
                    var foundObject1 = "";
                    foundObject1 = $.grep(available, function(e) { return e.FUNCTION_ID == val; });
                    if (foundObject1.length > 0) {
                        var obj = {
                            "applicationId": self.applicationid,
                            "functionId": val,
                            "userId": foundObject1[0].USER_ID,
                            "UserName": foundObject1[0].USER_NAME,
                            "actiontype": "ADD"
                        };
                        buildData.push(obj);
                    }
                });
            }

            if ((addIDS.length > 0) || (removeIDS.length > 0)) {
                $("#checknoneselectedmsg").html("");
                var dataInput = {
                    "XxcmstAdfFunctionAccess": buildData
                };
                showLoadingIndicator();
                this.saveuserresponsibility.saveUserResponsibility(dataInput);
            } else {
                $("#checknoneselectedmsg").html("Please select atleast one Responsibility");
            }


        },
        AfterSaveUserResponsibility: function(data) {
            var response = data.saveUserRespData;
            hideLoadingIndicator();
            if (response.STATUS == "SUCCESS") {
                modalMsg(response.STATUS_MESSAGE, "success");
            } else {
                modalMsg(response.STATUS_MESSAGE, "error");
            }
        },
        addRegiontoResponsibility: function(element) {
            var ele = $(element.currentTarget).parent().prev().find(".availregiontxt");
            var regiontext = $.trim(ele.text());
            //console.log("region.."+regiontext);
            var dataInput = {
                "XxcmstAdfRegionAccess": [{
                    "applicationId": this.applicationid,
                    "functionId": this.renderData.choiceSelected,
                    "RegionName": regiontext,
                    "UserName": this.loginUserName
                }]
            };
            showLoadingIndicator();
            this.addregion.addRegion(dataInput);
        },
        AfterAddRegions: function(data) {
            var response = data.responseAddRegionData;
            hideLoadingIndicator();
            if (response.STATUS == "SUCCESS") {
                modalMsg(response.STATUS_MESSAGE, "success");
                this.availableRegionsTab();
            } else {
                modalMsg(response.STATUS_MESSAGE, "error");
            }
        },
        deleteRegiontoResponsibility: function(element) {
            var regiontemp = $(element.currentTarget).prop("id");
            var region = regiontemp.split("_");
            console.log("region.." + region[1]);
            var accessid = region[1];
            var list = this.renderData.selectedAvailableregions.EXC_DB_REGION_RESP_USAGEOutput;
            var selectedTemplate = _.find(list, function(item) {
                return item.ACCESS_ID == accessid;
            });
            var dataInput = {
                "XxcmstAdfRegionAccess": [{
                    "applicationId": this.applicationid,
                    "functionId": this.renderData.choiceSelected,
                    "RegionName": selectedTemplate.REGION_NAME,
                    "UserName": this.loginUserName
                }]
            };
            showLoadingIndicator();
            this.deleteregion.deleteRegion(dataInput);
        },
        AfterDeleteRegions: function(data) {
            var response = data.responseDeleteRegionData;
            hideLoadingIndicator();
            if (response.STATUS == "SUCCESS") {
                modalMsg(response.STATUS_MESSAGE, "success");
                this.selectedRegionsTab();
            } else {
                modalMsg(response.STATUS_MESSAGE, "error");
            }
        },
        rightbuttonAction: function() {
            this.saveUserResponsibility();
        },




    });

    return AdministrationView;
});