/*globalize*/

define([
  'jquery',
  'underscore',
  'backbone',
  'templates',
  'models/requisitiondetails',
  'models/acknowledementdetails'
], function ($, _, Backbone, JST, RequisitionDetailsModel, AckDetails) {
  'use strict';

  var RequisitionDetailsView = Backbone.View.extend({
    template: JST['app/scripts/templates/requisitiondetails.ejs'],
    receivingDetailsTemplate:JST['app/scripts/templates/receivingdetails.ejs'],
    el:'#container',
    model: new RequisitionDetailsModel(),
    events: {
    'click .hdr-item-list':'loadItemDetails',
    'click .accordion-ack-details':'toggleAccordian'
    },

    initialize: function () {
      this.ackDetails = new AckDetails();
      this.listenTo(this.model,'change',this.render); //search for locations
      this.listenTo(this.ackDetails,'change',this.resultForAck); //search for locations
    },

    render:function(data){
      //var list = data.toJSON().RequisitionLineOutput[0];
    //  for(var i=0;i<list.length>0;i++){
        this.$el.html(this.template(data.toJSON()));
      //}

    },
    loadItemDetails:function(element){
      if($(window).width() > 767){
        return;
      }
      var selectedRow = $(element.currentTarget).prop('id').split('_');
      var selectedObj = _.find(this.model.toJSON().RequisitionLineOutput,function(item){
        return item.REQUISITION_NUMBER = selectedRow[1];
      });
      this.goTo('hdrItemDetails',selectedObj);
    },
    resultForAck:function(data){
        $(this.currEle).next().html(this.receivingDetailsTemplate(data));
        $(this.currEle).next().toggle("show");
    },
    toggleAccordian:function(element){
      this.currEle = element.currentTarget;
      this.ackDetails.fetchJson();


    }
  });

  return RequisitionDetailsView;
});
