define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/buadminavailableusers',
    'models/buadminselectedusers'
], function($, _, Backbone, JST, buAvailableUserModel, buSelectedUserModel) {
    'use strict';

    var RegionEmployeesView = Backbone.View.extend({
        regionEmployeeTemplate: JST['app/scripts/templates/regionemployees.ejs'],
        availableEmployeeTemplate: JST['app/scripts/templates/availableemployees.ejs'],
        noRecords: JST['app/scripts/templates/norecords.ejs'],
        //model: '',
        el: '.bu-admin-content',
        id: '',
        viewName: 'buAdminView',
        events: {
            'click #selectedEmp': 'loadSelectedEmployees',
            'click #availableEmp': 'loadAvailableEmployees',
            'click .delete-bg': 'deleteSelectedUser',
            'click .add-img': 'insertSelectedUser'
        },
        initialize: function(options) {
            //this.regionName = options.regionName;
            this.bu = options.bu;
            this.availableUserModel = new buAvailableUserModel();
            this.availableUserModelAdd = new buAvailableUserModel();
            this.selectedUserModel = new buSelectedUserModel();
            this.selectedUserModelDelete = new buSelectedUserModel();
            this.listenTo(this.availableUserModel, 'sync', this.renderAvailableUsers);
            this.listenTo(this.selectedUserModel, 'sync', this.renderSelectedUsers);
            this.listenTo(this.availableUserModelAdd, 'sync', this.resultAfterInsert);
            this.listenTo(this.selectedUserModelDelete, 'sync', this.resultAfterDelete);
            this.render();
        },
        render: function() {
            this.$el.html(this.regionEmployeeTemplate());
            this.loadAvailableEmployees();
            this.delegateEvents(this.events);
            return this;
        },

        loadSelectedEmployees: function() {
            $('.bu-admin-regionemp-content').empty();
            this.selectedEmployeesTab = true;
            this.availableEmployeesTab = false;
            $('#availableEmp').removeClass('btn-selected');
            $('#selectedEmp').addClass('btn-selected');
            var data = {
                "BUSINESS_UNIT": this.bu
            }
            showLoadingIndicator();
            this.selectedUserModel.fetchAvailableUsers(data);

        },
        loadAvailableEmployees: function() {
            $('.bu-admin-regionemp-content').empty();
            this.availableEmployeesTab = true;
            this.selectedEmployeesTab = false;
            $('#selectedEmp').removeClass('btn-selected');
            $('#availableEmp').addClass('btn-selected');
            var data = {
                "BUSINESS_UNIT": this.bu
            }
            showLoadingIndicator();
            this.availableUserModel.fetchAvailableUsers(data);

        },
        renderAvailableUsers: function(data) {
            hideLoadingIndicator();
            if (this.availableUserModel.responseAvailableData != undefined && this.availableUserModel.responseAvailableData.UsersListOutput != undefined) {
                this.availableEmployeesTabData = data.toJSON()
                $('.bu-admin-regionemp-content').html(this.availableEmployeeTemplate(this));
            } else {
                $('.bu-admin-regionemp-content').html(this.noRecords());
            }

        },
        renderSelectedUsers: function(data) {
            hideLoadingIndicator();
            if (this.selectedUserModel.responseAvailableData != undefined && this.selectedUserModel.responseAvailableData.SelectedUsersListOutput != undefined) {
                this.SelectedEmployeesTabData = this.selectedUserModel.responseAvailableData
                $('.bu-admin-regionemp-content').html(this.availableEmployeeTemplate(this));
            } else {
                $('.bu-admin-regionemp-content').html(this.noRecords());
            }

        },
        insertSelectedUser: function(element) {
            var selectedRowId = $(element.currentTarget).prop('id');
            var list = this.availableEmployeesTabData.UsersListOutput;
            var selectedTemplate = _.find(list, function(item) {
                return item.PERSON_ID === Number(selectedRowId);
            });
            var data = {
                "REQUESTOR_NAME": getUsername(),
                "InsertUsersDetailsInput": [{
                    "PERSON_ID": selectedTemplate.PERSON_ID,
                    "PERNR": selectedTemplate.PERNR,
                    "BUSINESS_UNIT": selectedTemplate.BUSINESS_UNIT,
                    "TITLE": selectedTemplate.TITLE,
                    "ATTRIBUTE1": selectedTemplate.NTID,
                    "ATTRIBUTE2": selectedTemplate.EMPLOYEE_NAME
                }]
            }
            this.availableUserModelAdd.addToSelectedUsers(data)
        },
        deleteSelectedUser: function(element) {
            showLoadingIndicator();
            var selectedRowId = $(element.currentTarget).prop('id');
            var list = this.SelectedEmployeesTabData.SelectedUsersListOutput;
            var selectedTemplate = _.find(list, function(item) {
                return item.PERSON_ID === Number(selectedRowId);
            });
            var data = {
                "REQUESTOR_NAME": getUsername(),
                "DeleteUsersInput": [{
                    "PERSON_ID": selectedTemplate.PERSON_ID,
                    "BUSINESS_UNIT": selectedTemplate.BUSINESS_UNIT
                }]
            }
            this.selectedUserModelDelete.deleteSelectedUser(data)

        },
        resultAfterInsert: function(data) {
            hideLoadingIndicator();
            if (data.toJSON().STATUS == "SUCCESS") {
                modalMsg(data.toJSON().STATUS_MESSAGE, "success");
            } else {
                modalMsg(data.toJSON().STATUS_MESSAGE, "error");
            }
            this.loadAvailableEmployees();
        },
        resultAfterDelete: function(data) {
            if (data.toJSON().STATUS == "SUCCESS") {
                modalMsg(data.toJSON().STATUS_MESSAGE, "success");
            } else {
                modalMsg(data.toJSON().STATUS_MESSAGE, "error");
            }
            this.loadSelectedEmployees();
        },
        backButtonAction: function() {
            this.toggleView();
        }


    });

    return RegionEmployeesView;
});