define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'collections/selectreserve',
    'collections/selectunreserve',
    'models/osoconfirm',
    'models/osoreserve'
], function($, _, Backbone, JST, SelectReserveCollection, SelectUnreserveCollection, OSOConfirmModel, OSOReserveModel) {
    'use strict';

    var OutstandingSalesView = Backbone.View.extend({
        template: JST['app/scripts/templates/outstandingsales.ejs'],
        itemTemplate: JST['app/scripts/templates/outstandingsalesitem.ejs'],
        emptyTemplate: JST['app/scripts/templates/norecords.ejs'],
        //model: '',
        selectedTab: "reserve",
        selectReserveCollection: new SelectReserveCollection(),
        selectUnreserveCollection: new SelectUnreserveCollection(),
        osoConfirmModel: new OSOConfirmModel(),
        osoReserveModel: new OSOReserveModel(),
        el: '#container',
        itemEl: "#items_container",

        id: '',
        viewName: 'outstandingSalesOrderView',
        events: {
            "click #oso_filter_btn": "toggleView",
            "click #oso_qr_btn": "toggleView",
            "click #btn_qr_scan": "scanQR",
            "click #togbtn_inq_reserve": "loadInquiryReserveData",
            "click #togbtn_conf_ship": "loadConfirmShippingData",
            "click #btn_osales_go": "loadData",
            "click #mobile_oso_btn_go": "loadData",
            "click #btn_oso_reserveAll": "reserveAll",
            "click #btn_oso_confirmAll": "confirmAll",
            "change #sort_filter": "sortItems",
            "change #sort_filter_mobile": "sortItems",
            "keyup #oso_search_filter": "filterItems",
            "keyup #oso_search_filter_mobile": "filterItems",
            "click .btn-qty-operation": function(event) {
                var itemId = $(event.currentTarget).attr("data-id");
                var quantity = $(event.currentTarget.parentElement.parentElement).find('input').val();
                if (event.currentTarget.innerHTML === "Reserve") {
                    this.reserveItem(itemId, quantity);
                } else {
                    this.confirmItem(itemId, quantity);
                }
            }
        },
        initialize: function() {
            this.listenTo(this.selectReserveCollection, 'reset sort', this.renderSelectReserve);
            this.listenTo(this.selectUnreserveCollection, 'reset sort', this.renderSelectUnreserve);
            this.listenTo(this.osoReserveModel, 'change', this.reserveComplete);
            $(this.itemEl).unbind();
        },
        render: function() {
            this.$el.html(this.template());
            var options = {
                initval: 1,
                min: 1,
                max: 20000000,
                step: 1,
            }
            $("#numspinner_qty").TouchSpin(options);
            this.delegateEvents(this.events);
            $('#btn_oso_confirmAll').hide();
            $(this.itemEl).html(this.emptyTemplate());
            return this;
        },
        loadData: function(event) {
            var cifaItem = "";
            var isoNumber = "";
            if (event.currentTarget.id === "mobile_oso_btn_go") {
                cifaItem = $("#txt_cifa_item_no").val();
                isoNumber = $("#txt_iso_no").val();
                if ($('#txt_cifa_item_no').val() === "") {
                    modalMsg("Please Scan/Enter Item Number", "error");
                    return;
                }
                this.toggleView();
            } else {
                cifaItem = $("#input_item_number").val();
                isoNumber = $("#input_iso_number").val();
                if ($('#input_item_number').val() === "") {
                    modalMsg("Please Enter Item Number", "error");
                    return;
                }
            }


            var preferences = JSON.parse(sessionStorage.getItem("preferences"));

            if (this.selectedTab === "reserve") {
                var dataInput = {
                    "requestor_user_name": getUsername(),
                    "cifa_item": cifaItem,
                    "source_organization": preferences.SOURCE_LOCATION,
                    "iso_number": isoNumber
                }
                this.selectReserveCollection.fetchData(dataInput);
            } else {
                var dataInput = {
                    "requestor_user_name": getUsername(),
                    "cifa_item": cifaItem,
                    "source_organization": preferences.SOURCE_LOCATION,
                    "iso_number": isoNumber
                }
                this.selectUnreserveCollection.fetchData(dataInput);
            }
        },
        renderSelectReserve: function(data) {
            $(this.itemEl).empty();

            if (data.isEmpty()) {
                $(this.itemEl).html(this.emptyTemplate());
                return;
            }

            var _this = this;
            data.models.forEach(function(model) {
                var item = model.toJSON();
                item.qtyLabelText = globalize.qtyToReserve;
                item.qtyBtnText = globalize.reserve;
                $(_this.itemEl).append(_this.itemTemplate(item));
            });
            var options = {
                initval: 1,
                min: 1,
                max: 20000000,
                step: 1,
            }
            $(".numberspinner").TouchSpin(options);
            this.delegateEvents(this.events);
            showHeaderButtons(false, true, "", "Reserve All");
            enableDone();
            hideLoadingIndicator();
        },

        renderSelectUnreserve: function(data) {
            $(this.itemEl).empty();

            if (data.isEmpty()) {
                $(this.itemEl).html(this.emptyTemplate());
                return;
            }

            var _this = this;
            data.models.forEach(function(model) {
                var item = model.toJSON();
                item.qtyLabelText = globalize.qtyToShip;
                item.qtyBtnText = globalize.confirm;
                //if (item.available_to_reserve) {
                $(_this.itemEl).append(_this.itemTemplate(item));
                //}
            });
            var options = {
                initval: 1,
                min: 1,
                max: 20000000,
                step: 1,
            }
            $(".numberspinner").TouchSpin(options);
            this.delegateEvents(this.events);
            showHeaderButtons(false, true, "", "Confirm All");
            enableDone();
            hideLoadingIndicator();
        },

        loadInquiryReserveData: function() {
            this.selectedTab = "reserve";
            $('#togbtn_conf_ship').removeClass('btn-selected');
            $('#togbtn_inq_reserve').addClass('btn-selected');
            $('#btn_oso_reserveAll').show();
            $('#btn_oso_confirmAll').hide();
            $(this.itemEl).empty();
            $(this.itemEl).unbind();
            //showHeaderButtons(false, true, "Reset", "Reserve All");
            hideHeaderButtons()
        },
        loadConfirmShippingData: function() {
            this.selectedTab = "unreserve";
            $('#togbtn_conf_ship').addClass('btn-selected');
            $('#togbtn_inq_reserve').removeClass('btn-selected');
            $('#btn_oso_reserveAll').hide();
            $('#btn_oso_confirmAll').show();
            $(this.itemEl).empty();
            $(this.itemEl).unbind();
            //showHeaderButtons(false, true, "Reset", "Confirm All");
            hideHeaderButtons();
        },

        reserveItem: function(itemId, quantity) {
            var item = this.selectReserveCollection.find(function(model) { return model.get('requisition_number') === itemId; }).toJSON();

            var input = {
                "InputType": []
            }

            var data = {
                "P_SO_HEADER_ID": item.iso_header_id,
                "P_SO_LINE_ID": item.iso_line_id,
                "P_REQUESTOR": getUsername(),
                "P_RESERVE_QTY": quantity,
                "P_SUBINVENTORY": item.subinventory_code,
                "P_LOCATOR_ID": item.locator
            }
            input.InputType.push(data);
            this.osoReserveModel.reserveQuantityRequest(input);
        },

        confirmItem: function(itemId, quantity) {
            var item = this.selectUnreserveCollection.find(function(model) { return model.get('requisition_number') === itemId; }).toJSON();
            var input = {
                "InputType": []
            }
            var data = {
                "P_SO_HEADER_ID": item.header_id,
                "P_SO_LINE_ID": item.line_id,
                "P_REQUESTOR": getUsername(),
                "P_QTY": quantity,
                "P_SUBINVENTORY": item.subinventory_code,
                "P_LOCATOR_ID": item.locator
            };
            input.InputType.push(data);
            this.osoConfirmModel.releaseBatchRequest(input);
        },

        reserveAll: function() {
            if (this.selectReserveCollection.isEmpty()) {
                return;
            }
            var input = {
                "InputType": []
            }
            this.selectReserveCollection.each(function(model) {
                var item = model.toJSON();
                var data = {
                    "P_SO_HEADER_ID": item.iso_header_id,
                    "P_SO_LINE_ID": item.iso_line_id,
                    "P_REQUESTOR": getUsername(),
                    "P_RESERVE_QTY": $("#numspinner_qty_" + item.line_number).val(),
                    "P_SUBINVENTORY": item.subinventory_code,
                    "P_LOCATOR_ID": item.locator
                }
                input.InputType.push(data);
            });
            this.osoReserveModel.reserveQuantityRequest(input);
        },

        confirmAll: function() {
            if (this.selectUnreserveCollection.isEmpty()) {
                return;
            }
            var input = {
                "InputType": []
            }
            this.selectUnreserveCollection.each(function(model) {
                var item = model.toJSON();
                var data = {
                    "P_SO_HEADER_ID": item.header_id,
                    "P_SO_LINE_ID": item.line_id,
                    "P_REQUESTOR": getUsername(),
                    "P_RESERVE_QTY": $("#numspinner_qty_" + item.line_number).val(),
                    "P_SUBINVENTORY": item.subinventory_code,
                    "P_LOCATOR_ID": item.locator
                }
                input.InputType.push(data);
            });
            this.osoConfirmModel.releaseBatchRequest(input);
        },

        toggleView: function(event) {
            if ($('#oso_page').css('display') === "none") {
                $('#oso_page').show();
                $('#oso_filter').hide();
                $('#oso_scanner').hide();
                hideHeaderButtons();
                toggleBackButton();
            } else if (event.currentTarget.id === "oso_qr_btn") {
                $('#oso_page').hide();
                $('#oso_scanner').show();
                showHeaderButtons(false, true, "Reset", "Done");
                toggleBackButton();
                enableDone();
            } else if (event.currentTarget.id === "oso_filter_btn") {
                $('#oso_page').hide();
                $('#oso_filter').show();
                showHeaderButtons(false, true, "Reset", "Done");
                toggleBackButton();
                enableDone();
            }
        },

        backButtonAction: function() {
            this.toggleView();
        },


        reserveComplete: function(data) {
            //var items = data.toJSON().OutputType;
            //modalMsg(data.toJSON()[0].STATUS, "success");
        },

        sortItems: function(event) {
            $('#oso_search_filter').val("");
            var value = event.currentTarget.value;
            if (this.selectedTab === "reserve") {
                this.selectReserveCollection.changeSort(value);
            } else {
                this.selectUnreserveCollection.changeSort(value);
            }
        },

        filterItems: function(event) {
            var value = event.currentTarget.value;
            if (this.selectedTab === "reserve") {
                this.renderSelectUnreserve(this.selectReserveCollection.search(value));
            } else {

            }
        },

        scanQR: function() {
            if (isPhoneGap()) {
                cordova.plugins.barcodeScanner.scan(
                    function(result) {
                        $("#txt_cifa_item_no").val(result.text);

                        console.log("We got a barcode\n" +
                            "Result: " + result.text + "\n" +
                            "Format: " + result.format + "\n" +
                            "Cancelled: " + result.cancelled);
                    },
                    function(error) {
                        console.log("Scanning failed: " + error);
                    }, {
                        "preferFrontCamera": false, // iOS and Android
                        "showFlipCameraButton": true, // iOS and Android
                        "prompt": "Place a QR code inside the scan area", // supported on Android only
                        "formats": "QR_CODE", // default: all but PDF_417 and RSS_EXPANDED
                        "orientation": "portrait" // Android only (portrait|landscape), default unset so it rotates with the device
                    }
                );
            }
        },

        rightbuttonAction: function(event) {
            if (event.currentTarget.innerHTML === "Reserve All") {
                this.reserveAll();
            } else if (event.currentTarget.innerHTML === "Confirm All") {
                this.confirmAll();
            } else {
                this.toggleView();
            }
        }


    });

    return OutstandingSalesView;
});