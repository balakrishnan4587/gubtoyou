/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/itemdetails',
    'models/addtocart'
], function($, _, Backbone, JST, ItemDetailsModel, CartModel) {
    'use strict';

    var ItemDetailsView = Backbone.View.extend({
        template: JST['app/scripts/templates/itemdetails.ejs'],
        viewName: 'itemDetailsView',
        el: '#container',
        tagName: 'div',
        model: new ItemDetailsModel(),
        id: '',
        className: '',
        events: {
            'click .btn-details-back': 'goToFavorites',
            'click .add-to-cart': 'addToCart',
            'click .select_source': 'loadSelectSource',
            'click .large-img': 'largeImageModal',
            'click .mf_addtocart': 'mfAddToCart'

        },

        initialize: function() {
            this.cartmodel = new CartModel();
            this.listenTo(this.model, 'change', this.render);
        },

        render: function(data) {
            $('#favorites-header').hide();
            $('.filter-mobile').hide();
            this.detailsresponse = data.toJSON().ItemDetailsOutput[0];
            this.$el.html(this.template(this.detailsresponse));
            hideLoadingIndicator();
            this.delegateEvents(this.events);
            hideLoadingIndicator();
            return this;
        },
        goToFavorites: function() {

            var previous = breadCrumbs[breadCrumbs.length - 2];
            if (previous) {
                this.close();
                window.location.href = previous.href;
            } else {
                this.close();
                window.history.back();
            }
        },
        backButtonAction: function() {

            toggleBackButton();
            var previous = breadCrumbs[breadCrumbs.length - 2];
            if (previous) {
                window.location.href = previous.href;
                this.close();
            } else {
                this.close();
                window.history.back();
            }

        },
        loadSelectSource: function(element) {
            this.goTo("#select_source?=" + this.detailsresponse.CIFA_ITEM_NUMBER);
        },
        addToCart: function() {
            var qty = 1;
            var needbydate = localStorage.getItem('needbyDate') + "T00:00:00";
            var currentFavItem = JSON.parse(localStorage.getItem('currentFavItem'));

            if (_.findWhere(breadCrumbs, { name: 'ShoppingCart' })) {
                qty = sessionStorage.getItem("currentitemquantity");
                needbydate = sessionStorage.getItem("currentitemneedByDate") + "T00:00:00";
            } else {
                qty = currentFavItem.quantity;
                needbydate = currentFavItem.needByDate + "T00:00:00";
            }
            qty = (qty == null) ? '1' : qty;
            var cartInputData = {
                "ShoppingCartUpsertData": [{
                    "CIFA_ITEM_NUMBER": this.detailsresponse.CIFA_ITEM_NUMBER,
                    "ITEM_DESC": this.detailsresponse.ITEM_DESCRIPTION,
                    "ITEM_CATEGORY": this.detailsresponse.CATEGORY,
                    "QUANTITY": qty,
                    "NEED_BY_DATE": needbydate,
                    "USER_NAME": getUsername()
                }]

            }
            showLoadingIndicator();
            this.cartmodel.addToCartRequest(cartInputData);
        },
        mfAddToCart: function(element) {
            var eid = $(element.currentTarget).prop("id");
            var tempeid = eid.split("_");
            var mfpartno = tempeid[1];
            //console.log("mfpartno..." + mfpartno);

            var qty = 1;
            var needbydate = localStorage.getItem('needbyDate') + "T00:00:00";
            var currentFavItem = JSON.parse(localStorage.getItem('currentFavItem'));

            if (_.findWhere(breadCrumbs, { name: 'ShoppingCart' })) {
                qty = sessionStorage.getItem("currentitemquantity");
                needbydate = sessionStorage.getItem("currentitemneedByDate") + "T00:00:00";
            } else {
                qty = currentFavItem.quantity;
                needbydate = currentFavItem.needByDate + "T00:00:00";
            }
            qty = (qty == null) ? '1' : qty;
            var cartInputData = {
                "ShoppingCartUpsertData": [{
                    "CIFA_ITEM_NUMBER": this.detailsresponse.CIFA_ITEM_NUMBER,
                    "ITEM_DESC": this.detailsresponse.ITEM_DESCRIPTION,
                    "ITEM_CATEGORY": this.detailsresponse.CATEGORY,
                    "QUANTITY": qty,
                    "NEED_BY_DATE": needbydate,
                    "USER_NAME": getUsername(),
                    "VENDOR_ITEM_NUMBER": mfpartno,
                }]

            }
            showLoadingIndicator();
            this.cartmodel.addToCartRequest(cartInputData);
        },

        largeImageModal: function(element) {
            //console.log($(element.currentTarget).data("imgsrc"));
            modalImage($(element.currentTarget).data("imgsrc"))
        }

    });

    return ItemDetailsView;
});