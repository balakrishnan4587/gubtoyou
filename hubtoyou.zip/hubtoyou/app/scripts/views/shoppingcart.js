/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'datepicker',
    'templates',
    'models/shoppingcart',
    'views/selectprojectnumber',
    'views/selectlocation',
    'views/tasknumber',
    'models/searchprojectdetails',
    'models/searchwarehouse',
    'views/expendituretype',
    'models/addtocart',
    'models/submitcart',
    'models/tasknumber',
    'models/expendituretype',
    'models/clearcart',
], function($, _, Backbone, datepicker, JST, ShoppingCartModel, SelectProjectNumberView,
    SelectLocationView, SelectTaskNumberView, SearchProjectDetailsModel, SearchWarehouseModel,
    SelectExpenditureTypeView, SaveCartModel, SubmitCartModel, TaskNumberModel, ExpenditureTypeModel, ClearCartModel) {
    'use strict';

    var ShoppingCartView = Backbone.View.extend({
        template: JST['app/scripts/templates/shoppingcart.ejs'],
        updateCartNeedByDate: JST['app/scripts/templates/updatecartneedbydate.ejs'],
        updateCartSrc: JST['app/scripts/templates/updatecartsrcloc.ejs'],
        updateCartDel: JST['app/scripts/templates/updatecartdelloc.ejs'],
        updateCartExpType: JST['app/scripts/templates/updatecartexptype.ejs'],
        updateCartExpDate: JST['app/scripts/templates/updatecartexpdate.ejs'],
        noRecords: JST['app/scripts/templates/norecords.ejs'],
        mobileUpdateCart: JST['app/scripts/templates/updatecartlinemobile.ejs'],
        offlineCartItemTemplate: JST['app/scripts/templates/offlinecartitem.ejs'],
        viewName: 'ShoppingCartView',
        el: '#container',
        tagName: 'div',
        model: new ShoppingCartModel(),
        id: '',
        className: '',
        updateCartReq: {},
        events: {
            'click #update-cart-accordian': 'toggleUdpateCartLine', //update cartlines toggle
            //'click #UC_loadProjNo': 'loadProjectSelectionWindow',
            'click #update_submit': 'updateDetails',
            'click .project-number-search-select': 'loadProjectSelectionWindow',
            'click .src-location-search-select': 'loadSourceLocationWindow',
            'click .to-location-search-select': 'loadDeliveryLocationWindow',
            'change .project-no-validation': 'updateProjectNumber',
            'change .src-loc-validation': 'updateSrc',
            'change .del-loc-validation': 'updateDest',
            'change #sc_update_cartlines_select': 'ChooseUpdateCartLinesInput', //dropdown select for project details/other details
            'change #sc_update_cartlines_field_select': 'renderInputForField', //render input for selected field input
            'change #sc_update_cartlines_mobile_select': 'ChooseUpdateCartLinesInputMobile', //dropdown select for project details/other details
            'change #sc_update_cartlines_mobile_field_select': 'renderInputForFieldMobile', //render input for selected field input             
            'click .task-number-select': 'loadTasknumberWindow',
            'click .expenditure-type-select': 'loadExpenditureTypeWindow',
            'click .delete-bg': 'deleteCartItem',
            'click #savecartdetailsbtn': 'saveCartItems',
            'click .show-update-cart': 'showUpdateCartLinesForMobile',
            'change .savecartquantity': 'saveCartQuantity',
            'changeDate .savecartneedbydate': 'saveCartNeedByDate',
            'changeDate .savecartexpenditemdate': 'saveCartExpendItemDate',
            'change textarea': 'saveCartNoteToApprover',
            'click #submitcartdetailsbtn': 'submitCartItems',
            'change .task-number-validation': 'updateTaskNumber',
            'change .exp-type-validation': 'updateExpType',
            'click #clearcartbtn': 'clearCart',
            'changeDate .updatecartneedbydate': 'enableDisableUpdateBtn',
            'changeDate .updatecartexpenditemdate': 'enableDisableUpdateBtn',
            'click .cart-to-itemdetails': "goToItemDetails",
            'click #btn_clearoffline': 'clearOfflineItems'
        },

        initialize: function() {
            //AppView.currentView = this;
            this.objForDelete = new ShoppingCartModel();
            this.prDetails = new SearchProjectDetailsModel();
            this.wareHouse = new SearchWarehouseModel();
            this.wareHouseDest = new SearchWarehouseModel();
            this.submitcart = new SubmitCartModel();
            this.tasknumber = new TaskNumberModel();
            this.expenditureTypeResults = new ExpenditureTypeModel();
            this.clearcart = new ClearCartModel();
            this.listenTo(this.model, 'change', this.render);
            this.listenTo(this.objForDelete, 'change', this.renderAfterDelete);
            this.listenTo(this.prDetails, 'sync', this.validationResultProjectNo);
            this.listenTo(this.wareHouse, 'sync', this.validationResultSrc);
            this.listenTo(this.wareHouseDest, 'sync', this.validationResultDest);
            this.listenTo(this.submitcart, 'change', this.AfterSubmit);
            this.listenTo(this.tasknumber, 'change', this.validationResultTaskNo);
            this.listenTo(this.expenditureTypeResults, 'change', this.validationResultExpType); //search for locations  
            this.listenTo(this.clearcart, 'sync', this.AfterClearCart);

            this.updateProjectDetailsBtn = true;
        },

        render: function(data) {
            var dataitems = data.responseData;
            if (typeof dataitems.ShoppingCartDetails == "undefined") {
                this.$el.html(this.noRecords()); //Display No records View
                hideLoadingIndicator();
                return;
            }
            var listitems = dataitems.ShoppingCartDetails;
            if (listitems.length > 0) {
                listitems = sortByKey(listitems, "LINE_NUMBER");
            }
            /*if (sessionStorage.getItem("deletelineid") > 0) {
                sessionStorage.setItem("deletelineid", "");
            } else {
                sessionStorage.setItem("saveCartDetails", JSON.stringify(listitems));
            }*/
            sessionStorage.setItem("saveCartDetails", JSON.stringify(listitems));
            showHeaderButtons(false, true, "Reset", "Submit");
            enableDone();
            this.model1 = { "ShoppingCartDetails": listitems };
            this.$el.html(this.template(this.model1));
            sessionStorage.setItem("cartItemsCount", listitems.length);
            updateCartCount();
            hideLoadingIndicator();

            if (listitems.length > 0) {
                if (isOnline) {
                    var user = getUsername();
                    offlineDB.clearData("CART", user);
                }

                listitems.forEach(function(item, index) {

                    if (isOnline && offlineDB) {
                        item.username = user;
                        offlineDB.addData("CART", user, item);
                    }

                    var spin_id = "#numspinner_" + item.LINE_ID;
                    var min_val = (item.MinimumOrder === null) ? 1 : item.MinimumOrder;
                    var max_val = (item.MaximumOrder === null) ? 2147483647 : item.MaximumOrder;
                    var interval = (item.FixedLot === null) ? 1 : item.FixedLot;

                    var options = {
                        initval: item.QUANTITY,
                        min: min_val,
                        max: max_val,
                        step: interval,
                    }
                    $(spin_id).TouchSpin(options);
                });

            }



            if (isPhoneGap()) {
                $('.dateinput').focus(function() {
                    var options = {
                        date: new Date(),
                        mode: 'date',
                        target: this
                    };

                    datePicker.show(options, function(date) {
                        $(options.target).val(date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate());
                        if ($(options.target).val() !== "") {
                            enableDone();
                        }
                    });
                });
            } else {
                $('.dateinput').datepicker({
                    autoclose: true,
                    format: "yyyy-mm-dd",
                    startDate: new Date()
                });
            }

            globalize.currOtherDetailsElement = '#uc_date_needby'; //default setting input as needbydate
            globalize.changeProperty = 'NEED_BY_DATE' //default settin property as input date
            $('.other-details-update-field').hide();

            //Render offline items
            if (!isOnline) {
                var user = sessionStorage.getItem("offlineUser");
                this.$el.find('.view-container').append("<div class='container gray-bg pad10tb'><h4 class='sub-heading inline' style='line-height:34px'>Offline Items</h4><button id='btn_clearoffline' class='btn inline pull-right'>Clear All</button></div><div id='offline_container'></div>")
                var me = this;
                offlineDB.getAllData("CARTOFFLINE", user, function(items) {
                    if (items.length > 0) {
                        items.forEach(function(item) {
                            me.$el.find('#offline_container').append(me.offlineCartItemTemplate(item));
                        });
                    } else {
                        $('#offline_container').append(me.noRecords());
                    }
                });
            }

            this.delegateEvents(this.events);
            return this;

        },
        bindingDateField: function() {
            if (isPhoneGap()) {
                $('.dateinput').focus(function() {
                    var options = {
                        date: new Date(),
                        mode: 'date',
                        target: this
                    };

                    datePicker.show(options, function(date) {
                        $(options.target).val(date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate());
                        $('#update_submit').removeClass('button-disable-opacity');
                        enableDone();
                    });
                });
            } else {
                $('.dateinput').datepicker({
                    autoclose: true,
                    format: "yyyy-mm-dd",
                    startDate: new Date()
                });
            }
        },
        enableDisableUpdateBtn: function(element) {
            if ($(element.currentTarget).data('lineno') === undefined) {
                $('#update_submit').removeClass('button-disable-opacity');
                enableDone();
            }
        },
        renderUpdatedCart: function(listitems) {
            if (listitems.length > 0) {
                listitems = sortByKey(listitems, "LINE_NUMBER");
            }
            this.model1 = { "ShoppingCartDetails": listitems };
            this.$el.html(this.template(this.model1));
            $('.other-details-update-field').hide();
            this.updateProjectDetailsBtn = true;
            this.bindingDateField();
            if (listitems.length > 0) {
                if (isOnline) {
                    var user = getUsername();
                    offlineDB.clearData("CART", user);
                }

                listitems.forEach(function(item, index) {

                    if (isOnline && offlineDB) {
                        item.username = user;
                        offlineDB.addData("CART", user, item);
                    }

                    var spin_id = "#numspinner_" + item.LINE_ID;
                    var min_val = (item.MinimumOrder === null) ? 1 : item.MinimumOrder;
                    var max_val = (item.MaximumOrder === null) ? 2147483647 : item.MaximumOrder;
                    var interval = (item.FixedLot === null) ? 1 : item.FixedLot;

                    var options = {
                        initval: item.QUANTITY,
                        min: min_val,
                        max: max_val,
                        step: interval,
                    }
                    $(spin_id).TouchSpin(options);
                });

            }
        },
        /*Update cart lines*/
        toggleUdpateCartLine: function(element) {
            if ($('.update-cart-line-container').is(':visible')) {
                $('.update-cart-line-container').fadeOut(500);
                $('#update-caret-btn').removeClass('caret-up');
                $('#update-caret-btn').addClass('caret-down');
                return false;
            } else {
                $('.update-cart-line-container').fadeIn(500);
                $('#update-caret-btn').removeClass('caret-down');
                $('#update-caret-btn').addClass('caret-up');
                return false;
            }
            /*

                        if ($('#update-caret-btn').hasClass('caret-up')) {
                            $('#update-caret-btn').removeClass('caret-up');
                            $('#update-caret-btn').addClass('caret-down');
                        } else {
                            $('#update-caret-btn').removeClass('caret-down');
                            $('#update-caret-btn').addClass('caret-up');
                        }
                        return false;*/
        },
        ChooseUpdateCartLinesInput: function(element) {
            if (element.currentTarget.value == "projectDetails") {
                $('.project-details-update-field').show();
                $('.other-details-update-field').hide();
                $('.other-sub-details-update-field').empty();
                this.updateProjectDetailsBtn = true;
                this.needByDateUpdate = false;
                this.resetUpdateInputFields();
                $('#sc_update_projectNo').val('');
            } else {
                $('#sc_update_cartlines_field_select').val('needByDate'); //to make need by default as selecte dvalue in dropdown
                $('.other-details-update-field').show();
                $('.project-details-update-field').hide();
                /*Re render need by date field input in DOM */
                $('.other-sub-details-update-field').html(this.updateCartNeedByDate());
                this.bindingDateField();
                globalize.currOtherDetailsElement = '#uc_date_needby';
                globalize.changeProperty = 'NEED_BY_DATE'
                    /*Ends */
                this.updateProjectDetailsBtn = false;
                this.needByDateUpdate = true;
            }
        },
        renderInputForField: function(element) {
            if (element.currentTarget.value == "delLocation") {
                $('.other-sub-details-update-field').html(this.updateCartDel());
                globalize.currOtherDetailsElement = '#uc_del_loc';
                globalize.changeProperty = 'DELIVERY_LOCATION_CODE'
            } else if (element.currentTarget.value == "srcLocation") {
                $('.other-sub-details-update-field').html(this.updateCartSrc());
                globalize.currOtherDetailsElement = '#uc_src_loc';
                globalize.changeProperty = 'SOURCE_ORGANIZATION_CODE'
            } else if (element.currentTarget.value == "expType") {
                $('.other-sub-details-update-field').html(this.updateCartExpType);
                globalize.currOtherDetailsElement = '#uc_exp_type';
                globalize.changeProperty = 'EXPENDITURE_TYPE'
            } else if (element.currentTarget.value == "expDate") {
                $('.other-sub-details-update-field').html(this.updateCartExpDate);
                this.bindingDateField();
                globalize.currOtherDetailsElement = '#uc_date_exp';
                globalize.changeProperty = 'EXPENDITURE_ITEM_DATE'
            } else {
                $('.other-sub-details-update-field').html(this.updateCartNeedByDate());
                this.bindingDateField();
                globalize.currOtherDetailsElement = '#uc_date_needby';
                globalize.changeProperty = 'NEED_BY_DATE'
            }
            $('#update_submit').addClass('button-disable-opacity');

        },
        ChooseUpdateCartLinesInputMobile: function(element) {
            disableDone();
            if (element.currentTarget.value == "projectDetails") {
                $('.project-details-update-field-mobile').show();
                $('.project-other-details-update-field-mobile').hide();
                this.updateProjectDetailsBtn = true;
                this.needByDateUpdate = false;
                this.resetUdpateInputFieldsMobile();
            } else {
                $('.project-details-update-field-mobile').hide();
                $('.project-other-details-update-field-mobile').show();
                $('#sc_update_cartlines_mobile_field_select').val('')
                $('#update_cart_Mobile_input').html(this.updateCartNeedByDate());
                this.updateProjectDetailsBtn = false;
                this.needByDateUpdate = true;
                this.bindingDateField();
                globalize.currOtherDetailsElement = '#uc_date_needby_mob';
                globalize.changeProperty = 'NEED_BY_DATE'
            }
        },
        renderInputForFieldMobile: function(element) {
            if (element.currentTarget.value == "delLocation") {
                $('#update_cart_Mobile_input').html(this.updateCartDel());
                globalize.currOtherDetailsElement = '#uc_del_loc_mob';
                globalize.changeProperty = 'DELIVERY_LOCATION_CODE'
            } else if (element.currentTarget.value == "srcLocation") {
                $('#update_cart_Mobile_input').html(this.updateCartSrc());
                globalize.currOtherDetailsElement = '#uc_src_loc_mob';
                globalize.changeProperty = 'SOURCE_ORGANIZATION_CODE'
            } else if (element.currentTarget.value == "expType") {
                $('#update_cart_Mobile_input').html(this.updateCartExpType);
                globalize.currOtherDetailsElement = '#uc_exp_type_mob';
                globalize.changeProperty = 'EXPENDITURE_TYPE'
            } else if (element.currentTarget.value == "expDate") {
                $('#update_cart_Mobile_input').html(this.updateCartExpDate);
                this.bindingDateField();
                globalize.currOtherDetailsElement = '#uc_date_exp_mob';
                globalize.changeProperty = 'EXPENDITURE_ITEM_DATE'
            } else {
                $('#update_cart_Mobile_input').html(this.updateCartNeedByDate());
                this.bindingDateField();
                globalize.currOtherDetailsElement = '#uc_date_needby_mob';
                globalize.changeProperty = 'NEED_BY_DATE'
            }
            disableDone();
        },
        updateDetails: function() {
            var updatedList = [];
            var temp = this.model.toJSON().ShoppingCartDetails;

            if (this.updateProjectDetailsBtn) {
                var projectInputValue = $('#sc_update_projectNo').val();
                var taskInputValue = $('#sc_update_taskNo').val();
                for (var i = 0; i < temp.length; i++) {
                    temp[i].PROJECT_NUMBER = projectInputValue;
                    temp[i].TASK_NUMBER = taskInputValue
                }
                /* update cart details json */
                var keyparam = $('#sc_update_projectNo').data("keyparam");
                saveCartDetails(keyparam, projectInputValue);
                var keyparam = $('#sc_update_taskNo').data("keyparam");
                saveCartDetails(keyparam, taskInputValue);
            } else {
                for (var i = 0; i < temp.length; i++) {
                    temp[i][globalize.changeProperty] = $(globalize.currOtherDetailsElement).val();
                }
                var keyparam = globalize.changeProperty; //property/key value
                var updatevalue = $(globalize.currOtherDetailsElement).val();
                //saveCartDetails(keyparam, updatevalue);
            }

            /* update cart details json */
            this.renderUpdatedCart(temp);
        },
        /*ends*/
        updateProjectNumber: function(element, data) {
            if (_.isUndefined(data)) {
                this.updateCartReq.PROJECT_NUMBER = element.currentTarget.value;
                /* update cart details json */
                var inpuval = $(element.currentTarget).val();
                var lineid = $(element.currentTarget).data("lineno");
                var keyparam = $(element.currentTarget).data("keyparam");
                saveCartDetails(keyparam, inpuval, lineid);
                /* update cart details json */
                globalize.projectNoInputBox = element.currentTarget;
                if ($(element.currentTarget).prop('id') == "sc_update_projectNo" ||
                    $(element.currentTarget).prop('id') == "sc_update_projectNo_mob") {
                    this.updatecartFlow = true;

                }
                if (inpuval == "") {
                    $("#tasknumber-cart_" + lineid).prop("disabled", true);
                    // $("#expenditure-type-cart_" + lineid).prop("disabled", true); //added to enable/disable exp type
                }
                this.checkEmptyField(this.updateCartReq.PROJECT_NUMBER, globalize.projectNoInputBox)
                if (this.updateCartReq.PROJECT_NUMBER !== '') {
                    $("#tasknumber-cart_" + lineid).prop("disabled", false);
                    //$("#expenditure-type-cart_" + lineid).prop("disabled", true); //added to enable/disable exp type
                    this.validateProjectNumber();
                }
            } else {
                this.updateCartReq.PROJECT_NUMBER = data.data.ProjectNumber;
                this.updateCartReq.PROJECT_ID = data.data.ProjectId;
                sessionStorage.setItem('projectId', data.data.ProjectId);
                sessionStorage.setItem('projectNumber', data.data.ProjectNumber);
                /* update cart details json */
                var inpuval = data.data.ProjectNumber;
                var lineid = $(element.currentTarget).data("lineno");
                var keyparam = "PROJECT_NUMBER";
                saveCartDetails(keyparam, inpuval, lineid);
                /* update cart details json */
                $("#tasknumber-cart_" + lineid).prop("disabled", false);
                /* update cart details json */
                var inpuval1 = data.data.ProjectId;
                var lineid1 = $(element.currentTarget).data("lineno");
                var keyparam1 = "PROJECT_ID";
                saveCartDetails(keyparam1, inpuval1, lineid1);
                /* update cart details json */
                if ($(element.currentTarget).prop('id') == "sc_update_projectNo" ||
                    $(element.currentTarget).prop('id') == "sc_update_projectNo_mob") {
                    this.updatecartFlow = true;
                    $('#sc_update_taskNo').attr('data-projectid', data.data.ProjectId);
                    $('#sc_update_taskNo').attr('data-tasktype', data.data.taskType);
                    $('#sc_update_taskNo').attr('data-projectno', data.data.ProjectNumber);
                    $('#uc_taskno_container').removeClass('button-disable-opacity');

                }
            }
        },
        updateSrc: function(element) {
            this.updateCartReq.SOURCE_LOCATION = element.currentTarget.value;
            globalize.srcInputBox = element.currentTarget;
            /* update cart details json */
            var inpuval = $(element.currentTarget).val();
            var lineid = $(element.currentTarget).data("lineno");
            var keyparam = $(element.currentTarget).data("keyparam");
            saveCartDetails(keyparam, inpuval, lineid);
            /* update cart details json */
            this.checkEmptyField(this.updateCartReq.SOURCE_LOCATION, globalize.srcInputBox);
            if (this.updateCartReq.SOURCE_LOCATION !== '') {
                this.validateSrc();
            }
        },
        updateDest: function(element) {
            this.updateCartReq.DELIVERY_TO_LOCATION = element.currentTarget.value;
            globalize.deliveryLocInputBox = element.currentTarget;
            /* update cart details json */
            var inpuval = $(element.currentTarget).val();
            var lineid = $(element.currentTarget).data("lineno");
            var keyparam = $(element.currentTarget).data("keyparam");
            saveCartDetails(keyparam, inpuval, lineid);
            /* update cart details json */
            this.checkEmptyField(this.updateCartReq.DELIVERY_TO_LOCATION, globalize.deliveryLocInputBox)
            if (this.updateCartReq.DELIVERY_TO_LOCATION !== '') {
                this.validateDest();
            }
        },
        checkEmptyField: function(value, txtElement) {
            if (value == "" && $(txtElement).hasClass('contain-error')) {
                $(txtElement).removeClass('contain-error');
            }
        },
        //Validation logics for the Input fields with service
        validateProjectNumber: function(event) {
            var dataInput = {
                "ProjectNumber": this.updateCartReq.PROJECT_NUMBER
            };
            showLoadingIndicator();
            this.prDetails.fetchData(dataInput);
        },
        validateSrc: function() {
            var dataInput = {
                "ORGANIZATION_CODE": this.updateCartReq.SOURCE_LOCATION
            };
            showLoadingIndicator();
            this.wareHouse.fetchData(dataInput);
        },
        validateDest: function() {
            var dataInput = {
                "LOCATION_CODE": this.updateCartReq.DELIVERY_TO_LOCATION
            };
            showLoadingIndicator();
            this.wareHouseDest.fetchData(dataInput);
        },
        validationResultDest: function(response) {
            hideLoadingIndicator();
            var data = this.wareHouseDest.warehouseResponse;
            if (!_.isUndefined(data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput) && data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput.length == 1) {
                if ($(globalize.deliveryLocInputBox).hasClass('contain-error')) {
                    $(globalize.deliveryLocInputBox).removeClass('contain-error');
                }
                this.model.EXPENDITURE_ORG = data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput.ORGANIZATION_CODE;
                this.model.EXPENDITURE_ORG_ID = data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput.DELIVER_TO_ORG_ID;
                this.validDest = true;
                $('#update_submit').removeClass('button-disable-opacity');
                enableDone();
                //this.validateSettingsBtn();
            } else {
                if (!$(globalize.deliveryLocInputBox).hasClass('contain-error')) {
                    $(globalize.deliveryLocInputBox).addClass('contain-error');
                }
                this.validDest = false;
                disableDone();
                //this.validateSettingsBtn();
            }

        },
        loadProjectSelectionWindow: function(element) {
            globalize.selectedWIndow = "selectProjectNo";
            globalize.modalTitle = globalize.selectProjectNo;
            globalize.projectNoInputBox = element.currentTarget.previousElementSibling;
            if ($(element.currentTarget).prop('id') == "UC_loadProjNo" ||
                $(element.currentTarget).prop('id') == "UC_loadProjNo_Mob") {
                this.updatecartFlow = true;
            }
            if ($(element.currentTarget).is('[data-mobile]')) {
                $('.mobile-update-cart-lines').hide();
                globalize.updateCartLine = true;
            } else {
                $('.shoppingcart-page').hide();
            }
            globalView = this;
            var projectDetailsView = new SelectProjectNumberView();
            breadCrumbs.push({ href: '#', name: 'Search And Select: Project Number' });
            showHeaderButtons(false, true, "Reset", "Done");
            updateBreadCrumbs();
            showBackButton();

        },
        loadSourceLocationWindow: function(element) {
            globalize.modalTitle = globalize.selectSrc;
            globalize.selectedWIndow = "selectSourceWarehouse";
            globalize.srcInputBox = element.currentTarget.previousElementSibling;
            $('.src-location-parent-class').on('change', globalize.srcInputBox, this.updateSrc);
            if ($(element.currentTarget).is('[data-mobile]')) {
                $('.mobile-update-cart-lines').hide();
                globalize.updateCartLine = true;
            } else {
                $('.shoppingcart-page').hide();
            }
            globalView = this;
            var locationDetailsView = new SelectLocationView();
            breadCrumbs.push({ href: '#', name: 'Search And Select: Source Warehouse' });
            showHeaderButtons(false, true, "Reset", "Done");
            updateBreadCrumbs();
            showBackButton();

        },

        loadDeliveryLocationWindow: function(element) {
            globalize.modalTitle = globalize.selectToLocation;
            globalize.selectedWIndow = "selectDeliveryLocation";
            globalize.deliveryLocInputBox = element.currentTarget.previousElementSibling;
            $('.to-location-parent-class').on('change', globalize.deliveryLocInputBox, this.updateSrc);
            if ($(element.currentTarget).is('[data-mobile]')) {
                $('.mobile-update-cart-lines').hide();
                globalize.updateCartLine = true;
            } else {
                $('.shoppingcart-page').hide();
            }
            globalView = this;
            var locationDetailsView = new SelectLocationView();
            breadCrumbs.push({ href: '#', name: 'Search And Select: Delivery To Location' });
            showHeaderButtons(false, true, "Reset", "Done");
            updateBreadCrumbs();
            showBackButton();

        },
        loadTasknumberWindow: function(element) {

            globalize.taskInputBox = element.currentTarget.previousElementSibling;
            globalize.expedituretypeVal = $("#expenditure-type-cart").val();
            var currrId = $(element.currentTarget.previousElementSibling).prop('id').split('_')[1];
            globalize.expedituretypeInputBox = $('#expenditure-type-cart_' + currrId);
            //$('.tasknumber-parent-class').on('change', globalize.taskInputBox, this.updateSrc);
            if ($(element.currentTarget).is('[data-mobile]')) {
                $('.mobile-update-cart-lines').hide();
                globalize.updateCartLine = true;
            } else {
                $('.shoppingcart-page').hide();
            }
            globalView = this;
            var tasknumberView = new SelectTaskNumberView();
            breadCrumbs.push({ href: '#', name: 'Search And Select: Task Number' });
            showHeaderButtons(false, true, "Reset", "Done");
            updateBreadCrumbs();
            showBackButton();
            disableDone();

        },
        //validations result - callbacks
        validationResultProjectNo: function(response) {
            hideLoadingIndicator();
            var data = this.prDetails.detailsResponse;
            if (!_.isUndefined(data.ProjectsDetailsOutput) && data.ProjectsDetailsOutput.length == 1) {
                $(globalize.projectNoInputBox).removeClass('contain-error');
                var lineid = $(globalize.projectNoInputBox).data("lineno");
                $("#tasknumber-cart_" + lineid).prop("disabled", false);
                //$("#expenditure-type-cart_" + lineid).prop("disabled", false); //added to enable/disable exp type
                this.validProjectNo = true;
                sessionStorage.setItem('projectId', data.ProjectsDetailsOutput[0].ProjectId);
                sessionStorage.setItem('projectNumber', data.ProjectsDetailsOutput[0].ProjectNumber);
                /* update cart details json */
                var inpuval = data.ProjectsDetailsOutput[0].ProjectNumber;
                var lineid = $(globalize.projectNoInputBox).data("lineno");
                var keyparam = "PROJECT_NUMBER";
                saveCartDetails(keyparam, inpuval, lineid);
                /* update cart details json */
                /* update cart details json */
                var inpuval1 = data.ProjectsDetailsOutput[0].ProjectId;
                var lineid1 = $(globalize.projectNoInputBox).data("lineno");
                var keyparam1 = "PROJECT_ID";
                saveCartDetails(keyparam1, inpuval1, lineid1);
                /* update cart details json */
                if (this.updatecartFlow) {
                    $('#uc_taskno_container').removeClass('button-disable-opacity');
                    $($('.project-details-update-field-mobile')[1]).removeClass('button-disable-opacity');
                }
            } else {
                $(globalize.projectNoInputBox).addClass('contain-error');
                var lineid = $(globalize.projectNoInputBox).data("lineno");
                $("#tasknumber-cart_" + lineid).prop("disabled", true);
                // $("#expenditure-type-cart_" + lineid).prop("disabled", true); //added to enable/disable exp type
                this.validProjectNo = false;
                if (this.updatecartFlow) {
                    this.resetUpdateInputFields();
                    $($('.project-details-update-field-mobile')[1]).addClass('button-disable-opacity'); //mobile task no in updatecart
                    $('#sc_update_taskNo_mob').val('');
                    disableDone();
                }
                $('#update_submit').addClass('button-disable-opacity');
                /* update cart details json */
                var inpuval = "";
                var lineid = $(globalize.projectNoInputBox).data("lineno");
                var keyparam = "PROJECT_NUMBER";
                saveCartDetails(keyparam, inpuval, lineid);
                /* update cart details json */
                /* update cart details json */
                var inpuval1 = "";
                var lineid1 = $(globalize.projectNoInputBox).data("lineno");
                var keyparam1 = "PROJECT_ID";
                saveCartDetails(keyparam1, inpuval1, lineid1);
                /* update cart details json */

            }

        },
        validationResultSrc: function(response) {
            hideLoadingIndicator();
            var data = this.wareHouse.warehouseResponse;
            if (!_.isUndefined(data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput) && data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput.length == 1) {
                if ($(globalize.srcInputBox).hasClass('contain-error')) {
                    $(globalize.srcInputBox).removeClass('contain-error');
                }
                $('#update_submit').removeClass('button-disable-opacity');
                this.validSrc = true;
                enableDone();
                //this.validateSettingsBtn();
            } else {
                if (!$(globalize.srcInputBox).hasClass('contain-error')) {
                    $(globalize.srcInputBox).addClass('contain-error');
                }
                this.validSrc = false;
                disableDone();
                $('#update_submit').addClass('button-disable-opacity');
                //this.validateSettingsBtn();
            }

        },
        loadExpenditureTypeWindow: function(element) {

            globalize.expedituretypeInputBox = element.currentTarget.previousElementSibling;
            if ($(element.currentTarget).is('[data-mobile]')) {
                $('.mobile-update-cart-lines').hide();
                globalize.updateCartLine = true;
            } else {
                $('.shoppingcart-page').hide();
            }
            globalView = this;
            var expenditureView = new SelectExpenditureTypeView();
            breadCrumbs.push({ href: '#', name: 'Search And Select: Expenditure Type' });
            showHeaderButtons(false, true, "Reset", "Done");
            updateBreadCrumbs();
            showBackButton();
            disableDone();

        },
        deleteCartItem: function(element) {
            var selectId = $(element.currentTarget).prop('id');
            var lineId = $(element.currentTarget).data('lineid');
            sessionStorage.setItem("deletelineid", lineId);
            var current_lineNo = selectId.split("_")[1];

            var dataInput = {
                "USER_NAME": getUsername(),
                "LineDetails": [{
                    "LINE_NUMBER": current_lineNo
                }]
            };
            showLoadingIndicator();
            this.objForDelete.deleteCartItem(dataInput);
        },
        renderAfterDelete: function(response) {
            var self = this;
            hideLoadingIndicator();
            modalMsg(response.responseData.STATUS_MESSAGE, "success");
            if (response.responseData.STATUS == "SUCCESS") {
                /* update cart details json */
                var lineid = sessionStorage.getItem("deletelineid")
                saveCartDetails("", "", lineid, true);
                /* update cart details json */
            }
            self.model.getCartItems();
        },
        saveCartItems: function() {
            var savecart = new SaveCartModel();
            var cartitems = JSON.parse(sessionStorage.getItem('saveCartDetails'));

            if (this.needByDateCheck()) {
                if (this.ExpendItemDateCheck()) {
                    if (this.recordStatusCheck()) {
                        if (this.mandateFieldCheck()) {
                            if (this.onblurValidationCheck()) {
                                var dataInput = { "ShoppingCartUpsertData": cartitems }
                                //console.log("save in....")
                                showLoadingIndicator();
                                savecart.addToCartRequest(dataInput);
                            } else {
                                modalMsg("One or more items has error. Please correct the errors before saving or checking out.", "error");
                            }
                        } else {
                            modalMsg("One or more items has error. Please correct the errors before saving or checking out.", "error");
                        }

                    } else {
                        modalMsg("One or more items has error. Please correct the errors before saving or checking out.", "error");
                    }
                } else {
                    modalMsg("One or more items has error. Expenditure Item Date cannot be before current date.", "error");
                }
            } else {
                modalMsg("One or more items has error. Need By Date cannot be before current date.", "error");
            }

        },
        showUpdateCartLinesForMobile: function() {
            $('.shoppingcart-page').hide();
            $('.mobile-update-cart-lines').html(this.mobileUpdateCart());
            /*Initial setting for mobile view for update cart line */
            setTitle("Update", "mob-cart");
            showHeaderButtons(false, true, "Reset", "Done");
            disableDone();
            showBackButton();
            $('.project-details-update-field-mobile').hide();
            $('.project-other-details-update-field-mobile').hide();
            /*ends */
        },
        rightbuttonAction: function() {
            if ($('.mobile-update-cart-lines').children().length > 0) {
                var updatedList = [];
                var temp = this.model.toJSON().ShoppingCartDetails;
                if (this.updateProjectDetailsBtn) {
                    var projectInputVal = $('#sc_update_projectNo_mob').val();
                    var taskNoVal = $('#sc_update_taskNo_mob').val();
                    for (var i = 0; i < temp.length; i++) {
                        temp[i].PROJECT_NUMBER = projectInputVal;
                        temp[i].TASK_NUMBER = taskNoVal;
                    }
                    /* update cart details json */
                    saveCartDetails("PROJECT_NUMBER", projectInputVal);
                    saveCartDetails("TASK_NUMBER", taskNoVal);
                } else {
                    for (var i = 0; i < temp.length; i++) {
                        temp[i][globalize.changeProperty] = $(globalize.currOtherDetailsElement).val();
                    }
                    var keyparam = globalize.changeProperty; //property/key value
                    var updatevalue = $(globalize.currOtherDetailsElement).val();
                    saveCartDetails(keyparam, updatevalue);
                }
                $('.mobile-update-cart-lines').empty();
                setTitle("Cart", "mob-cart");
                removeBackButton();
                showHeaderButtons(false, true, "Reset", "Submit");
                /* update cart details json */
                this.renderUpdatedCart(temp);
            } else {
                this.submitCartItems();
            }

        },
        recordStatusCheck: function() {
            var self = this;
            var cartitems = JSON.parse(sessionStorage.getItem('saveCartDetails'));
            for (var key in cartitems) {
                if (cartitems[key].RECORD_STATUS == "ERROR") {
                    return false;
                }
            }
            return true;
        },
        needByDateCheck: function() {
            var self = this;
            var cartitems = JSON.parse(sessionStorage.getItem('saveCartDetails'));
            for (var key in cartitems) {
                if (self.validateDate(cartitems[key].NEED_BY_DATE)) {
                    return false;
                }
            }
            return true;
        },
        ExpendItemDateCheck: function() {
            var self = this;
            var cartitems = JSON.parse(sessionStorage.getItem('saveCartDetails'));
            for (var key in cartitems) {
                if (self.validateDate(cartitems[key].EXPENDITURE_ITEM_DATE)) {
                    return false;
                }
            }
            return true;

        },
        validateDate: function(date) {
            var today = new Date();
            var tempDate = new Date(date.replace(/-/g, '\/').replace(/T.+/, ''));
            var todayymd = new Date(today.getFullYear(), today.getMonth(), today.getDate());
            var tempymd = new Date(tempDate.getFullYear(), tempDate.getMonth(), tempDate.getDate());
            if (tempymd.getTime() < todayymd.getTime()) {
                return true;
            }
            return false;
        },
        mandateFieldCheck: function() {
            var self = this;
            var cartitems = JSON.parse(sessionStorage.getItem('saveCartDetails'));
            for (var key in cartitems) {
                if (!isValid(cartitems[key].PROJECT_NUMBER) || isObject(cartitems[key].PROJECT_NUMBER)) {
                    return false;
                }
                if (!isValid(cartitems[key].TASK_NUMBER) || isObject(cartitems[key].TASK_NUMBER)) {
                    return false;
                }
                if (!isValid(cartitems[key].EXPENDITURE_TYPE) || isObject(cartitems[key].EXPENDITURE_TYPE)) {
                    return false;
                }
                if (!isValid(cartitems[key].EXPENDITURE_ITEM_DATE) || isObject(cartitems[key].EXPENDITURE_ITEM_DATE)) {
                    return false;
                }
                /*if (!isValid(cartitems[key].EXPENDITURE_ORG) || isObject(cartitems[key].EXPENDITURE_ORG)) {
                    return false;
                }*/

            }
            return true;
        },
        onblurValidationCheck: function() {
            if ((this.validProjectNo == false) || (this.taskNoResult == false) || (this.validSrc == false) || (this.validDest == false)) {
                return false;
            }
            return true;
        },

        saveCartNoteToApprover: function(element) {
            /* update cart details json */
            var inpuval = $(element.currentTarget).val();
            var lineid = $(element.currentTarget).data("lineno");
            var keyparam = $(element.currentTarget).data("keyparam");
            saveCartDetails(keyparam, inpuval, lineid);
            /* update cart details json */
        },
        saveCartNeedByDate: function(element) {
            /* update cart details json */
            var inputval = $(element.currentTarget).val() + "T00:00:00";
            //var inputval = $(element.currentTarget).val();
            //inputval = inputval.split("/");
            //var tempinputval = inputval[2] + '-' + inputval[0] + '-' + inputval[1];
            var lineid = $(element.currentTarget).data("lineno");
            var keyparam = $(element.currentTarget).data("keyparam");
            //console.log("saveCartNeedByDate...", inputval);
            saveCartDetails(keyparam, inputval, lineid);
            /* update cart details json */
            /* if ($(element.currentTarget).data('lineno') === undefined) {
                 $('#update_submit').removeClass('button-disable-opacity');
                 enableDone();
             }*/

        },
        saveCartExpendItemDate: function(element) {
            /* update cart details json */
            var inputval = $(element.currentTarget).val() + "T00:00:00";
            //var inputval = $(element.currentTarget).val();
            //inputval = inputval.split("/");
            //var tempinputval = inputval[2] + '-' + inputval[0] + '-' + inputval[1];
            var lineid = $(element.currentTarget).data("lineno");
            var keyparam = $(element.currentTarget).data("keyparam");
            //console.log("saveCartExpendItemDate...", inputval);
            saveCartDetails(keyparam, inputval, lineid);
            /* update cart details json */
            /*  if ($(element.currentTarget).data('lineno') === undefined) {
                  $('#update_submit').removeClass('button-disable-opacity');
                  enableDone();
              }*/
        },
        saveCartQuantity: function(element) {
            /* update cart details json */
            var inpuval = $(element.currentTarget).val();
            var lineid = $(element.currentTarget).data("lineno");
            var keyparam = $(element.currentTarget).data("keyparam");
            saveCartDetails(keyparam, inpuval, lineid);
            /* update cart details json */
        },
        submitCartItems: function() {
            var cartitems = JSON.parse(sessionStorage.getItem('saveCartDetails'));
            if (this.needByDateCheck()) {
                if (this.ExpendItemDateCheck()) {
                    if (this.recordStatusCheck()) {
                        if (this.mandateFieldCheck()) {
                            if (this.onblurValidationCheck()) {
                                var dataInput = { "ShoppingCartUpsertData": cartitems }
                                showLoadingIndicator();
                                this.submitcart.submitCartRequest(dataInput);
                            } else {
                                modalMsg("One or more items has error. Please correct the errors before saving or checking out.", "error");
                            }
                        } else {
                            modalMsg("One or more items has error. Please correct the errors before saving or checking out.", "error");
                        }

                    } else {
                        modalMsg("One or more items has error. Please correct the errors before saving or checking out.", "error");
                    }
                } else {
                    modalMsg("One or more items has error. Expenditure Item Date cannot be before current date.", "error");
                }
            } else {
                modalMsg("One or more items has error. Need By Date cannot be before current date.", "error");
            }

        },

        AfterSubmit: function(data) {
            var response = data;
            hideLoadingIndicator();
            if (response.responseData.STATUS == "SUCCESS") {
                //modalMsg(response.responseData.STATUS_MESSAGE, "success");
                window.location.href = "#checkout";
            } else {
                modalMsg(response.responseData.STATUS_MESSAGE, "error");
            }
        },

        updateTaskNumber: function(element) {
            var currentvalue = element.currentTarget.value;
            globalize.taskInputBox = element.currentTarget;
            var projectid = $(globalize.taskInputBox).data('projectid');
            var projectno = $(globalize.taskInputBox).data('projectno');
            var tasktype = $(globalize.taskInputBox).data('tasktype');
            var exptype = $("#expenditure-type-cart").val();
            /* Busniess requirement from Sathya*/
            var currrId = $(element.currentTarget).prop('id').split('_')[1];
            globalize.expedituretypeInputBox = $('#expenditure-type-cart_' + currrId);
            /*ends */
            /* update cart details json */
            var keyparam = $(globalize.taskInputBox).data("keyparam");
            var lineno = $(globalize.taskInputBox).data("lineno");
            var updatevalue = currentvalue;
            saveCartDetails(keyparam, updatevalue, lineno);
            /* update cart details json */

            this.checkEmptyField(currentvalue, globalize.taskInputBox)
            if (currentvalue !== '') {
                var dataInput = {
                    "PROJECT_ID": projectid !== undefined ? projectid : sessionStorage.getItem("projectId"),
                    "TASK_NUMBER": currentvalue,
                    "PROJECT_NUMBER": projectno,
                    "TASK_TYPE": tasktype,
                    "EXPENDITURE_TYPE": exptype,
                    "REQUESTOR_NAME": getUsername()
                };
                showLoadingIndicator();
                this.tasknumber.fetchData(dataInput);
            }
        },
        validationResultTaskNo: function(response) {
            hideLoadingIndicator();
            var data = this.tasknumber.tasknumberResponse;
            if (!_.isUndefined(data.EXC_DB_FETCH_TASK_DETAILSOutput) && data.EXC_DB_FETCH_TASK_DETAILSOutput.length == 1) {
                if ($(globalize.taskInputBox).hasClass('contain-error')) {
                    $(globalize.taskInputBox).removeClass('contain-error');
                }
                $('#update_submit').removeClass('button-disable-opacity');
                /*Sathya requirements 16Jan*/
                var expType = data.EXC_DB_FETCH_TASK_DETAILSOutput[0].EXPENDITURE_TYPE;
                $(globalize.expedituretypeInputBox).val(data.EXC_DB_FETCH_TASK_DETAILSOutput[0].EXPENDITURE_TYPE);
                /* update cart details json */
                var keyparam = $(globalize.expedituretypeInputBox).data("keyparam");
                var lineno = $(globalize.expedituretypeInputBox).data("lineno");
                var updatevalue = expType;
                saveCartDetails(keyparam, updatevalue, lineno);
                /* update cart details json */
                /*ends - 16Jan */
                this.taskNoResult = true;
                enableDone();

            } else {
                if (!$(globalize.taskInputBox).hasClass('contain-error')) {
                    $(globalize.taskInputBox).addClass('contain-error');
                }
                this.taskNoResult = false;
                disableDone();
                $('#update_submit').addClass('button-disable-opacity');
            }

        },
        resetUpdateInputFields: function() {
            $('#uc_taskno_container').addClass('button-disable-opacity');
            $('#sc_update_taskNo').removeClass('contain-error');
            $('#sc_update_taskNo').val('');
            $('#update_submit').addClass('button-disable-opacity');
        },
        resetUdpateInputFieldsMobile: function() {
            $($('.project-details-update-field-mobile')[1]).addClass('button-disable-opacity'); //mobile task no in updatecart
            $('#sc_update_taskNo_mob').val('');
            $('#sc_update_projectNo_mob').val('');
            disableDone();
        },
        updateExpType: function(element) {
            var currentvalue = element.currentTarget.value;
            globalize.taskInputBox = element.currentTarget;
            // var projectid = $(globalize.taskInputBox).data('projectid');
            // /* update cart details json */
            // var keyparam = $(globalize.taskInputBox).data("keyparam");
            // var lineno = $(globalize.taskInputBox).data("lineno");
            // var updatevalue = currentvalue;
            // saveCartDetails(keyparam, updatevalue, lineno);
            // /* update cart details json */

            this.checkEmptyField(currentvalue, globalize.taskInputBox)
            if (currentvalue !== '') {
                var dataInput = {
                    "ExpenditureType": currentvalue
                }
                showLoadingIndicator();
                this.expenditureTypeResults.fetchData(dataInput);
            }
        },
        validationResultExpType: function(response) {
            hideLoadingIndicator();
            var data = this.expenditureTypeResults.expenditureTypeResponse;
            if (!_.isUndefined(data.ExpenditureTypeOutput) && data.ExpenditureTypeOutput.length == 1) {
                if ($(globalize.taskInputBox).hasClass('contain-error')) {
                    $(globalize.taskInputBox).removeClass('contain-error');
                }
                $('#update_submit').removeClass('button-disable-opacity');
                this.taskNoResult = true;
                enableDone();

            } else {
                if (!$(globalize.taskInputBox).hasClass('contain-error')) {
                    $(globalize.taskInputBox).addClass('contain-error');
                }
                this.taskNoResult = false;
                disableDone();
                $('#update_submit').addClass('button-disable-opacity');
            }

        },
        backButtonAction: function() {
            $('.shoppingcart-page').show();
            $('.mobile-update-cart-lines').empty();
            /*Initial setting for mobile view for update cart line */
            setTitle("Cart", "mob-cart");
            removeBackButton();
            showHeaderButtons(false, true, "Reset", "Submit");
        },
        clearCart: function() {
            if (!isOnline) {
                var user = getUsername();
                if (offlineDB) {
                    offlineDB.clearData("CARTLOGS", user);
                    offlineDB.addData("CARTLOGS", user, "clear cart");
                    $("#shoppingcart_list").empty();
                }
                return;
            }
            var personid = localStorage.getItem("personID");
            var dataInput = {
                "REQUESTOR_ID": personid
            }
            showLoadingIndicator();
            this.clearcart.clearCartRequest(dataInput);
        },
        AfterClearCart: function(data) {
            var response = data;
            if (response.responseData.STATUS == "SUCCESS") {

                if (isOnline) {
                    this.model.getCartItems();
                } else {
                    this.model.fetchOfflineData();
                }
            } else {
                modalMsg(response.responseData.STATUS_MESSAGE, "error");
            }

        },
        goToItemDetails: function(element) {
            var lineno = $(element.currentTarget).data("lineno");
            var cifaitemnumber = $(element.currentTarget).data("cifaitemnumber");

            var itemquantity = $("#numspinner_" + lineno).val();
            var itemneedByDate = $("#date-needby_" + lineno).val();
            sessionStorage.setItem("currentitemquantity", itemquantity);
            sessionStorage.setItem("currentitemneedByDate", itemneedByDate);
            window.location.href = "#item_details?=" + cifaitemnumber;
        },

        clearOfflineItems: function() {
            // if ($('#offline_container').children().length == 0) {
            //     modalMsg("No items are availble in offline cart", "warning", "");
            //     $('#offline_container').append(this.noRecords());
            //     return;
            // }
            var user = getUsername();
            offlineDB.clearData("CARTOFFLINE", user);
            modalMsg("All offline items are deleted from your cart", "warning", "");
            $('#offline_container').empty();
            $('#offline_container').append(this.noRecords());
            //this.render();
            return;
        }
    });

    return ShoppingCartView;
});