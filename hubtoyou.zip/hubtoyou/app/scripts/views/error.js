/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates'
], function($, _, Backbone, JST) {
    'use strict';

    var FooterView = Backbone.View.extend({
        template: JST['app/scripts/templates/errorpage.ejs'],
        viewName: 'errorView',
        tagName: 'div',
        id: '',
        className: '',
        el: '#container',
        events: {

        },

        initialize: function() {
            //this.listenTo(this.model, 'change', this.render);
        },
        render: function() {
            this.$el.html(this.template());
            return this;
        }
    });

    return FooterView;
});