/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/helplink'
], function($, _, Backbone, JST, HelpLinkModel) {
    'use strict';

    var FooterView = Backbone.View.extend({
        template: JST['app/scripts/templates/footer.ejs'],

        viewName: 'footerView',

        tagName: 'div',

        id: '',

        className: '',

        events: {
            'click .btn-group > .btn': function(source) {
                $(source.target).addClass('active').siblings().removeClass('active');
            },
            'click #termsCond': 'showTermsConditions',
            'click #helpLink': 'fetchHelpLink'
        },

        initialize: function() {
            this.helpLinkModel = new HelpLinkModel();
            this.listenTo(this.helpLinkModel, 'sync', this.helpLinkCallback);
        },
        render: function() {
            var currentDate = new Date();
            var currentYear = currentDate.getFullYear();
            this.$el.html(this.template(currentYear));
            globalize.FooterViewObject = this;
            return this;
        },
        showTermsConditions: function() {
            //modalMsg(globalize.termsAndConditions, "info", "", "", "false");
            popupModalMsg(globalize.termsAndConditions);
        },
        fetchHelpLink: function() {
            var data = {
                "SourceSystem": "HUB2U"
            };
            showLoadingIndicator();
            this.helpLinkModel.getHelpLink(data);
        },
        helpLinkCallback: function(data) {
            hideLoadingIndicator();
            globalize.helpLinkUrl = data.toJSON().Output[0].link;
            if(isPhoneGap()){
                var win = window.open(globalize.helpLinkUrl, '_system');
            } else {
                var win = window.open(globalize.helpLinkUrl, '_blank');
            }            
            if (isValid(win)) {
                win.focus();
            } else {
                modalMsg("Please allow popups for this website", "error");
            }

        }
    });

    return FooterView;
});