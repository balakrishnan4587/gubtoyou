/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/userpreferences',
    'views/selectprojectnumber',
    'models/searchprojectdetails',
    'models/searchwarehouse',
    'models/searchinventory'
], function($, _, Backbone, JST, model1, SelectProjectNumberView, SearchProjectDetailsModel, SearchWarehouseModel, SearchInventoryModel) {
    'use strict';

    var UserPreferencesView = Backbone.View.extend({
        template: JST['app/scripts/templates/userpreferences.ejs'],
        model: new model1(),
        viewName: 'userPreferencesView',
        el: '.load-pereferences-fields',
        tagName: 'div',
        id: '',

        className: '',

        events: {
            'focus .drop-down': 'showDropDown',
            'blur .drop-down': 'hideDropDown',
            'click .drop-down-picker li': 'setSelectedValue',
            'click #selectProjectNo': 'loadProjectSelectionWindow',
            'click #selectSourceWarehouse': 'loadSourceLocationWindow',
            'click #selectDeliveryLocation': 'loadDeliveryToLocationWindow',
            'click #selectSubInventory': 'loadSubInventoryWindow',
            //'blur #projectNo':'validateProjectNumber',
            'change #projectNo': 'updateProjectNumber',
            'change #srcLocation': 'updateSrc',
            'change #destLocation': 'updateDest',
            'change #subInventory': 'updateSubInventory',
            'change #offsetDate': 'updateOffsetCount',
            'change #yesNoBU': 'updateBU',
            'click #save': 'saveSettings'
        },

        initialize: function(options) {
            AppView.currentView = this;
            this.fetchUserModel = new model1();
            this.saveSettingsModel = new model1();
            this.prDetails = new SearchProjectDetailsModel();
            this.wareHouse = new SearchWarehouseModel();
            this.wareHouseDest = new SearchWarehouseModel();
            this.inventoryDetails = new SearchInventoryModel();
            this.listenTo(this.model, 'sync', this.render);
            this.listenTo(this.fetchUserModel, 'change', this.renderAfterFetchUsr);
            this.listenTo(this.prDetails, 'sync', this.validationResultProjectNo);
            this.listenTo(this.wareHouse, 'sync', this.validationResultSrc);
            this.listenTo(this.wareHouseDest, 'sync', this.validationResultDest);
            this.listenTo(this.inventoryDetails, 'sync', this.validationResultSubInventory);
            this.listenTo(this.saveSettingsModel, 'sync', this.showSaveSettingsResult);
            this.destinationChanged = false;
            this.validSrc = true;
            this.validProjectNo = true;
            this.model.fetchData(options.userName);
            // this.fetchUserModel.fetchUserName(options.userName);
        },
        renderAfterFetchUsr: function(data) {
            if (data.toJSON().EXC_DB_FETCH_USER_NAMEOutput != undefined && data.toJSON().EXC_DB_FETCH_USER_NAMEOutput.length > 0) {
                var userName = data.toJSON().EXC_DB_FETCH_USER_NAMEOutput[0].user_name;
                this.userValid = true;

            }
        },
        render: function(model) {
            if (typeof model.userPrefResponse.PreferencesSelectOutput == "undefined") {
                $("#err-msg-div").html("Enter Valid NT User Name");
                $(".load-pereferences-fields").empty();
                hideLoadingIndicator();
                disableDone();
                return;
            }
            this.model = model.toJSON().PreferencesSelectOutput[0];
            var user = getUsername();
            if (isOnline) {
                offlineDB.clearData("settings", user);
            }
            if (isOnline && offlineDB) {
                var settingsData = model.toJSON();
                settingsData.username = user;
                offlineDB.addData("settings", user, settingsData);
            }
            // showHeaderButtons(false, true, "Reset", "Save");
            // enableDone();
            $("#err-msg-div").html("");
            this.$el.html(this.template(this.model));
            hideLoadingIndicator();
            enableDone();
            // $('#mb_title').html("Settings");
            globalize.projectNoInputBox = this.$el.find('#projectNo');
            globalize.srcInputBox = this.$el.find('#srcLocation');
            globalize.deliveryLocInputBox = this.$el.find('#destLocation');
            globalize.subInventoryInputBox = this.$el.find('#subInventory');

            if (this.model.ATTRIBUTE6 == null || this.model.ATTRIBUTE6 == "N") {
                this.$el.find('#yesNoBU').val("No");
            } else {
                this.$el.find('#yesNoBU').val("Yes");
            }
            this.delegateEvents(this.events);
            return this;
        },
        checkEmptyField: function(value, txtElement) {
            if (value == "" && $(txtElement).hasClass('contain-error')) {
                $(txtElement).removeClass('contain-error');
            }
        },
        updateProjectNumber: function(element, data) {
            if (_.isUndefined(data)) {
                this.model.PROJECT_NUMBER = element.currentTarget.value;
                this.checkEmptyField(this.model.PROJECT_NUMBER, globalize.projectNoInputBox)
                if (this.model.PROJECT_NUMBER !== '') {
                    this.validateProjectNumber();
                }
            } else {
                this.model.PROJECT_NUMBER = data.data.ProjectNumber;
                this.model.PROJECT_ID = data.data.ProjectId;
            }
        },
        updateSrc: function(element, data) {
            if (_.isUndefined(data)) {
                this.model.SOURCE_LOCATION = element.currentTarget.value;
                this.checkEmptyField(this.model.SOURCE_LOCATION, globalize.srcInputBox)
                if (this.model.SOURCE_LOCATION !== '') {
                    this.validateSrc();
                }

            } else {
                this.model.SOURCE_LOCATION = data.data.ORGANIZATION_CODE;
            }

        },
        updateDest: function(element, data) {
            if (_.isUndefined(data)) {
                this.model.DELIVERY_TO_LOCATION = element.currentTarget.value;
                this.checkEmptyField(this.model.DELIVERY_TO_LOCATION, globalize.deliveryLocInputBox)
                if (this.model.DELIVERY_TO_LOCATION !== '') {
                    this.validateDest();
                }
            } else {
                this.destinationChanged = true;
                this.model.DELIVERY_TO_LOCATION = data.data.LOCATION_CODE;
                this.model.EXPENDITURE_ORG = data.data.ORGANIZATION_CODE;
                this.model.EXPENDITURE_ORG_ID = data.data.DELIVER_TO_ORG_ID;
            }

        },
        updateSubInventory: function(element, data) {
            if (_.isUndefined(data)) {
                this.model.SUBINVENTORY = element.currentTarget.value;
                this.checkEmptyField(this.model.SUBINVENTORY, globalize.subInventoryInputBox)
                if (this.model.SUBINVENTORY !== '') {
                    this.validateSubInventory();
                }
            } else {
                this.model.SUBINVENTORY = data.data.SUBINVENTORY_NAME;
            }
        },
        updateOffsetCount: function(element) {
            this.model.NEED_BY_DATE_TIME = element.currentTarget.value;
        },
        updateBU: function(element) {
            var value = element.currentTarget.value;
            (value.toLowerCase() == "yes") ? this.model.ATTRIBUTE6 = "Y": this.model.ATTRIBUTE6 = 'N';
        },
        showDropDown: function(source) {
            $(source.target).next().slideDown(200);
        },
        hideDropDown: function(source) {
            $(source.target).next().slideUp(200);
        },
        setSelectedValue: function(source) {
            $(source.target).closest('div').prev().val(source.target.innerHTML)
        },

        // goToProjectSelection: function(element) {
        //   globalize.modalTitle = globalize.selectProjectNo;
        //   globalize.selectedWIndow = $(element.currentTarget).prop('id');
        //   location.href = "#settings?view=project-selection"
        // },

        loadProjectSelectionWindow: function(element) {
            globalize.modalTitle = globalize.selectProjectNo;
            globalize.selectedWIndow = $(element.currentTarget).prop('id');
            $('#bu_page').hide();
            var projectDetailsView = new SelectProjectNumberView();
            if (!_.findWhere(breadCrumbs, { name: 'Search And Select: Project Number' })) {
                breadCrumbs.push({
                    "name": "Search And Select: Project Number",
                    "href": "#"
                });
            }

            showHeaderButtons(false, true, "Reset", "Done");
            updateBreadCrumbs();
            showBackButton();
            globalView = this;

        },

        loadSourceLocationWindow: function(element) {
            globalize.modalTitle = globalize.selectSrc;
            globalize.selectedWIndow = $(element.currentTarget).prop('id');
            $('#bu_page').hide();
            var projectDetailsView = new SelectProjectNumberView();
            if (!_.findWhere(breadCrumbs, { name: 'Search And Select: Source Warehouse' })) {
                breadCrumbs.push({
                    "name": "Search And Select: Source Warehouse",
                    "href": "#"
                });
            }

            showHeaderButtons(false, true, "Reset", "Done");
            updateBreadCrumbs();
            showBackButton();
            globalView = this;

        },
        loadDeliveryToLocationWindow: function(element) {
            globalize.modalTitle = globalize.selectToLocation;
            globalize.selectedWIndow = $(element.currentTarget).prop('id');
            $('#bu_page').hide();
            var projectDetailsView = new SelectProjectNumberView();
            if (!_.findWhere(breadCrumbs, { name: 'Search And Select: Delivery To Location' })) {
                breadCrumbs.push({
                    "name": "Search And Select: Delivery To Location",
                    "href": "#"
                });
            }

            showHeaderButtons(false, true, "Reset", "Done");
            updateBreadCrumbs();
            showBackButton();
            globalView = this;

        },
        loadSubInventoryWindow: function(element) {
            globalize.modalTitle = globalize.selectSubInventory;
            globalize.selectedWIndow = $(element.currentTarget).prop('id');
            $('#bu_page').hide();
            var projectDetailsView = new SelectProjectNumberView();
            if (!_.findWhere(breadCrumbs, { name: 'Search And Select: Sub Inventory' })) {
                breadCrumbs.push({
                    "name": "Search And Select: Sub Inventory",
                    "href": "#"
                });
            }

            showHeaderButtons(false, true, "Reset", "Done");
            updateBreadCrumbs();
            showBackButton();
            globalView = this;

        },
        //Validation logics for the Input fields with service
        validateProjectNumber: function(event) {
            var dataInput = {
                "ProjectNumber": this.model.PROJECT_NUMBER
            };
            this.prDetails.fetchData(dataInput);
        },
        validationResultProjectNo: function(response) {
            var data = this.prDetails.detailsResponse;
            if (!_.isUndefined(data.ProjectsDetailsOutput) && data.ProjectsDetailsOutput.length == 1) {
                $(globalize.projectNoInputBox).removeClass('contain-error');
                this.validProjectNo = true;
                this.validateSettingsBtn();
            } else {
                $(globalize.projectNoInputBox).addClass('contain-error');
                this.validProjectNo = false;
                this.validateSettingsBtn();
            }

        },
        validateSrc: function() {
            var dataInput = {
                "ORGANIZATION_CODE": this.model.SOURCE_LOCATION
            };
            this.wareHouse.fetchData(dataInput);
        },
        validationResultSrc: function(response) {
            var data = this.wareHouse.warehouseResponse;
            if (!_.isUndefined(data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput) && data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput.length == 1) {
                if ($(globalize.srcInputBox).hasClass('contain-error')) {
                    $(globalize.srcInputBox).removeClass('contain-error');
                }
                this.validSrc = true;
                this.validateSettingsBtn();
            } else {
                if (!$(globalize.srcInputBox).hasClass('contain-error')) {
                    $(globalize.srcInputBox).addClass('contain-error');
                }
                this.validSrc = false;
                this.validateSettingsBtn();
            }

        },
        validateDest: function() {
            var dataInput = {
                "LOCATION_CODE": this.model.DELIVERY_TO_LOCATION
            };
            this.wareHouseDest.fetchData(dataInput);
        },
        validationResultDest: function(response) {
            var data = this.wareHouseDest.warehouseResponse;
            if (!_.isUndefined(data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput) && data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput.length == 1) {
                if ($(globalize.deliveryLocInputBox).hasClass('contain-error')) {
                    $(globalize.deliveryLocInputBox).removeClass('contain-error');
                }
                this.model.EXPENDITURE_ORG = data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput.ORGANIZATION_CODE;
                this.model.EXPENDITURE_ORG_ID = data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput.DELIVER_TO_ORG_ID;
                this.validSrc = true;
                this.validateSettingsBtn();
            } else {
                if (!$(globalize.deliveryLocInputBox).hasClass('contain-error')) {
                    $(globalize.deliveryLocInputBox).addClass('contain-error');
                }
                this.validDest = false;
                this.validateSettingsBtn();
            }

        },
        //Sub inventory
        validateSubInventory: function() {
            var dataInput = {
                "SUBINVENTORY_NAME": this.model.SUBINVENTORY
            }
            this.inventoryDetails.fetchData(dataInput);
        },
        validationResultSubInventory: function(response) {
            var data = this.inventoryDetails.inventoryResponse;
            if (!_.isUndefined(data.EXC_DB_SELECT_SUBINVENTORYOutput) && data.EXC_DB_SELECT_SUBINVENTORYOutput.length == 1) {
                if ($(globalize.subInventoryInputBox).hasClass('contain-error')) {
                    $(globalize.subInventoryInputBox).removeClass('contain-error');
                }
                this.validSInventory = true;
                this.validateSettingsBtn();
            } else {
                if (!$(globalize.subInventoryInputBox).hasClass('contain-error')) {
                    $(globalize.subInventoryInputBox).addClass('contain-error');
                }
                this.validSrc = false;
                this.validateSettingsBtn();
            }

        },
        validateSettingsBtn: function() {
            if (this.validSrc && this.validProjectNo) {
                this.$el.find('.settings-page').find('button').prop('disabled', '');
                this.$el.find('.settings-page').find('button').removeClass('button-gray')
                enableDone();
            } else {
                this.$el.find('.settings-page').find('button').prop('disabled', 'disabled');
                this.$el.find('.settings-page').find('button').addClass('button-gray')
                disableDone();
            }
        },
        formRequestData: function() {
            var dataInput = {
                "TechMobilePref": {
                    "personId": this.model.PERSON_ID,
                    "username": this.model.USER_NAME,
                    "requestor": this.model.REQUESTOR,
                    "projectNumber": this.model.PROJECT_NUMBER,
                    "projectId": this.model.PROJECT_ID,
                    "subinventory": this.model.SUBINVENTORY,
                    "needByDateTime": this.model.NEED_BY_DATE_TIME,
                    "attribute6": this.model.ATTRIBUTE6,
                    "sourceLocation": this.model.SOURCE_LOCATION
                }
            };
            if (this.destinationChanged) {
                dataInput.TechMobilePref.deliveryToLocation = this.model.DELIVERY_TO_LOCATION;
                dataInput.TechMobilePref.expenditureOrgId = this.model.EXPENDITURE_ORG_ID;
                dataInput.TechMobilePref.expenditureOrg = this.model.EXPENDITURE_ORG;
            }
            return dataInput;
        },
        rightbuttonAction: function() {
            this.saveSettings();
        },
        saveSettings: function() {
            var inputForSaveSettings = this.formRequestData();
            showLoadingIndicator();
            this.saveSettingsModel.saveData(inputForSaveSettings);
        },
        showSaveSettingsResult: function(data) {
            hideLoadingIndicator();
            if (data.toJSON().STATUS == "Success") {
                modalMsg("Your changes have been applied.", "success");
                ///globalView.loadUserPreferences();
            } else {
                modalMsg("Your changes not been applied.", "error");
            }

        }

    });

    return UserPreferencesView;
});