/*globalize*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/announcement',
    'models/adminavailableregions',
    'models/insertannouncement',
    'views/viewannouncement',
    'views/manageannouncement'
], function($, _, Backbone, JST, AnnouncementModel, RegionList, CreateAlertModel, ViewAnnouncementView,
    ManageAnnouncementView) {
    'use strict';

    var AnnouncementView = Backbone.View.extend({
        template: JST['app/scripts/templates/announcement.ejs'],
        newAlertTemplate: JST['app/scripts/templates/announcementCreate.ejs'],
        editAlertTemplate: JST['app/scripts/templates/announcementedit.ejs'],
        el: '#container',
        id: '',
        childView: null,
        className: '',

        events: {
            'click #viewNotif': function() {
                window.location.href = "#announcement?home";
            },
            'click #manageNotif': function() {
                window.location.href = "#announcement?manage";
            }
        },

        initialize: function(options) {
            this.render(options.view);
        },
        render: function(view) {
            this.$el.html(this.template());
            if (view === "" || view.toLowerCase() === "home") {
                this.renderViewNotifications();
            } else if (view.toLowerCase() === "manage") {
                this.renderManageNotifications();
            } else {
                this.renderViewNotifications();
            }
        },

        renderViewNotifications: function(event) {
            if (this.childView) {
                this.childView.remove();
                this.childView.unbind();
            }
            this.viewAnnoucement = true;
            $('#manageNotif').removeClass('btn-selected');
            $('#viewNotif').addClass('btn-selected');
            this.childView = new ViewAnnouncementView();
        },

        renderManageNotifications: function(event) {
            if (this.childView) {
                this.childView.remove();
                this.childView.unbind();
            }
            this.viewAnnoucement = true;
            $('#viewNotif').removeClass('btn-selected');
            $('#manageNotif').addClass('btn-selected');
            this.childView = new ManageAnnouncementView();
        }

    });

    return AnnouncementView;
});