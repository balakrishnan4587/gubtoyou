/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/searchntusername',
], function($, _, Backbone, JST, SearchNTUsernameModel) {
    'use strict';

    var SearchNTUserPopupView = Backbone.View.extend({
        template: JST['app/scripts/templates/searchntusernamepopup.ejs'],
        resultsntusertemplate: JST['app/scripts/templates/searchntusernameresult.ejs'],
        viewName: 'viewSearchNTUserName',
        el: '#searchntuserpopup',
        tagName: 'div',
        id: '',
        className: '',
        inputData: {},
        events: {
            'click #ntusersearchbtn': 'searchNTUserName',
            'change #ntusernameinput': 'updateNTUserNameINput',
            'click .selectRecordRow': 'selectRecord',
            'click #NTUserDoneBtn': 'populateNTUserName',
            'click .gotoback': 'backToAdmin'
        },
        initialize: function() {
            if (AppView.currentView !== undefined) {
                globalPreviousView = AppView.currentView;
            }
            AppView.currentView = this;
            this.searchntusermodel = new SearchNTUsernameModel();
            this.listenTo(this.searchntusermodel, 'sync', this.renderSearchNTUserResult);
            this.render();
        },
        render: function() {
            this.$el.html(this.template());
            this.delegateEvents(this.events);
            return this;
        },
        updateNTUserNameINput: function(event) {
            this.inputData.NTUsernameValue = event.currentTarget.value;
            this.validateSearchButton(this.inputData);
        },
        validateSearchButton: function(value) {
            if (isValid(value.NTUsernameValue)) {
                this.$el.find('#ntusersearchbtn').removeClass('button-disable-opacity');
                return;
            } else {
                this.$el.find('#ntusersearchbtn').addClass('button-disable-opacity');
            }
        },
        searchNTUserName: function() {
            var dataInput = {
                "USER_NAME": this.inputData.NTUsernameValue
            }
            showLoadingIndicator();
            this.searchntusermodel.fetchNTUserName(dataInput);
        },
        renderSearchNTUserResult: function(data) {
            var searchdata = data.responseNTUserData;
            this.$el.find("#loadNTUsernameData").html(this.resultsntusertemplate(searchdata));
            hideLoadingIndicator();
        },
        /* Record selection from table */
        selectRecord: function(element) {

            var selectId = $(element.currentTarget).prop('id');
            var cur_row = selectId.split("_");
            $("#radioBtn_" + cur_row[1]).prop("checked", true);
            $(".mobile-select-btn").addClass("hidden");
            $("#mob-row_" + cur_row[1]).removeClass("hidden");
            enableDone();
            var NTuserid = cur_row[1];
            var NTusername = $("#ntusername_" + cur_row[1]).text();

            this.NTuserid = NTuserid;
            this.NTusername = NTusername;

        },
        populateNTUserName: function() {
            $(globalize.NTUsernameInputBox).val(this.NTusername);
            this.$el.empty();
            this.close(); //to kill the current view           
            hideHeaderButtons();
            if (globalView.viewName == "buAdminView") {
                $(globalize.NTUsernameInputBox).trigger('change', [{ data: this.NTusername }]);
                $('#bu_page').show();
            } else {
                $('.adminstration-page').show();
            }

            $(globalize.NTUsernameInputBox).removeClass('contain-error');
            $('#NTUserDoneBtn').removeClass('button-disable-opacity');
            var len = breadCrumbs.length;
            breadCrumbs.splice(len - 1, 1);
            updateBreadCrumbs();
            removeBackButton();
            showHeaderButtons(false, true, "Reset", "Save");
            disableDone();
            AppView.currentView = globalView;
        },

        backToAdmin: function() {
            if (globalView.viewName == "buAdminView") {
                $('#bu_page').show();
            } else {
                $('.adminstration-page').show();
            }
            this.$el.empty();
            this.close(); //to kill the current view
            var len = breadCrumbs.length;
            breadCrumbs.splice(len - 1, 1);
            updateBreadCrumbs();
            removeBackButton();
            disableDone();

        },
        backButtonAction: function() {
            if (globalView.viewName == "buAdminView") {
                $('#bu_page').show();
            } else {
                $('.adminstration-page').show();
            }
            this.$el.empty();
            this.close(); //to kill the current view
            var len = breadCrumbs.length;
            breadCrumbs.splice(len - 1, 1);
            updateBreadCrumbs();
            removeBackButton();
            showHeaderButtons(false, true, "Reset", "Save");
        },
        rightbuttonAction: function() {
            this.populateNTUserName();
        }

    });

    return SearchNTUserPopupView;
});