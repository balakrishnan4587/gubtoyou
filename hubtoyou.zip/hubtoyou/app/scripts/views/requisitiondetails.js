/*globalize*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/requisitiondetails',
    'models/acknowledementdetails',
    'models/requisitionaddtocart',
    'models/feedback',
    'models/acknowledementinsert',
    'views/acknowledgement',
    'models/shippingcartitemdetails',
    'models/admingrantedresponsibility',
    'models/adminselectedregions'
], function($, _, Backbone, JST, RequisitionDetailsModel, AckDetails, RequisitionAddToCartModel,
    FeedbackModel, AckInsertModel, AcknowledgementView, CartItemModel, GrantedResponsibilityModel,
    AdminSelectedRegionsModel) {
    'use strict';

    var RequisitionDetailsView = Backbone.View.extend({
        template: JST['app/scripts/templates/requisitiondetails.ejs'],
        //reportRequisitionDetailsTemplate: JST['app/scripts/templates/reportrequisitiondetails.ejs'],
        receivingDetailsTemplate: JST['app/scripts/templates/receivingdetails.ejs'],
        receivingDetailsMobileTemplate: JST['app/scripts/templates/receivingdetailsmob.ejs'],
        cifaItemDetailMobileTemplate: JST['app/scripts/templates/requisitionitemdetails.ejs'],
        feedbackMobileTemplate: JST['app/scripts/templates/feedbackmobile.ejs'],
        feedbackDesktopTemplate: JST['app/scripts/templates/feedbackdesktop.ejs'],
        emptyTemplate: JST['app/scripts/templates/norecords.ejs'],
        el: '#container',
        isMobile: false,
        model: new RequisitionDetailsModel(),
        events: {
            'click .hdr-item-list': 'loadItemDetails',
            'click #requisition_details_back': 'goToHome',
            'click #requisition_details_back_Mobile': 'goToHome',
            'click .launch-feedback': 'showFeedbackArea',
            'click .feedback-mobile': 'loadMobileFeedbackPage',
            'click #submit_feedback': 'submitFeedback',
            'change .feedback-txtarea': 'updateFeedbackComments',
            'change .desktop-star': 'updateRating',
            'change .feedback-mobile-comments': 'updateMobileFeedbackComments',
            'change .mobile-star': 'updateMobileRating',
            'click .accordion-ack-details': 'toggleAccordian',
            'click .cart-bg': 'requisitionAdd2Cart',
            'click #acknowledgement_Btn': 'goToAcknowledgement',
            'click #btn_mob_acknowldegement': 'goToAcknowledgement',
            'click #submit_Receiving': 'submitReceivingDetails'
        },

        initialize: function() {
            this.childView = null;
            //console.log('init requisition details');
            //AppView.currentView = this;
            this.ackInsertModel = new AckInsertModel();
            this.ackDetails = new AckDetails();
            this.requisitonAddToCartModel = new RequisitionAddToCartModel();
            this.feedBackModel = new FeedbackModel();
            this.getfeedBackModel = new FeedbackModel();
            this.itemcountModel = new CartItemModel();
            //this.grantedResponsibilityModel = new GrantedResponsibilityModel();
            this.selectedregions = new AdminSelectedRegionsModel();
            this.selectedregionsForFeedback = new AdminSelectedRegionsModel();
            this.listenTo(this.model, 'sync', this.render);
            this.listenTo(this.feedBackModel, 'sync', this.resultAfterSubmit);
            this.listenTo(this.ackDetails, 'sync', this.resultForAck);
            this.listenTo(this.getfeedBackModel, 'sync', this.resultAfterLoadFeedback);
            this.listenTo(this.itemcountModel, 'sync', this.resultAfterItemCountFetch);
            this.listenTo(this.requisitonAddToCartModel, 'sync', this.resultAfterAdd2Cart);
            this.listenTo(this.ackInsertModel, 'sync', this.resultAfterSubmitReceivingDetails);
            //this.listenTo(this.grantedResponsibilityModel, 'sync', this.renderAfterGrantedResponsibilities);
            this.listenTo(this.selectedregions, 'sync', this.renderAfterSelectedRegions);
            this.listenTo(this.selectedregionsForFeedback, 'sync', this.renderAfterFeedbackValidation);
            globalize.regionalAcknowledge = false; //default set to flase for acknowledge button
            globalize.regionalFeedback = false; //default set to flase for feedback button
            //$('.feedback-panel').hide(); //hide feedbacl content initialy
            //this.listenTo(this.reqAddToCart,'change',this.resultForAddToCart);
        },
        subView: false,
        feedbackInput: { rating: '', comments: '' },
        render: function(data) {
            if (data !== undefined && data.toJSON() !== undefined && data.toJSON().RequisitionLineOutput !== undefined) {
                this.renderData = data.toJSON();
                this.validateUserForAcknowledgement();
            } else {
                this.$el.html(this.emptyTemplate());
                hideLoadingIndicator();
            }

        },
        validateUserForAcknowledgement: function() {
            var dataInput = { "BIND_APPLICATIONID": 1, "FUNCTIONID": 7 };
            this.selectedregions.fetchSelectedRegions(dataInput); //service call
        },

        renderAfterSelectedRegions: function(data) {
            var regions = data.toJSON();

            //var t = _.findWhere(regions.EXC_DB_REGION_RESP_USAGEOutput, { REGION_NAME: localStorage.getItem('region_user') });
            var region = localStorage.getItem('region_user');
            var t = false;
            if (region !== null && isValid(regions.EXC_DB_REGION_RESP_USAGEOutput)) {
                regions.EXC_DB_REGION_RESP_USAGEOutput.forEach(function(item) {
                    if (region.indexOf(item.REGION_NAME) > -1) {
                        t = true;
                    }
                });
            }
            if (regions != undefined && regions.EXC_DB_REGION_RESP_USAGEOutput != undefined && t) {
                globalize.regionalAcknowledge = true;
            } else {
                globalize.regionalAcknowledge = false;
            }
            this.validateUserForFeedback();
            // this.$el.html(this.template(this.renderData));
            // $('.feedback-panel').hide();
            // this.delegateEvents(this.events);
            // hideLoadingIndicator();

        },
        validateUserForFeedback: function() {
            var dataInput = { "BIND_APPLICATIONID": 1, "FUNCTIONID": 8 };
            this.selectedregionsForFeedback.fetchSelectedRegions(dataInput); //service call
        },
        renderAfterFeedbackValidation: function(data) {
            var regions = data.toJSON();

            var region = localStorage.getItem('region_user');
            var t = false;
            if (region !== null && isValid(regions.EXC_DB_REGION_RESP_USAGEOutput)) {
                regions.EXC_DB_REGION_RESP_USAGEOutput.forEach(function(item) {
                    if (region.indexOf(item.REGION_NAME) > -1) {
                        t = true;
                    }
                });
            }

            if (regions != undefined && regions.EXC_DB_REGION_RESP_USAGEOutput != undefined && t) {
                globalize.regionalFeedback = true;
            } else {
                globalize.regionalFeedback = false;
            }
            this.$el.html(this.template(this.renderData));
            $('.feedback-panel').hide();
            this.delegateEvents(this.events);
            hideLoadingIndicator();
        },
        /*Loads desktop feedback accordian*/
        showFeedbackArea: function(element) {
            this.currEle = element.currentTarget;
            if (($($(this.currEle).next()).is(':visible'))) {
                $(this.currEle).next().hide();
                return;
            }
            var input = {
                "RequisitionHeaderId": this.model.toJSON().RequisitionLineOutput[0].REQUISITION_HEADER_ID,
                "RequisitionNumber": this.model.toJSON().RequisitionLineOutput[0].REQUISITION_NUMBER
            };
            showLoadingIndicator();
            this.getfeedBackModel.getFeedback(input);
        },
        resultAfterLoadFeedback: function(data) {
            hideLoadingIndicator();
            if ($(window).width() > 991) {
                $(this.currEle).next().show();
                $(this.currEle).next().html(this.feedbackDesktopTemplate(data.toJSON()));
                if (data.responseData.Rating != undefined && data.responseData.Rating != null) {
                    this.feedbackExist = true;
                    $('#star' + data.responseData.Rating).prop('checked', true);
                    $('#submit_feedback').hide();
                    $('.feedback-txtarea').prop('readonly', true);
                    $('.desktop-star').prop('disabled', 'disabled');
                }
                return;
            }

            $('.load-feedback').html(this.feedbackMobileTemplate(data.toJSON()));
            showBackButton();
            this.subView = true;
            showHeaderButtons(false, true, "Reset", "Save");
            setTitle("Feedback", "");
            if (data.responseData.Rating != undefined && data.responseData.Rating != null) {
                disableDone();
                this.feedbackExist = true;
                $('#mob_star' + data.responseData.Rating).prop('checked', true);
                $('.feedback-mobile-comments').prop('readonly', true);
                $('.mobile-star').prop('disabled', 'disabled');
            }

        },
        /*updates the Rating given by user*/
        updateRating: function(element) {
            if (this.feedbackExist != undefined && this.feedbackExist == true) {
                return false;
            }
            this.feedbackInput.rating = element.currentTarget.value;
            if (this.feedbackInput.rating != "") {
                this.$el.find('#submit_feedback').removeClass('btn-disabled');
                return; //enable submit btn
            }
            this.$el.find('#submit_feedback').addClass('btn-disabled');
        },
        /*updates the Comments given by user*/
        updateFeedbackComments: function(element) {
            this.feedbackInput.comments = element.currentTarget.value;
            if (this.feedbackInput.rating != "") {
                this.$el.find('#submit_feedback').removeClass('btn-disabled');
                return; //enable submit btn
            }
            this.$el.find('#submit_feedback').addClass('btn-disabled');
        },
        /*Loads mobile feedback page*/
        loadMobileFeedbackPage: function() {
            $('.requisition-details-page').hide();
            var input = {
                "RequisitionHeaderId": this.model.toJSON().RequisitionLineOutput[0].REQUISITION_HEADER_ID,
                "RequisitionNumber": this.model.toJSON().RequisitionLineOutput[0].REQUISITION_NUMBER
            };
            showLoadingIndicator();
            this.getfeedBackModel.getFeedback(input);
        },
        /*updates the Rating given by user for mobile*/
        updateMobileRating: function(element) {
            if (this.feedbackExist != undefined && this.feedbackExist == true) {
                return false;
            }
            this.feedbackInput.rating = element.currentTarget.value;
            if (this.feedbackInput.rating != "") {
                enableDone();
                return; //enable submit btn
            }
            disableDone();
        },
        /*updates the Comments given by user for mobile*/
        updateMobileFeedbackComments: function(element) {
            this.feedbackInput.comments = element.currentTarget.value;
            if (this.feedbackInput.rating != "") {
                enableDone();
                return; //enable submit btn
            }
            disableDone();
        },
        submitFeedback: function() {
            var dataInput = {
                "REQUISITION_HEADER_ID": this.model.toJSON().RequisitionLineOutput[0].REQUISITION_HEADER_ID,
                "RequisitionNumber": this.model.toJSON().RequisitionLineOutput[0].REQUISITION_NUMBER,
                "UserName": getUsername(),
                "Rating": this.feedbackInput.rating,
                "Comments": this.feedbackInput.comments
            };
            showLoadingIndicator();
            this.feedBackModel.submitFeedback(dataInput);
        },
        loadItemDetails: function(element) {
            if ($(window).width() > 991) {
                return;
            }
            var selectedRow = $(element.currentTarget).prop('id').split('_');
            var selectedObj = _.find(this.model.toJSON().RequisitionLineOutput, function(item) {
                return item.ITEM_NUMBER == selectedRow[1];
            });
            this.$el.find('.requisition-details-page').hide();
            this.$el.find('.load-cifa-item-detail').html(this.cifaItemDetailMobileTemplate(selectedObj));
            showBackButton();
            this.subView = true;
            setTitle("CIFA Item", "");

            //var selectedTemplate;
            // this.currEle = element.currentTarget;
            // var selectedItem = $(this.currEle).prop('id');
            // var itemNo = selectedItem.split('_')[1];
            // var list = this.model.toJSON().RequisitionLineOutput;
            // selectedTemplate = _.find(list, function(item) {
            //     return item.ITEM_NUMBER === itemNo;
            // });

            var reqData = JSON.parse(localStorage.getItem('reqHeaderItemData'));
            if (reqData.STATUS.toLowerCase() === "approved" && reqData.ISO_ORDER_NUMBER != null) {
                if (selectedObj.SALES_ORDER_STATUS.toLowerCase() === "shipped") {
                    var dataInput = {
                        "RequisitionHeaderId": selectedObj.REQUISITION_HEADER_ID,
                        "RequisitionNumber": selectedObj.REQUISITION_NUMBER,
                        "SOLineId": selectedObj.SO_LINE_ID,
                        "RequisitionLineNumber": selectedObj.LINE_NUM
                    };
                    this.isMobile = true;
                    showLoadingIndicator();

                    this.ackDetails.fetchData(dataInput);
                }
            }
        },
        backButtonAction: function() {
            if (this.subView) {
                this.$el.find('.requisition-details-page').show();
                this.$el.find('.load-feedback').empty();
                setTitle("Line Details", "");
                this.$el.find('.load-cifa-item-detail').empty();
                this.subView = false;
                disableDone();
                hideHeaderButtons();
            } else {
                this.close();
                window.location.href = "#" + previousView;
            }

        },
        rightbuttonAction: function() {
            showLoadingIndicator();
            this.submitFeedback();
        },
        resultForAck: function(data) {
            hideLoadingIndicator();
            if (this.isMobile) {
                if (data.toJSON().STATUS === "ERROR" || typeof data.toJSON().GetRequisitionShipmentOutput === "undefined") {
                    $("#receiving_details_container").html(this.emptyTemplate());
                    return;
                }

                $("#receiving_details_container").html(this.receivingDetailsMobileTemplate(data.toJSON().GetRequisitionShipmentOutput[0]))
                if (isPhoneGap()) {
                    $('.dateinput').focus(function() {
                        var options = {
                            date: new Date(),
                            mode: 'date',
                            target: this
                        };

                        datePicker.show(options, function(date) {
                            $(options.target).val(date.getDate() + '-' + (date.getMonth() + 1) + '-' + date.getFullYear());
                            if ($(options.target).val() !== "") {
                                enableDone();
                            }
                        });
                    });
                } else {
                    $('.dateinput').datepicker({
                        autoclose: true,
                        format: "yyyy-mm-dd"
                            //startDate: new Date()
                    });
                }

                var options = {
                    min: 1,
                    max: 2147483647,
                    step: 1
                }
                $(".numberspinner").TouchSpin(options);
                showHeaderButtons(false, true, "", "Submit");
                enableDone();
                this.delegateEvents(this.events);
                if (data.toJSON().GetRequisitionShipmentOutput[0].AcknowledgedQuantity !== null) {
                    $('#ack_qty_input').prop('readonly', 'readonly');
                    $('#date-ack_input').prop('disabled', 'disabled');
                    $('#input_comments_txt').prop('readonly', 'readonly');
                    disableDone();
                }
                return;
            }
            if (data !== undefined && data.toJSON() !== undefined && data.toJSON().STATUS !== "ERROR" && data.toJSON().GetRequisitionShipmentOutput !== undefined) {
                var list = data.toJSON().GetRequisitionShipmentOutput;
                $(this.currEle).next().html(this.receivingDetailsTemplate(list[0]));
                if (isPhoneGap()) {
                    $('.dateinput').focus(function() {
                        var options = {
                            date: new Date(),
                            mode: 'date',
                            target: this
                        };

                        datePicker.show(options, function(date) {
                            $(options.target).val(date.getDate() + '-' + (date.getMonth() + 1) + '-' + date.getFullYear());
                            if ($(options.target).val() !== "") {
                                enableDone();
                            }
                        });
                    });
                } else {
                    $('.dateinput').datepicker({
                        autoclose: true,
                        format: "yyyy-mm-dd"
                            //startDate: new Date()
                    });
                }
                if (list[0].AcknowledgedQuantity != null) {
                    $('#rcv_ack_qty').prop('readonly', 'readonly');
                    $('#date-rcv-ack').prop('disabled', 'disabled');
                    $('#rcv_ack_comments').prop('readonly', 'readonly');
                    $('#submit_Receiving').prop('disabled', 'disabled');
                    $('#submit_Receiving').addClass('button-disable-opacity');
                }
                $(this.currEle).next().show();
            } else {
                $(this.currEle).next().html(this.emptyTemplate());
                $(this.currEle).next().show();
            }

        },
        goToHome: function() {
            window.location.href = "#home";
        },
        //Receiving details accordian
        collapseAllAccordion: function() {
            if (($($('.accordion-ack-details').next()).is(':visible'))) {
                $('.accordion-ack-details').next().hide();
                $('.accordion-ack-details').next().empty();
                return;
            }
        },

        toggleAccordian: function(element) {
            var selectedTemplate;
            this.currEle = element.currentTarget;

            if (($($(this.currEle).next()).is(':visible'))) {
                $(this.currEle).next().hide();
                $(this.currEle).next().empty();
                return;
            }
            this.collapseAllAccordion();
            var selectedItem = $(this.currEle).prop('id');
            var itemNo = selectedItem.split('_')[1];
            var list = this.model.toJSON().RequisitionLineOutput;
            selectedTemplate = _.find(list, function(item) {
                return item.ITEM_NUMBER === itemNo;
            });
            var dataInput = {
                "RequisitionHeaderId": selectedTemplate.REQUISITION_HEADER_ID,
                "RequisitionNumber": selectedTemplate.REQUISITION_NUMBER,
                "SOLineId": selectedTemplate.SO_LINE_ID,
                "RequisitionLineNumber": selectedTemplate.LINE_NUM
            };
            showLoadingIndicator();
            this.ackDetails.fetchData(dataInput);
            return false;
        },
        //Addin item to cart
        requisitionAdd2Cart: function() {
            var dataInput = { "REQUESTOR": getUsername(), "REQUISITION_NUMBER": this.model.get("RequisitionLineOutput")[0].REQUISITION_NUMBER };
            showLoadingIndicator();
            this.requisitonAddToCartModel.addToCartRequest(dataInput);
        },
        goToAcknowledgement: function(event) {
            previousView = "home";
            var ackInput = {
                "RequisitionHeaderId": this.model.toJSON().RequisitionLineOutput[0].REQUISITION_HEADER_ID,
                "RequisitionNumber": this.model.toJSON().RequisitionLineOutput[0].REQUISITION_NUMBER
            }

            breadCrumbs.push({
                "name": "Acknowledgement",
                "href": "#acknowledgement"
            });
            updateBreadCrumbs();
            toggleBackButton();
            var acknowledgementView = new AcknowledgementView();
            this.childView = acknowledgementView;
            //AppView.setCurrentView(acknowledgementView);
            showLoadingIndicator();
            acknowledgementView.model.fetchData(ackInput);
            setTitle("Acknowledgement", "");
            showBackButton();
        },
        resultAfterSubmit: function(data) {
            hideLoadingIndicator();
            modalMsg(data.toJSON().STATUS_MESSAGE, data.toJSON().STATUS.toLowerCase());
            if (data.toJSON().STATUS == "SUCCESS") {
                $('#submit_feedback').hide();
                $('.feedback-txtarea').prop('readonly', true);
                $('.desktop-star').prop('disabled', 'disabled');
            }

        },

        submitReceivingDetails: function(event) {
            var inputData = {
                "InsertRequisitionAckInput": []
            }

            if ($("#rcv_ack_qty").val().trim() === "" || $("#date-rcv-ack").val().trim() === "") {
                modalMsg("Please fill Acknowledge Quantity and Acknowledgement Date.", "error");
                return;
            }
            var item = this.ackDetails.toJSON().GetRequisitionShipmentOutput[0];
            var data = {
                "RequisitionNumber": item.RequisitionNumber,
                "RequisitionHeaderId": JSON.parse(localStorage.getItem("reqHeaderItemData")).REQUISITION_HEADER_ID,
                "RequisitionLineNumber": item.RequisitionlineNumber,
                "UserName": getUsername(),
                "ShipmentNumber": item.ShipmentNumber,
                "ShipmentDate": item.ShipmentDate,
                "ShippedQuantity": "",
                "QuantityReceived": item.QuantityReceived,
                "AcknowledgedQuantity": $("#rcv_ack_qty").val().trim(),
                "AcknowledgedDate": $("#date-rcv-ack").val(),
                "Comments": $('#rcv_ack_comments').val().trim(),
                "SourceOrganizatioId": item.SourceOrganizatioId
            }
            inputData.InsertRequisitionAckInput.push(data);
            showLoadingIndicator();
            this.ackInsertModel.fetchData(inputData);
        },
        resultAfterAdd2Cart: function(data) {
            modalMsg(data.toJSON().STATUS_MESSAGE, "success", "Message");
            this.itemcountModel.getCartItems();
        },
        resultAfterItemCountFetch: function() {
            hideLoadingIndicator();
        },
        resultAfterSubmitReceivingDetails: function(data) {
            hideLoadingIndicator();
            if (data.toJSON().STATUS === "SUCCESS") {
                $('#submit_Receiving').prop('disabled', 'disabled');
                $('#submit_Receiving').addClass('button-disable-opacity');
            }

        },

        onClose: function() {
            //console.log("closing req detail view");
        }

    });

    return RequisitionDetailsView;
});