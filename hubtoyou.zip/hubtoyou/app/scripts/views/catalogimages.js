/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/previewimage',
    'models/uploadimages',
    'models/itemdetails',
], function($, _, Backbone, JST, PreviewImgModel, UploadImgesModel, ItemDetailsModel) {
    'use strict';

    var CatalogImagesView = Backbone.View.extend({
        template: JST['app/scripts/templates/catalogimages.ejs'],
        previewtemplate: JST['app/scripts/templates/previewimages.ejs'],
        uploadtemplate: JST['app/scripts/templates/uploadimages.ejs'],
        noRecords: JST['app/scripts/templates/norecords.ejs'],
        model: new PreviewImgModel(),
        el: '#container',
        id: '',
        uploadFiles: [],
        className: 'viewCatalogImages',
        cifaitemerror: true,
        events: {
            'click #previewImgBtn': 'renderPreview',
            'click #uploadImgBtn': 'renderUpload',
            'change #upload-from-gallery': 'uploadGallery',
            'click #uploadtoserver': 'uploadToServer',
            'click #previewSearch': 'previewSearch',
            'click .large-img': 'largeImageModal',
            'click #upload-from-camera': 'uploadFromCamera',
            'keyup #previewInput': 'checkNumber',
            'blur #previewInput': 'checkZero',
            "click #btn_qr_scan": "scanQR",

        },

        initialize: function() {
            AppView.currentView = this;
            this.uploadimagesmodel = new UploadImgesModel();
            this.previewimagesmodel = new PreviewImgModel();
            this.itemdetailsmodel = new ItemDetailsModel();

            this.listenTo(this.previewimagesmodel, 'change', this.afterFetchPreviewImage);
            this.listenTo(this.model, 'change', this.render);
            this.listenTo(this.uploadimagesmodel, 'change', this.AfterUploadImages);
            this.listenTo(this.itemdetailsmodel, 'change', this.AfterDescriptionFetch);


            this.$el.html(this.template());
            //this.renderUpload();
            this.renderPreview();
            showHeaderButtons(false, true, "Reset", "Save");

        },

        renderPreview: function(data) {
            $("#previewImgBtn").addClass("btn-selected");
            $("#uploadImgBtn").removeClass("btn-selected");
            if (_.findWhere(breadCrumbs, { name: 'Upload Image' })) {
                breadCrumbs.forEach(function(item, index) {
                    if (item.name == "Upload Image") {
                        breadCrumbs.splice(index, 1);
                    }
                });
            }
            if (!_.findWhere(breadCrumbs, { name: 'Preview Image' })) {
                breadCrumbs.push({ href: '#', name: 'Preview Image' });
            }
            updateBreadCrumbs();
            disableSaveBtn();
            this.$el.find('.catalog-images-content').html(this.previewtemplate());
            this.delegateEvents(this.events);
            return this;
        },
        renderUpload: function(data) {
            this.uploadFiles = [];
            $("#uploadImgBtn").addClass("btn-selected");
            $("#previewImgBtn").removeClass("btn-selected");
            if (_.findWhere(breadCrumbs, { name: 'Preview Image' })) {
                breadCrumbs.forEach(function(item, index) {
                    if (item.name == "Preview Image") {
                        breadCrumbs.splice(index, 1);
                    }
                });
            }
            if (!_.findWhere(breadCrumbs, { name: 'Upload Image' })) {
                breadCrumbs.push({ href: '#', name: 'Upload Image' });
            }
            updateBreadCrumbs();
            enableSaveBtn();
            this.$el.find('.catalog-images-content').html(this.uploadtemplate());
            this.delegateEvents(this.events);
            return this;
        },
        uploadGallery: function(element) {
            var ele = element.currentTarget;
            console.log("upload-from-gallery.. value.. " + $('#upload-from-gallery').val());
            for (var i = 0; i < ele.files.length; i++) {
                var file = ele.files[i];
                var filename = file.name.substr(0, file.name.lastIndexOf('.'));
                var ext = file.name.substr(file.name.lastIndexOf('.') + 1);
                //if (!_.findWhere(this.uploadFiles, { "ImageName": filename })) {

                if (ext == 'jpg' || ext == 'JPG' || ext == 'jpeg' || ext == 'JPEG') {
                    this.readFile(file);
                    console.group("File " + i);
                    console.log("name : " + file.name);
                    console.log("size : " + file.size);
                    console.log("type : " + file.type);
                    console.groupEnd();
                } else {
                    $('.uploaderror').html("File format should be JPG or JPEG");
                    return false;
                }

                /*}else{
                     $('.uploaderror').html("This File Name Already Exists");
                     return false;
                }*/
            }
        },

        readFile: function(file) {
            var self = this;
            $('.uploaderror').html("");
            var reader = new FileReader();
            var rowObj = {
                "filename": file.name
            }
            var listrow = this.buildListRowHTML(rowObj);

            var result = '';
            reader.onload = function(e) {
                result = e.target.result;
                console.log("element.target.result.." + e.target.result);

                $("#imagelistgallery").show();
                $("#imagelistgallery").append(listrow);
                $('#imagelistgallery').on('click', '.deleteimage', self.deleteImage);
                $('#imagelistgallery').on('click', '.checkimage', self.checkValue);
                $('#imagelistgallery').on('keyup', '.cifanumberinput', self.checkNumber);
                $('#imagelistgallery').on('blur', '.cifanumberinput', self.checkZero);
                var base64value = e.target.result.replace("data:image/jpeg;base64,", "");
                var filename = file.name;
                var obj = {
                    "filename": filename,
                    "base64value": base64value
                }
                self.buildFileList(obj);
                $('#upload-from-gallery').val("");
            };
            // reader.readAsText(file);
            reader.readAsDataURL(file);
            return result;
        },
        buildFileList: function(data) {
            var imgdata = {
                "ImageName": data.filename,
                "ImageBinary": data.base64value
            }
            console.log("Final..this.uploadFiles..List.. " + JSON.stringify(this.uploadFiles));
            this.uploadFiles.push(imgdata);
        },
        buildListRowHTML: function(filedata) {
            var listrow = '<div class="imglistrow">' +
                '<div class="filename">' + filedata.filename + '</div>' +
                '<div class="uploadcifanumber"><input type="text" class="cifanumberinput" placeholder="Enter CIFA Item #"  maxlength="9" /></div>' +
                '<div class="checkimage text-center"> <div class="check-bg"></div></div>' +
                '<div class="deleteimage text-center"> <div class="delete-bg2"></div></div>' +
                '</div>' +
                '<div class="descriptionrow" style="display:none;"><label class="label-value">Description:&nbsp;</label><div class="desccontent"></div></div>';
            return listrow;
        },
        formatBytes: function(bytes, decimals) {
            if (bytes == 0) return '0 Byte';
            var k = 1000; // or 1024 for binary
            var dm = decimals + 1 || 3;
            var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
            var i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
        },
        checkValue: function(element) {
            var self = AppView.currentView;
            globalize.itemDescDiv = $(element.currentTarget).parent().next();
            var curInput = $(element.currentTarget).prev().find('.cifanumberinput');
            var value = $(element.currentTarget).prev().find('.cifanumberinput').val();

            var max_chars = 9;
            if (value.length > max_chars) {
                value = value.substr(0, max_chars);
                $(curInput).val(value);
            }
            if (value > 0) {
                this.cifaitemerror = true;
                $('.uploaderror').html("");
                $(globalize.itemDescDiv).hide();
                $(globalize.itemDescDiv).find('.desccontent').html("");
                showLoadingIndicator();
                self.itemdetailsmodel.fetchData(self.prefixZeros(value));
            } else {
                $('.uploaderror').html("Please enter valid CIFA Item Number");
            }
        },
        checkNumber: function(element) {
            var eleval = element.currentTarget.value;
            if (isNaN(eleval)) {
                $(element.currentTarget).val("");
            }
        },
        checkZero: function(element) {
            var self = AppView.currentView;
            var eleval = element.currentTarget.value;
            if ((eleval > 0) && (eleval.length < 9)) {
                $(element.currentTarget).val(self.prefixZeros(eleval));
            }
        },
        AfterDescriptionFetch: function(data) {
            var resultdata = data.responseData;
            hideLoadingIndicator();
            if (resultdata.STATUS == "SUCCESS" && typeof resultdata.ItemDetailsOutput !== "undefined") {
                var desc = resultdata.ItemDetailsOutput[0].ITEM_DESCRIPTION;
                this.cifaitemerror = true;
                if (desc) {
                    $(globalize.itemDescDiv).show();
                    $(globalize.itemDescDiv).find('.desccontent').html(desc);
                }
            } else {
                this.cifaitemerror = false;
                $('.uploaderror').html("Please enter valid CIFA Item Number");
            }
        },
        prefixZeros: function(n, width, z) {
            z = z || '0';
            width = width || 9;
            n = n + '';
            return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
        },
        deleteImage: function(element) {
            $('.uploaderror').html("");
            var self = AppView.currentView;
            var current = element.currentTarget.parentElement;
            var filename = $(current).find('.filename').text();
            if (_.findWhere(self.uploadFiles, { "ImageName": filename })) {
                self.uploadFiles.forEach(function(item, index) {
                    if (filename == item.ImageName) {
                        self.uploadFiles.splice(index, 1);
                        $(current).next().remove();
                        $(current).remove();
                        if (self.uploadFiles.length == 0) {
                            $("#imagelistgallery").hide();
                        }
                    }
                });
            }
        },

        uploadToServer: function() {
            var self = this;
            var checkempty = true;
            var checkzerovalue = true;
            var tempArray = [];
            if (this.uploadFiles.length > 0) {
                $('.cifanumberinput').each(function(i, obj) {
                    var cifanumber = $(this).val();
                    tempArray.push(cifanumber);
                    if (!/^\d+$/.test(cifanumber)) {
                        checkempty = false;
                    }
                    if (cifanumber <= 0) {
                        checkzerovalue = false;
                    }
                });
                if (checkempty && checkzerovalue && this.cifaitemerror) {
                    if (tempArray.length == _.uniq(tempArray).length) {
                        $('.uploaderror').html("");
                        $('.imglistrow').each(function(i, obj) {
                            var filename = $(this).find('.filename').text();
                            var cifanumber = $(this).find('.cifanumberinput').val();
                            console.log("filename..." + filename + " cifanumber.." + cifanumber);
                            self.uploadFiles.forEach(function(item, index) {
                                if (filename == item.ImageName) {
                                    item['ImageName'] = cifanumber;
                                }
                            });
                        });

                        var dataInput = {
                            "RequestorName": getUsername(),
                            "UploadImageInput": this.uploadFiles
                        }
                        console.log("upload request json..." + JSON.stringify(dataInput));
                        showLoadingIndicator();
                        this.uploadimagesmodel.uploadImagesRequest(dataInput);
                    } else {
                        $('.uploaderror').html("CIFA Item Number Sholud be Unique");
                    }

                } else {
                    $('.uploaderror').html("Please Enter Valid CIFA Item Number for uploaded Images");
                }

            } else {
                $('.uploaderror').html("Request could not be submitted. Select some file to upload and try again.");
            }

        },

        AfterUploadImages: function(data) {
            console.log(data);
            hideLoadingIndicator();
            if (data.responseData.STATUS == "SUCCESS") {
                this.uploadFiles = [];
                $('.uploaderror').html(data.responseData.STATUS_MESSAGE);
                $("#imagelistgallery").empty().hide();
            } else {
                this.uploadFiles = [];
                $('.uploaderror').html(data.responseData.STATUS_MESSAGE);
                $("#imagelistgallery").empty().hide();
            }
        },

        previewSearch: function() {
            var cifano = $('#previewInput').val();
            if (/^\d+$/.test(cifano) && (cifano > 0)) {
                var dataInput = {
                    "PreviewImageInput": [{
                        "ImageName": cifano
                    }]
                };
                showLoadingIndicator();
                this.previewimagesmodel.fetchData(dataInput);
            } else {
                $('.previewerror').html('Please enter valid CIFA Item Number');
            }
        },
        afterFetchPreviewImage: function(data) {
            console.log(data);
            hideLoadingIndicator();
            if (data.responseData.STATUS == "SUCCESS") {
                $('.previewerror').html('');
                if (typeof data.responseData.PreviewImageOutput == "object") {
                    $("#previewInput").val("");
                    $("#previewImageSrc").attr("src", data.responseData.PreviewImageOutput[0].ImageUrl);
                }
            } else {
                $('.previewerror').html(data.responseData.STATUS_MESSAGE);
            }
        },
        largeImageModal: function(element) {
            console.log($('#previewImageSrc').attr("src"));
            modalImage($('#previewImageSrc').attr("src"));
        },
        rightbuttonAction: function() {
            this.uploadToServer();
        },
        scanQR: function() {
            if (isPhoneGap()) {
                cordova.plugins.barcodeScanner.scan(
                    function(result) {
                        $("#previewInput").val(result.text);

                        console.log("We got a barcode\n" +
                            "Result: " + result.text + "\n" +
                            "Format: " + result.format + "\n" +
                            "Cancelled: " + result.cancelled);
                    },
                    function(error) {
                        console.log("Scanning failed: " + error);
                    }, {
                        "preferFrontCamera": false, // iOS and Android
                        "showFlipCameraButton": true, // iOS and Android
                        "prompt": "Place a QR code inside the scan area", // supported on Android only
                        "formats": "QR_CODE", // default: all but PDF_417 and RSS_EXPANDED
                        "orientation": "portrait" // Android only (portrait|landscape), default unset so it rotates with the device
                    }
                );
            }
        },
        uploadFromCamera: function() {
            console.log("calling takepicture...")
            this.takePicture();
        },
        takePicture: function() {
            var self = this;
            var options = {
                quality: 50,
                destinationType: navigator.camera.DestinationType.FILE_URI,
                sourceType: navigator.camera.PictureSourceType.CAMERA,
                encodingType: navigator.camera.EncodingType.JPEG
            }
            navigator.camera.getPicture(function cameraSuccess(imagedata) {
                /* var img = $('<img style="width:60px;height:60px;margin-right:10px;"></img>');
                 var src = 'data:image/jpeg;base64,' + imagedata;
                */
                console.log("image uri... " + imagedata);
                var tempfilename = imagedata.split('\\').pop().split('/').pop();
                console.log("tempfilename... " + tempfilename);

                self.getFileContentAsBase64(imagedata, function(base64Image) {
                    console.log("final base64Image..." + base64Image);
                    //img.attr('src', base64Image);
                    //img.appendTo("#imgcontainer");
                    $('.uploaderror').html("");
                    var rowObj = {
                        "filename": tempfilename
                    }
                    var listrow = self.buildListRowHTML(rowObj);
                    $("#imagelistgallery").show();
                    $("#imagelistgallery").append(listrow);
                    $('#imagelistgallery').on('click', '.deleteimage', self.deleteImage);
                    $('#imagelistgallery').on('click', '.checkimage', self.checkValue);
                    $('#imagelistgallery').on('keyup', '.cifanumberinput', self.checkNumber);
                    $('#imagelistgallery').on('blur', '.cifanumberinput', self.checkZero);
                    var base64value = base64Image.replace("data:image/jpeg;base64,", "");
                    var obj = {
                        "filename": tempfilename,
                        "base64value": base64value
                    }
                    self.buildFileList(obj);

                });

            }, function cameraError(error) {
                console.log("Unable to obtain picture: " + error);
                modalMsg("Unable to obtain picture: " + error, "error");
            }, options);
        },
        getFileContentAsBase64: function(path, callback) {
            window.resolveLocalFileSystemURL(path, gotFile, fail);

            function fail(e) {
                console.log('Cannot found requested file');
                modalMsg("Cannot found requested file", "error");
            }

            function gotFile(fileEntry) {
                fileEntry.file(function(file) {
                    var reader = new FileReader();
                    reader.onloadend = function(e) {
                        var content = this.result;
                        console.log("got file...");
                        callback(content);
                    };
                    // The most important point, use the readAsDatURL Method from the file plugin
                    reader.readAsDataURL(file);
                });
            }
        }
    });

    return CatalogImagesView;
});