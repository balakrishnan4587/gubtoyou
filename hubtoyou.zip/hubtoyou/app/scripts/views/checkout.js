/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/shoppingcart',
    'models/checkout',
], function($, _, Backbone, JST, getCartDetailsModel, CheckoutModel) {
    'use strict';

    var CheckoutView = Backbone.View.extend({
        template: JST['app/scripts/templates/checkout.ejs'],
        noRecords: JST['app/scripts/templates/norecords.ejs'],
        viewName: 'viewCheckout',
        el: '#container',
        tagName: 'div',
        model: new getCartDetailsModel(),
        id: '',
        className: '',
        events: {
            'click .gotobackBtn': 'goToBack',
            'click #checkoutbtn': 'checkoutSubmit'

        },
        initialize: function() {
            //AppView.currentView = this;
            this.checkoutmodel = new CheckoutModel();
            this.listenTo(this.model, 'change', this.render);
            this.listenTo(this.checkoutmodel, 'change', this.AfterCheckout);

        },
        render: function(data) {
            var dataitems = data.responseData;
            if (typeof dataitems.ShoppingCartDetails == "undefined") {
                this.$el.html(this.noRecords()); //Display No records View
                return;
            }
            var listitems = dataitems.ShoppingCartDetails;
            if (listitems.length > 0) {
                listitems = sortByKey(listitems, "LINE_NUMBER");
            }
            showHeaderButtons(false, true, "Reset", "Checkout");
            enableDone();
            this.model1 = { "ShoppingCartDetails": listitems };
            this.$el.html(this.template(this.model1));
            this.delegateEvents(this.events);
            hideLoadingIndicator();
            return this;
        },
        goToBack: function() {
            var len = breadCrumbs.length;
            breadCrumbs.splice(len - 1, 1);
            updateBreadCrumbs();
            //window.history.back();
            window.location.href = "#shoppingcart";
        },
        backButtonAction: function() {
            var len = breadCrumbs.length;
            breadCrumbs.splice(len - 1, 1);
            updateBreadCrumbs();
            toggleBackButton();
            //window.history.back();
            window.location.href = "#shoppingcart";
        },
        checkoutSubmit: function() {
            var desc = $("#requisition-desc").val();
            var personid = localStorage.getItem("personID");
            var datainput = {
                "REQUESTOR_ID": personid,
                "REQ_DESC": desc
            }
            showLoadingIndicator();
            this.checkoutmodel.checkoutRequest(datainput);
        },
        AfterCheckout: function(data) {
            var response = data;
            hideLoadingIndicator();
            if (response.responseData.STATUS == "SUCCESS") {
                modalMsg(response.responseData.STATUS_MESSAGE, "success");
                window.location.href = "#home";
            } else {
                modalMsg(response.responseData.STATUS_MESSAGE, "error");
            }
        },
        rightbuttonAction: function() {
            this.checkoutSubmit();
        }


    });

    return CheckoutView;
});