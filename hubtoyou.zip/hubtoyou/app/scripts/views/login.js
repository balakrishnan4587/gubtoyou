/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'helper'
], function($, _, Backbone, JST, helper) {
    'use strict';

    var LoginView = Backbone.View.extend({
        template: JST['app/scripts/templates/login.ejs'],

        el: '#container',

        //tagName: 'div',

        viewName: 'loginView',

        id: '',

        className: '',

        events:{
            'click #loginTrouble':'loginBySafari'
        },

        initialize: function() {
            hideLoadingIndicator();
        },

        render: function() {
            this.$el.html(this.template());
            this.delegateEvents(this.events);
            return this;
        },
        loginBySafari: function(){
            auth0.authorize(true);
        }

    });

    return LoginView;
});