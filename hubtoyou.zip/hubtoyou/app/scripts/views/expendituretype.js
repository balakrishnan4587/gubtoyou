/*globalize*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/expendituretype'
], function($, _, Backbone, JST, ExpenditureTypeModel) {
    'use strict';

    var ExpenditureTypeView = Backbone.View.extend({
        template: JST['app/scripts/templates/expendituretype.ejs'],
        searchexpendituretype: JST['app/scripts/templates/searchexpendituretype.ejs'],
        el: '#projectNoSearch',
        id: '',
        className: '',
        inputData: {},
        events: {
            'click #search': 'search',
            'click .gotoBack': 'closeSearchWindow',
            'click .selectRecordRow': 'selectRecord',
            'click #PopulateProjectNumber': 'populateExpenditureType',
            'change #ExpendTypeInput': 'updateExpendType',
            'change #ExpendCategoryInput': 'updateExpendCategory',
            'change #ExpendDescInput': 'updateExpendDesc'
        },

        initialize: function() {
            if (AppView.currentView !== undefined) {
                globalPreviousView = AppView.currentView;
            }
            AppView.currentView = this;
            this.expenditureTypeResults = new ExpenditureTypeModel();
            this.render();
            this.listenTo(this.expenditureTypeResults, 'change', this.renderTable); //search for locations      
        },

        render: function() {
            this.$el.html(this.template());
        },
        validateSearchButton: function(value) {
            if (isValid(value.ExpendType) || isValid(value.ExpendCategory) || isValid(value.ExpendDesc)) {
                this.$el.find('#search').removeClass('button-disable-opacity');
                return;
            } else {
                this.$el.find('#search').addClass('button-disable-opacity');
            }
        },
        /*User input updation in tasknumber window*/
        updateExpendType: function(event) {
            this.inputData.ExpendType = event.currentTarget.value;
            //this.validateSearchButton(this.inputData);
        },
        updateExpendCategory: function(event) {
            this.inputData.ExpendCategory = event.currentTarget.value;
            //this.validateSearchButton(this.inputData);
        },
        updateExpendDesc: function(event) {
            this.inputData.ExpendDesc = event.currentTarget.value;
            //this.validateSearchButton(this.inputData);
        },

        search: function() {
            var dataInput = {
                "ExpenditureType": this.inputData.ExpendType,
                "ExpenditureCategory": this.inputData.ExpendCategory,
                "Description": this.inputData.ExpendDesc
            }
            showLoadingIndicator();
            this.expenditureTypeResults.fetchData(dataInput);

        },
        renderTable: function() {
            this.$el.find('.load-results').html(this.searchexpendituretype(this.expenditureTypeResults.toJSON()));
            hideLoadingIndicator();
            $('[data-toggle="tooltip"]').tooltip();
        },
        /* Record selection from table */
        selectRecord: function(element) {
            var selectedTemplate;
            var selectId = $(element.currentTarget).prop('id');
            var cur_row = selectId.split("_");
            $("#radioBtn_" + cur_row[1]).prop("checked", true);
            $(".mobile-select-btn").addClass("hidden");
            $("#mob-row_" + cur_row[1]).removeClass("hidden");

            var expendType = $("#expendType_" + cur_row[1]).text();
            var list = this.expenditureTypeResults.toJSON().ExpenditureTypeOutput;
            selectedTemplate = _.find(list, function(item) {
                return item.ExpenditureType === expendType;
            });
            this.selectedTemplate = selectedTemplate;
            this.selectedCode = selectedTemplate.ExpenditureType;
            enableDone();

        },
        populateExpenditureType: function() {
            $(globalize.expedituretypeInputBox).val(this.selectedCode);
            /* update cart details json */
            var keyparam = $(globalize.expedituretypeInputBox).data("keyparam");
            var lineno = $(globalize.expedituretypeInputBox).data("lineno");
            var updatevalue = this.selectedCode;
            saveCartDetails(keyparam, updatevalue, lineno);
            /* update cart details json */
            this.$el.empty();
            this.close(); //to kill the current view
            updateBreadcrumbsToParent() //to update the parent page breadcrumb
            showHeaderButtons(false, true, "Reset", "Submit");
            if ($('.mobile-update-cart-lines').children().length > 0) {
                AppView.currentView = globalView; //setting for usage in mobile view for getting bakc the parent view
                $('.mobile-update-cart-lines').show();
                $(globalize.taskInputBox).removeClass('contain-error');
                enableDone();
                return;
            }
            AppView.currentView = globalView;
            $('.shoppingcart-page').show();
            $(globalize.taskInputBox).removeClass('contain-error');
            $('#update_submit').removeClass('button-disable-opacity');
        },
        closeSearchWindow: function(element) {
            $('.shoppingcart-page').show();
            this.$el.empty();
            this.close(); //to kill the current view
            updateBreadcrumbsToParent() //to update the parent page breadcrumb
        },
        backButtonAction: function(element) {
            if (globalize.updateCartLine != undefined && globalize.updateCartLine == true) {
                $('.mobile-update-cart-lines').show();
                AppView.currentView = globalView;
            } else {
                $('.shoppingcart-page').show();
                showHeaderButtons(false, true, "Reset", "Submit");
                removeBackButton();
            }
            this.$el.empty();
            this.close(); //to kill the current view
            updateBreadcrumbsToParent() //to update the parent page breadcrumb            
        },
        rightbuttonAction: function() {
            this.populateExpenditureType();
        }
    });

    return ExpenditureTypeView;
});