/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/acknowledementdetails',
    'models/acknowledementinsert'
], function($, _, Backbone, JST, AcknowledgeModel, AckInsertModel) {

    'use strict';

    var AcknowledgementView = Backbone.View.extend({
        template: JST['app/scripts/templates/acknowledgement.ejs'],
        itemTemplate: JST['app/scripts/templates/acknowledgementitem.ejs'],
        emptyTemplate: JST['app/scripts/templates/norecords.ejs'],
        viewName: 'acknowledgement',
        // collection: new AcknowledgementCollection(),
        el: '#ackview_container',
        //tagName: 'div',
        events: {
            'click #btn_acknowledgement_back': 'backButtonAction',
            "change #mob_allCHK": 'ackSelectAll',
            "change #allCHK": 'ackSelectAll',
            'click #btn_acknowledgement_save': 'insertAcknowledgement'
        },
        initialize: function(options) {
            //this.reqView = options.data;
            this.model = new AcknowledgeModel();
            this.insertModel = new AckInsertModel();
            this.listenTo(this.model, 'sync', this.render);
            this.listenTo(this.insertModel, 'sync', this.onAckInsertFinish);
            // this.render();

        },
        render: function(data) {
            hideLoadingIndicator();
            //AppView.currentView = this;
            if (previousView == "reports") {
                $('.requisition-details-page').hide();
                this.$el.html(this.template(data.toJSON()));
            } else {
                $("#reqdetail_container").hide();
                this.$el.html(this.template(data.toJSON()));
            }

            if (data.toJSON().STATUS === "ERROR" || typeof data.toJSON().GetRequisitionShipmentOutput === "undefined") {
                $('#ack_item_container').html(this.emptyTemplate());
                $('#btn_acknowledgement_save').hide();
                $('.ack_selectall_container').hide()
                hideHeaderButtons();
                return;
            } else {
                // <% var list = obj.GetRequisitionShipmentOutput;
                // for(var i=0; i<list.length;i++){
                //     %>

                // <%}%>
                var _this = this;
                var items = data.toJSON().GetRequisitionShipmentOutput;
                var count = 0;
                items.forEach(function(item, index) {
                    item.index = index;
                    if (item.AcknowledgedQuantity === null) {
                        $('#ack_item_container').append(_this.itemTemplate(item));
                        count++;
                    }
                });

                if (isPhoneGap()) {
                    $('.dateinput').click(function() {
                        var options = {
                            date: new Date(),
                            mode: 'date',
                            target: this
                        };

                        datePicker.show(options, function(date) {
                            $(options.target).val(date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate());
                        });
                    });
                } else {
                    $('.dateinput').datepicker({
                        autoclose: true,
                        format: "yyyy-mm-dd",
                        startDate: new Date()
                    });
                }
            }

            var options = {
                min: 1,
                max: 2147483647,
                step: 1
            }
            if (count > 0) {
                $('#btn_acknowledgement_save').show();
                $(".numberspinner").TouchSpin(options);
                showHeaderButtons(false, true, "", "Save");
                enableDone();
            } else {
                $('#ack_item_container').html(this.emptyTemplate());
                $('#btn_acknowledgement_save').hide();
                $('.ack_selectall_container').hide()
                hideHeaderButtons();
            }
            this.delegateEvents(this.events);
            hideLoadingIndicator();
            return this;
        },


        onAckInsertFinish: function() {
            $('#btn_acknowledgement_save').attr("disabled", true);
            $('#btn_acknowledgement_save').addClass("button-disable-opacity");
            //$('.ack_selectall_container').hide();
            hideHeaderButtons();
        },

        // goToBack: function() {
        //     var len = breadCrumbs.length;
        //     breadCrumbs.splice(len - 1, 1);
        //     updateBreadCrumbs();
        //     window.history.back();
        // },
        backButtonAction: function() {
            var len = breadCrumbs.length;
            breadCrumbs.splice(len - 1, 1);
            updateBreadCrumbs();
            toggleBackButton();
            if (previousView == "reports") {
                $('.requisition-details-page').show();
                $('.load-acknowldegement').empty();
                return;
            }
            $('#ackview_container').empty();
            this.close();
            $("#reqdetail_container").show();
            //AppView.currentView = this.reqView;
            showBackButton();
        },

        ackSelectAll: function(event) {
            var count = this.model.toJSON().GetRequisitionShipmentOutput.length;
            if (event.currentTarget.id === "mob_allCHK") {
                for (var i = 0; i < count; i++) {
                    $("#mob_chk_" + i).prop("checked", event.currentTarget.checked);
                }
            } else {
                for (var i = 0; i < count; i++) {
                    $("#id_chk_" + i).prop("checked", event.currentTarget.checked);
                }
            }
        },

        rightbuttonAction: function(event) {
            this.insertAcknowledgement(event);
        },

        insertAcknowledgement: function(event) {
            var count = this.model.toJSON().GetRequisitionShipmentOutput.length;
            var inputData = {
                "InsertRequisitionAckInput": []
            }
            if (event.currentTarget.id === "mb_button_right") {
                for (var i = 0; i < count; i++) {
                    if ($("#mob_chk_" + i).prop("checked") === true) {
                        if ($("#ack_qty_" + i).val().trim() === "" || $("#date-ack_" + i).val().trim() === "") {
                            modalMsg("Please fill Acknowledge Quantity and Acknowledgement Date.", "error");
                            return;
                        }
                        var item = this.model.toJSON().GetRequisitionShipmentOutput[i];
                        var data = {
                            "RequisitionNumber": item.RequisitionNumber,
                            "RequisitionHeaderId": JSON.parse(localStorage.getItem("reqHeaderItemData")).REQUISITION_HEADER_ID,
                            "RequisitionLineNumber": item.RequisitionlineNumber,
                            "UserName": getUsername(),
                            "ShipmentNumber": item.ShipmentNumber,
                            "ShipmentDate": item.ShipmentDate,
                            "ShippedQuantity": "",
                            "QuantityReceived": item.QuantityReceived,
                            "AcknowledgedQuantity": $("#ack_qty_" + i).val(),
                            "AcknowledgedDate": new Date(DateFormatter($("#date-ack_" + i).val())),
                            "Comments": $('#input_comments_txt_' + i).val(),
                            "SourceOrganizatioId": item.SourceOrganizatioId
                        }
                        inputData.InsertRequisitionAckInput.push(data);
                    }
                }
            } else {
                for (var i = 0; i < count; i++) {
                    if ($("#id_chk_" + i).prop("checked") === true) {
                        if ($("#ack_qty_" + i).val().trim() === "" || $("#date-ack_" + i).val().trim() === "") {
                            modalMsg("Please fill Acknowledge Quantity and Acknowledgement Date.", "error");
                            return;
                        }
                        var item = this.model.toJSON().GetRequisitionShipmentOutput[i];
                        var data = {
                            "RequisitionNumber": item.RequisitionNumber,
                            "RequisitionHeaderId": JSON.parse(localStorage.getItem("reqHeaderItemData")).REQUISITION_HEADER_ID,
                            "RequisitionLineNumber": item.RequisitionlineNumber,
                            "UserName": getUsername(),
                            "ShipmentNumber": item.ShipmentNumber,
                            "ShipmentDate": item.ShipmentDate,
                            "ShippedQuantity": "",
                            "QuantityReceived": item.QuantityReceived,
                            "AcknowledgedQuantity": $("#ack_qty_" + i).val(),
                            "AcknowledgedDate": new Date(DateFormatter($("#date-ack_" + i).val())),
                            "Comments": $('#input_comments_txt_' + i).val(),
                            "SourceOrganizatioId": item.SourceOrganizatioId
                        }
                        inputData.InsertRequisitionAckInput.push(data);
                    }
                }
            }
            if (inputData.InsertRequisitionAckInput.length === 0) {
                modalMsg("Please select atleast one item", "error");
                return;
            }
            showLoadingIndicator();
            this.insertModel.fetchData(inputData);
        },

        onClose: function() {
            console.log("Closing Acknowledgement View");
        }
    });

    return AcknowledgementView;
});