/*global define*/

define([
  'jquery',
  'underscore',
  'backbone',
  'templates',
  'models/notification'
], function ($, _, Backbone, JST, NotificationModel) {
  'use strict';

  var NotifictaionView = Backbone.View.extend({
    template: JST['app/scripts/templates/notification.ejs'],
    model: new NotificationModel(),
    el:'#container',
    id: '',
    className: 'notificationView',    
    events: {
      
    },
    initialize: function () {
      this.listenTo(this.model, 'reset', this.render);
    },
    render: function () {
      this.$el.html(this.template());
      return this;
    }
    

  });

  return NotifictaionView;
});
