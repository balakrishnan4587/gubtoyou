/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/settings',
    'views/selectprojectnumber',
    'models/searchprojectdetails',
    'models/searchwarehouse',
    'models/searchinventory',
    'models/readonlyusers'
], function($, _, Backbone, JST, model1, SelectProjectNumberView, SearchProjectDetailsModel,
    SearchWarehouseModel, SearchInventoryModel, ReadOnlyUsersModel) {
    'use strict';

    var SettingsView = Backbone.View.extend({
        template: JST['app/scripts/templates/settings.ejs'],
        emptyTemplate: JST['app/scripts/templates/norecords.ejs'],
        model: new model1(),
        viewName: 'settingsView',
        el: '#container',
        tagName: 'div',
        id: '',

        className: '',

        events: {
            'focus .drop-down': 'showDropDown',
            'blur .drop-down': 'hideDropDown',
            'click .drop-down-picker li': 'setSelectedValue',
            'click #selectProjectNo': 'loadProjectSelectionWindow',
            'click #selectSourceWarehouse': 'loadSourceLocationWindow',
            'click #selectDeliveryLocation': 'loadDeliveryToLocationWindow',
            'click #selectSubInventory': 'loadSubInventoryWindow',
            //'blur #projectNo':'validateProjectNumber',
            'change #projectNo': 'updateProjectNumber',
            'change #srcLocation': 'updateSrc',
            'change #destLocation': 'updateDest',
            'change #subInventory': 'updateSubInventory',
            'change .numberspinner': 'updateOffsetCount',
            'change #yesNoBU': 'updateBU',
            'click #save': 'saveSettings'

        },

        initialize: function() {
            // AppView.currentView = this;
            this.saveSettingsModel = new model1();
            this.readonlyUsers = new ReadOnlyUsersModel();
            this.prDetails = new SearchProjectDetailsModel();
            this.wareHouse = new SearchWarehouseModel();
            this.wareHouseDest = new SearchWarehouseModel();
            this.inventoryDetails = new SearchInventoryModel();
            this.listenTo(this.model, 'change', this.render);
            this.listenTo(this.readonlyUsers, 'sync', this.resultAfterUserValidation);
            this.listenTo(this.prDetails, 'sync', this.validationResultProjectNo);
            this.listenTo(this.wareHouse, 'sync', this.validationResultSrc);
            this.listenTo(this.wareHouseDest, 'sync', this.validationResultDest);
            this.listenTo(this.inventoryDetails, 'sync', this.validationResultSubInventory);
            this.listenTo(this.saveSettingsModel, 'sync', this.showSaveSettingsResult);
            this.destinationChanged = false;
            this.validSrc = true;
            this.validProjectNo = true;
            this.validDest = true;
            this.validSInventory = true;
        },
        resultAfterUserValidation: function(response) {
            hideLoadingIndicator();
            if (response.toJSON().SelectedUsersListOutput !== undefined) {
                this.readonlyScreen();
            }
        },
        readonlyScreen: function() {
            this.undelegateEvents();
            $('input').prop('readonly', 'readonly');
            $('select').prop('disabled', 'disabled');
            $('#save').addClass('button-disable-opacity');
            $($('#offsetDate').next().next()[0]).find('.btn').prop('disabled', 'disabled');
            $('#offsetDate').prev().prev().find('.btn').prop('disabled', 'disabled');
        },
        render: function(model) {
            if (typeof model.toJSON().PreferencesSelectOutput == "undefined") {
                //this.$el.append(this.emptyTemplate());
                this.$el.html(this.template());
                this.$el.find('#yesNoBU').val("No");
                this.model.USER_NAME = getUsername();
                hideLoadingIndicator();
                // return;
            } else {
                this.model = model.toJSON().PreferencesSelectOutput[0];
                var user = getUsername();
                if (isOnline && offlineDB) {
                    offlineDB.clearData("settings", user);
                    var settingsData = model.toJSON();
                    settingsData.username = user;
                    offlineDB.addData("settings", user, settingsData);
                }
                showHeaderButtons(false, true, "Reset", "Save");
                enableDone();
                this.$el.html(this.template(this.model));
                $('#mb_title').html("Settings");
                if (this.model.ATTRIBUTE6 == null || this.model.ATTRIBUTE6 == "N") {
                    this.$el.find('#yesNoBU').val("No");
                } else {
                    this.$el.find('#yesNoBU').val("Yes");
                }
            }

            var spin_id = "#offsetDate";

            var min_val = 0;
            //var max_val = (item.MaximumOrder === null) ? 2147483647 : item.MaximumOrder;
            var interval = 1;

            var options = {
                initval: min_val,
                min: min_val,
                max: 10000,
                step: interval
            }
            $('#offsetDate').TouchSpin(options);
            globalize.projectNoInputBox = this.$el.find('#projectNo');
            globalize.srcInputBox = this.$el.find('#srcLocation');
            globalize.deliveryLocInputBox = this.$el.find('#destLocation');
            globalize.subInventoryInputBox = this.$el.find('#subInventory');
            this.delegateEvents(this.events);
            if (isIE) {
                $('#offsetDate').on('keypress', this.validateNumericField);
            }
            if (typeof model.toJSON().PreferencesSelectOutput != "undefined") {
                var dataInput = { "PERSON_ID": this.model.PERSON_ID }
                if (isOnline) {
                    this.readonlyUsers.getUsers(dataInput);
                }
            }
            return this;
        },
        validateNumericField: function(evt) {
            if ((evt.which < 48 || evt.which > 57) || (evt.keyCode >= 96 && evt.keyCode <= 105)) {
                evt.preventDefault();
            }
        },
        checkEmptyField: function(value, txtElement) {
            if (value == "" && $(txtElement).hasClass('contain-error')) {
                $(txtElement).removeClass('contain-error');
            }
        },
        updateProjectNumber: function(element, data) {
            if (_.isUndefined(data)) {
                this.model.PROJECT_NUMBER = element.currentTarget.value;
                this.checkEmptyField(this.model.PROJECT_NUMBER, globalize.projectNoInputBox)
                if (this.model.PROJECT_NUMBER !== '') {
                    this.validateProjectNumber();
                } else {
                    this.model.PROJECT_ID = "";
                }
            } else {
                this.model.PROJECT_NUMBER = data.data.ProjectNumber;
                this.model.PROJECT_ID = data.data.ProjectId;
                this.validProjectNo = true;
                this.validateSettingsBtn();
            }
        },
        updateSrc: function(element, data) {
            if (_.isUndefined(data)) {
                this.model.SOURCE_LOCATION = element.currentTarget.value;
                this.checkEmptyField(this.model.SOURCE_LOCATION, globalize.srcInputBox)
                if (this.model.SOURCE_LOCATION !== '') {
                    this.validateSrc();
                }

            } else {
                this.model.SOURCE_LOCATION = data.data.ORGANIZATION_CODE;
                this.validSrc = true;
                this.validateSettingsBtn();
            }

        },
        updateDest: function(element, data) {
            if (_.isUndefined(data)) {
                this.destinationChanged = true;
                this.model.DELIVERY_TO_LOCATION = element.currentTarget.value;
                this.checkEmptyField(this.model.DELIVERY_TO_LOCATION, globalize.deliveryLocInputBox)
                if (this.model.DELIVERY_TO_LOCATION !== '') {
                    this.validateDest();
                }
            } else {
                this.destinationChanged = true;
                this.model.DELIVERY_TO_LOCATION = data.data.LOCATION_CODE;
                this.model.EXPENDITURE_ORG = data.data.ORGANIZATION_CODE;
                this.model.EXPENDITURE_ORG_ID = data.data.DELIVER_TO_ORG_ID;
                this.validDest = true;
                this.validateSettingsBtn();
            }

        },
        updateSubInventory: function(element, data) {
            if (_.isUndefined(data)) {
                this.model.SUBINVENTORY = element.currentTarget.value;
                this.checkEmptyField(this.model.SUBINVENTORY, globalize.subInventoryInputBox)
                if (this.model.SUBINVENTORY !== '') {
                    this.validateSubInventory();
                }
            } else {
                this.model.SUBINVENTORY = data.data.SUBINVENTORY_NAME;
                this.validSInventory = true;
                this.validateSettingsBtn();
            }
        },
        updateOffsetCount: function(element) {
            this.model.NEED_BY_DATE_TIME = element.currentTarget.value;
        },
        updateBU: function(element) {
            var value = element.currentTarget.value;
            if (value.toLowerCase() == "yes") {
                this.model.ATTRIBUTE6 = "Y";
                localStorage.setItem("defaultBU", "Y");
            } else {
                this.model.ATTRIBUTE6 = 'N'
                localStorage.setItem("defaultBU", "N");
            }
            //(value.toLowerCase() == "yes") ? this.model.ATTRIBUTE6 = "Y": this.model.ATTRIBUTE6 = 'N';
        },
        showDropDown: function(source) {
            $(source.target).next().slideDown(200);
        },
        hideDropDown: function(source) {
            $(source.target).next().slideUp(200);
        },
        setSelectedValue: function(source) {
            $(source.target).closest('div').prev().val(source.target.innerHTML)
        },

        // goToProjectSelection: function(element) {
        //   globalize.modalTitle = globalize.selectProjectNo;
        //   globalize.selectedWIndow = $(element.currentTarget).prop('id');
        //   location.href = "#settings?view=project-selection"
        // },

        loadProjectSelectionWindow: function(element) {
            globalize.modalTitle = globalize.selectProjectNo;
            globalize.selectedWIndow = $(element.currentTarget).prop('id');
            $('.settings-page').hide();
            var projectDetailsView = new SelectProjectNumberView();
            breadCrumbs.push({ href: '#', name: 'Search And Select: Project Number' });
            showHeaderButtons(false, true, "Reset", "Done");
            updateBreadCrumbs();
            showBackButton();
            globalView = this;

        },

        loadSourceLocationWindow: function(element) {
            globalize.modalTitle = globalize.selectSrc;
            globalize.selectedWIndow = $(element.currentTarget).prop('id');
            $('.settings-page').hide();
            var projectDetailsView = new SelectProjectNumberView();
            breadCrumbs.push({ href: '#', name: 'Search And Select: Source Warehouse' });
            showHeaderButtons(false, true, "Reset", "Done");
            updateBreadCrumbs();
            showBackButton();
            globalView = this;

        },
        loadDeliveryToLocationWindow: function(element) {
            globalize.modalTitle = globalize.selectToLocation;
            globalize.selectedWIndow = $(element.currentTarget).prop('id');
            $('.settings-page').hide();
            var projectDetailsView = new SelectProjectNumberView();
            breadCrumbs.push({ href: '#', name: 'Search And Select: Delivery To Location' });
            showHeaderButtons(false, true, "Reset", "Done");
            updateBreadCrumbs();
            showBackButton();
            globalView = this;

        },
        loadSubInventoryWindow: function(element) {
            globalize.modalTitle = globalize.selectSubInventory;
            globalize.selectedWIndow = $(element.currentTarget).prop('id');
            $('.settings-page').hide();
            var projectDetailsView = new SelectProjectNumberView();
            breadCrumbs.push({ href: '#', name: 'Search And Select: Sub Inventory' });
            showHeaderButtons(false, true, "Reset", "Done");
            updateBreadCrumbs();
            showBackButton();
            globalView = this;

        },
        //Validation logics for the Input fields with service
        validateProjectNumber: function(event) {
            var dataInput = {
                "ProjectNumber": this.model.PROJECT_NUMBER
            };
            showLoadingIndicator();
            this.prDetails.fetchData(dataInput);
        },
        validationResultProjectNo: function(response) {
            hideLoadingIndicator();
            var data = this.prDetails.detailsResponse;
            if (!_.isUndefined(data.ProjectsDetailsOutput) && data.ProjectsDetailsOutput.length == 1) {
                $(globalize.projectNoInputBox).removeClass('contain-error');
                this.validProjectNo = true;
                this.validateSettingsBtn();
            } else {
                $(globalize.projectNoInputBox).addClass('contain-error');
                this.validProjectNo = false;
                this.validateSettingsBtn();
            }

        },
        validateSrc: function() {
            var dataInput = {
                "ORGANIZATION_CODE": this.model.SOURCE_LOCATION
            };
            showLoadingIndicator();
            this.wareHouse.fetchData(dataInput);
        },
        validationResultSrc: function(response) {
            hideLoadingIndicator();
            var data = this.wareHouse.warehouseResponse;
            if (!_.isUndefined(data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput) && data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput.length == 1) {
                if ($(globalize.srcInputBox).hasClass('contain-error')) {
                    $(globalize.srcInputBox).removeClass('contain-error');
                }
                this.validSrc = true;
                this.validateSettingsBtn();
            } else {
                if (!$(globalize.srcInputBox).hasClass('contain-error')) {
                    $(globalize.srcInputBox).addClass('contain-error');
                }
                this.validSrc = false;
                this.validateSettingsBtn();
            }

        },
        validateDest: function() {
            var dataInput = {
                "LOCATION_CODE": this.model.DELIVERY_TO_LOCATION
            };
            showLoadingIndicator();
            this.wareHouseDest.fetchData(dataInput);
        },
        validationResultDest: function(response) {
            hideLoadingIndicator();
            var data = this.wareHouseDest.warehouseResponse;
            if (!_.isUndefined(data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput) && data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput.length == 1) {
                if ($(globalize.deliveryLocInputBox).hasClass('contain-error')) {
                    $(globalize.deliveryLocInputBox).removeClass('contain-error');
                }
                $(globalize.deliveryLocInputBox).val(data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput[0].LOCATION_DISPLAY);
                this.model.DELIVERY_TO_LOCATION = data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput[0].LOCATION_CODE;
                this.model.EXPENDITURE_ORG = data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput[0].ORGANIZATION_CODE;
                this.model.EXPENDITURE_ORG_ID = data.EXC_SELECT_SOURCE_WH_DELIVERY_LOCOutput[0].DELIVER_TO_ORG_ID;
                this.validDest = true;
                this.validateSettingsBtn();
            } else {
                if (!$(globalize.deliveryLocInputBox).hasClass('contain-error')) {
                    $(globalize.deliveryLocInputBox).addClass('contain-error');
                }
                this.validDest = false;
                this.validateSettingsBtn();
            }

        },
        //Sub inventory
        validateSubInventory: function() {
            var dataInput = {
                "SUBINVENTORY_NAME": this.model.SUBINVENTORY
            }
            showLoadingIndicator();
            this.inventoryDetails.fetchData(dataInput);
        },
        validationResultSubInventory: function(response) {
            hideLoadingIndicator();
            var data = this.inventoryDetails.inventoryResponse;
            if (!_.isUndefined(data.EXC_DB_SELECT_SUBINVENTORYOutput) && data.EXC_DB_SELECT_SUBINVENTORYOutput.length == 1) {
                if ($(globalize.subInventoryInputBox).hasClass('contain-error')) {
                    $(globalize.subInventoryInputBox).removeClass('contain-error');
                }
                this.validSInventory = true;
                this.validateSettingsBtn();
            } else {
                if (!$(globalize.subInventoryInputBox).hasClass('contain-error')) {
                    $(globalize.subInventoryInputBox).addClass('contain-error');
                }
                this.validSInventory = false;
                this.validateSettingsBtn();
            }

        },
        validateSettingsBtn: function() {
            if (this.validSrc && this.validProjectNo && this.validDest && this.validSInventory) {
                this.$el.find('.settings-page').find('#save').prop('disabled', '');
                this.$el.find('.settings-page').find('#save').removeClass('button-disable-opacity')
                enableDone();
            } else {
                this.$el.find('.settings-page').find('#save').prop('disabled', 'disabled');
                this.$el.find('.settings-page').find('#save').addClass('button-disable-opacity')
                disableDone();
            }
        },
        formRequestData: function() {
            var dataInput = {
                "TechMobilePref": {
                    "personId": this.model.PERSON_ID,
                    "username": this.model.USER_NAME,
                    "requestor": this.model.REQUESTOR,
                    "projectNumber": this.model.PROJECT_NUMBER,
                    "projectId": this.model.PROJECT_ID,
                    "subinventory": this.model.SUBINVENTORY,
                    "needByDateTime": this.model.NEED_BY_DATE_TIME,
                    "attribute6": this.model.ATTRIBUTE6,
                    "sourceLocation": this.model.SOURCE_LOCATION
                }
            };
            if (this.destinationChanged) {
                dataInput.TechMobilePref.deliveryToLocation = this.model.DELIVERY_TO_LOCATION;
                dataInput.TechMobilePref.expenditureOrgId = this.model.EXPENDITURE_ORG_ID;
                dataInput.TechMobilePref.expenditureOrg = this.model.EXPENDITURE_ORG;
            }
            return dataInput;
        },
        rightbuttonAction: function() {
            this.saveSettings();
        },
        saveSettings: function() {
            var inputForSaveSettings = this.formRequestData();
            showLoadingIndicator();
            this.saveSettingsModel.saveData(inputForSaveSettings);
        },
        showSaveSettingsResult: function(data) {
            hideLoadingIndicator();
            if (data.toJSON().STATUS == "Success") {
                modalMsg("Your changes have been applied.", "success", "Message");
                this.fetchSettingsData();
            } else {
                modalMsg(data.toJSON().STATUS_MESSAGE, "error");
            }
        },

        fetchSettingsData: function() {
            var settingsModel = new model1();
            settingsModel.fetchData();
        }

    });

    return SettingsView;
});