/**/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'xpull',
    'collections/home',
    'routes/app_router',
    'models/shippingcartitemdetails',
    'models/settings',
    'models/addtocart',
    'models/profiledetails',
    'models/admingrantedresponsibility',
    'models/clearcart',

], function($, _, Backbone, JST, xpull, HomeCollection, Router, CartItemDetailsModel, SettingsModel, CartModel, ProfileDetailsModel,
    ResponsibilityModel, ClearCartModel) {
    'use strict';

    var HomeView = Backbone.View.extend({
        template: JST['app/scripts/templates/home.ejs'],
        requisitionList: JST['app/scripts/templates/requisitionlist.ejs'],
        noRecords: JST['app/scripts/templates/norecords.ejs'],
        filterTemplate: JST['app/scripts/templates/filterrequisition.ejs'],
        //el: $('#page'),
        collection: new HomeCollection(),
        cartItemDetailsModel: new CartItemDetailsModel(),
        //settingsModel: new SettingsModel(),
        //profileDetailsModel: new ProfileDetailsModel(),
        el: '#container',
        viewName: 'homeView',
        serviceData: {},
        events: {
            'click .select-all': 'selectAllFilters',
            'click .select-all-mobile': 'selectAllFilters',
            'click .home-checkbox': 'filterList',
            'click .home-checkbox-mobile': 'selectParticularFilter',
            'click #loadHomeFilter': 'routeTOFilter',
            'click #doneFilter': 'filterListMobile',
            //'click .requition-item': 'goToRequisitionDetails',
            'click .req-list-item': 'goToRequisitionDetails',
            'click .refresh-btn': function() {
                showLoadingIndicator();
                this.collection.fetchData();
            },
            "scroll": "detect_scroll",
            'click #btn_scroll_top': function() {
                $("html, body").animate({ scrollTop: 0 }, 300);
                return false;
            },

        },

        initialize: function(options) {
            this.clearcartmodel = new ClearCartModel();
            console.log("HomeView :::" + this);
            if (getUsername() !== "") {
                showLoadingIndicator();
            }
            this.cartmodel = new CartModel();
            globalView = this;
            if (offlineDB.db) {
                this.collection.fetchOfflineData();
            } else {
                this.collection.fetchData();
            }
            // if (isOnline) {
            //     this.collection.fetchOfflineData();
            //     //this.collection.fetchData();
            //     // this.listenTo(this.settingsModel, 'sync', this.renderContent);
            //     // this.preferenceFetch();
            // } else {
            //     this.collection.fetchOfflineData();
            // }
            this.collection.on('sort', this.render, this);
            this.collection.on('offlineReset', this.renderOfflineData, this);
            this.collection.on('sync', this.renderContent, this);
            _.bindAll(this, 'detect_scroll');
            $(window).scroll(this.detect_scroll);
        },

        fetchItemCount: function() {
            this.cartItemDetailsModel.getCartItems();
        },

        // preferenceFetch: function() {
        //     showLoadingIndicator();
        //     this.settingsModel.fetchData();
        // },
        // fetchResponsibilities: function() {
        //     var dataInput = {
        //         "BIND_APPLICATIONID": "1",
        //         "USER_NAME": getUsername()
        //     };
        //     this.userResponsibilitiesModel.getUserGrantedResponsibility(dataInput);
        // },

        renderOfflineData: function(data) {
            //console.log(data);
            if (data.length === 0) {
                this.collection.fetchData();
            } else {
                this.renderContent();
            }
            setUserDetails();
            if (!isOnline) {
                $("#menu_items a").attr("href", "#error");
            }
        },

        renderContent: function() {
            this.$el.html(this.template());
            $('#filterviewPage').hide();
            globalView = null;
            enableItemsForResponsibility();
            this.render(this.collection);
            // if (isOnline) {
            //     //this.collection.fetchData(); //home screen data
            // } else {

            // }

            if (isOnline) {
                var me = this;
                if (config.isFirstLogin === true) {
                    config.isFirstLogin = false;
                    this.collection.fetchData();
                    return;
                }
                offlineDB.getAllData("CARTLOGS", getUsername(), function(items) {
                    if (items.length > 0) {
                        offlineDB.clearData("CARTLOGS", getUsername());
                        var personid = localStorage.getItem("personID");
                        var dataInput = {
                            "REQUESTOR_ID": personid
                        }
                        showLoadingIndicator();
                        me.clearcartmodel.clearCartRequest(dataInput, function() {
                            offlineDB.syncOfflineCart(getUsername(), me.syncOfflineCartItems, me);
                        });
                    } else {
                        offlineDB.syncOfflineCart(getUsername(), me.syncOfflineCartItems, me)
                    }
                })
            }
        },
        render: function(data) {
            var _this = this;
            this.$list = $('#requition-list');
            this.$list.empty();
            if (!_.isUndefined(data.models) && data.models.length > 0) {
                //this.backupData = data;
                var user = getUsername();
                // if (isOnline) {
                //     offlineDB.clearData("requisitions", user);
                // }
                data.models.forEach(function(model) {
                    $(_this.$list).append(_this.requisitionList(model.toJSON()));
                    // if (isOnline && offlineDB) {
                    //     var item = model.toJSON();
                    //     item.username = user;
                    //     offlineDB.addData("requisitions", user, item);
                    // }
                });

            } else {
                $(_this.$list).append(this.noRecords());
            }

            this.delegateEvents(this.events);
            // var profileImage = sessionStorage.getItem("profileImage");
            // if (profileImage !== null) {
            //     $(".profile-image-mob").css('background', 'url(' + profileImage + ') no-repeat center');
            //     $("#desk-user-icon").css('background', 'url(' + profileImage + ') no-repeat center').addClass("small-profile-image");
            // }

            var profileImage = sessionStorage.getItem(getUsername() + "profileImage");
            if (profileImage !== null) {
                if (profileImage !== "") {
                    $(".profile-image-mob").css('background', 'url(' + profileImage + ') no-repeat center');
                    $("#desk-user-icon").css('background', 'url(' + profileImage + ') no-repeat center').addClass("small-profile-image");
                }
            }
            hideLoadingIndicator();
        },


        syncOfflineCartItems: function(items, me) {
            if (items.length > 0) {
                showLoadingIndicator();
                var data = {
                    "ShoppingCartUpsertData": []
                }

                items.forEach(function(item) {
                    data.ShoppingCartUpsertData.push(item);
                }, this);
                //console.log(data);
                me.cartmodel.addToCartRequest(data, me.addToCartCallback);
            } else {
                hideLoadingIndicator();
            }
        },

        addToCartCallback: function(status) {
            if (status === "SUCCESS") {
                var user = getUsername();
                offlineDB.clearData("CARTOFFLINE", user);
                modalMsg("Items added to cart while you were offline were successfully synced with server", "success");
            }
            hideLoadingIndicator();
        },


        routeTOFilter: function() {
            //window.location.href = "#homeFilter"; //changed to not to go thrugh router.
            $('#homeviewPage').hide();
            $('#filterviewPage').show();
            setTitle("Filter", "");
            //AppView.currentView = this;
            toggleBackButton();
        },
        displayString: "All",
        displayFilterArray: [],
        filterObjMobile: {},
        //Select particular filer in mobile
        selectParticularFilter: function(element) {
            this.filterObjMobile = {
                approved: $('#mob_approvedCHK').prop('checked'),
                pending: $('#mob_pendingCHK').prop('checked'),
                declined: $('#mob_declinedCHK').prop('checked'),
                onProjectHold: $('#mob_onProjectHoldCHK').prop('checked')
            };
            if (this.filterObjMobile.approved && this.filterObjMobile.declined && this.filterObjMobile.pending && this.filterObjMobile.onProjectHold) {
                $('#mob_allCHK').prop('checked', true);
                this.filterObjMobile.all = true;
            } else if (!this.filterObjMobile.approved && !this.filterObjMobile.declined && !this.filterObjMobile.pending && !this.filterObjMobile.onProjectHold) {
                $('#mob_allCHK').prop('checked', false);
                this.filterObjMobile.all = false;
            } else {
                $('#mob_allCHK').prop('checked', false);
            }
        },
        //filter confirm in mobile view
        filterListMobile: function() {
            if (this.filterObjMobile.all) {
                this.render(this.collection);
                $('.current-filter-text').text("All");
            } else {
                this.displayFilterArray = [];
                if (this.filterObjMobile.approved) {
                    this.displayFilterArray.push("Approved");
                }
                if (this.filterObjMobile.pending) {
                    this.displayFilterArray.push("In Process");
                }
                if (this.filterObjMobile.declined) {
                    this.displayFilterArray.push("Incomplete");
                }
                if (this.filterObjMobile.onProjectHold) {
                    this.displayFilterArray.push("On Project Hold");
                }
                this.render(this.collection.search(this.filterObjMobile));
                this.displayString = this.displayFilterArray.join(", ");
                $('.current-filter-text').text(this.displayString);
            }

            $('#filterviewPage').hide();
            $('#homeviewPage').show();
            toggleBackButton();
            setTitle(globalize.home, "icon-home");
            //this.goTo("home",this.collection);
            //this.render(this.collection.search(filterObj));
        },
        //Mobile view select all checkbox logic
        selectAllFilters: function(element) {
            if ($(window).width() > 767) {
                if (element.currentTarget.checked) {
                    $('.home-checkbox').each(function() {
                        this.checked = true;
                    });
                    this.render(this.collection);
                } else {
                    $('.home-checkbox').each(function() {
                        this.checked = false;
                    });
                    this.$list.empty();
                    this.$el.find('.home-page').find('#requition-list').append(this.noRecords());
                }
            } else {
                if (element.currentTarget.checked) {
                    $('.home-checkbox-mobile').each(function() {
                        this.checked = true;
                    });
                } else {
                    $('.home-checkbox-mobile').each(function() {
                        this.checked = false;
                    });
                }
                this.filterObjMobile = {
                    approved: $('#mob_approvedCHK').prop('checked'),
                    pending: $('#mob_pendingCHK').prop('checked'),
                    declined: $('#mob_declinedCHK').prop('checked'),
                    onProjectHold: $('#mob_onProjectHoldCHK').prop('checked'),
                    all: $('#mob_allCHK').prop('checked')
                }
            }
        },
        //Desktop filter action
        filterList: function(element) {
            var filterObj = {
                approved: $('#approvedCHK').prop('checked'),
                pending: $('#pendingCHK').prop('checked'),
                declined: $('#declinedCHK').prop('checked'),
                onProjectHold: $('#onProjectHoldCHK').prop('checked')
            };
            if (filterObj.approved && filterObj.declined && filterObj.pending && filterObj.onProjectHold) {
                $('#allCHK').prop('checked', true);
                this.render(this.collection);
            } else {
                if (!filterObj.approved && !filterObj.declined && !filterObj.pending && !filterObj.onProjectHold) {
                    $('#allCHK').prop('checked', false);
                    this.$list.empty();
                    this.$el.find('.home-page').find('#requition-list').append(this.noRecords());
                } else {
                    $('#allCHK').prop('checked', false);
                    this.render(this.collection.search(filterObj));
                }
            }
        },
        goToRequisitionDetails: function(element) {
            var selectId = $(element.currentTarget).prop('id');
            var cur_row = selectId.split("_");
            var selectedTemplate = _.find(this.collection.models, function(item) {
                return item.attributes.REQUISITION_NUMBER === cur_row[1];
            });
            localStorage.setItem("reqHeaderItemData", JSON.stringify(selectedTemplate));
            this.goTo("#requisitionDetail?=" + cur_row[1])
            setTitle("Line Details", "");
            showBackButton();
        },
        backButtonAction: function() {
            $('#filterviewPage').hide();
            $('#homeviewPage').show();
            removeBackButton();
        },
        detect_scroll: function(event) {
            if ($(window).scrollTop() > 0) {
                $('#btn_scroll_top').fadeIn();
            } else {
                $('#btn_scroll_top').fadeOut();
            }
        },

        onClose: function() {
            this.collection.off();
            //console.log("closing home");
        }
    });

    return HomeView;
});