/*globalize*/

define([
    'jquery',
    'underscore',
    'backbone',
    'templates',
    'models/tasknumber'
], function($, _, Backbone, JST, TaskNumberModel) {
    'use strict';

    var SelectTaskNumberView = Backbone.View.extend({
        template: JST['app/scripts/templates/tasknumber.ejs'],
        searchtasknumber: JST['app/scripts/templates/searchtasknumber.ejs'],
        el: '#projectNoSearch',
        id: '',
        className: '',
        inputData: {},
        events: {
            'click #search': 'search',
            'click .gotoBack': 'closeSearchWindow',
            'click .selectRecordRow': 'selectRecord',
            'click #PopulateProjectNumber': 'populateProjectNumber',
            'change #BuInput': 'updateBuUnit',
            'change #TaskNoInput': 'updateTaskNo',
            'change #TaskNameInput': 'updateTaskName'
        },

        initialize: function() {
            if (AppView.currentView !== undefined) {
                globalPreviousView = AppView.currentView;
            }
            AppView.currentView = this;
            this.taskNoResults = new TaskNumberModel();
            // When User has default BU as yes, we must set the BU number defaulted in the application.
            // this.DefaultBU = JSON.parse(sessionStorage.getItem("preferences")).ATTRIBUTE6;
            // if (this.DefaultBU) {
            //     this.buNumber = JSON.parse(sessionStorage.getItem("preferences")).ATTRIBUTE9;
            // } else {
            //     this.buNumber = "";
            // }
            this.DefaultBU = localStorage.getItem("defaultBU");
            if (this.DefaultBU == "Y") {
                this.buNumber = localStorage.getItem("buNumber");
            } else {
                this.buNumber = "";
            }
            this.render();
            this.listenTo(this.taskNoResults, 'change', this.renderTable); //search for locations      
        },

        render: function() {
            var data = {};
            data.bu = this.buNumber;
            this.$el.html(this.template(data));
            if (isValid(data.bu)) {
                this.inputData.BUValue = this.buNumber;
                this.validateSearchButton(this.inputData);
            }
        },
        validateSearchButton: function(value) {
            if (isValid(value.BUValue) || isValid(value.TaskNoValue) || isValid(value.TaskNameValue)) {
                //this.$el.find('#search').removeClass('button-disable-opacity');
                return;
            } else {
                //this.$el.find('#search').addClass('button-disable-opacity');
            }
        },
        /*User input updation in tasknumber window*/
        updateBuUnit: function(event) {
            this.inputData.BUValue = event.currentTarget.value;
            this.validateSearchButton(this.inputData);
        },
        updateTaskNo: function(event) {
            this.inputData.TaskNoValue = event.currentTarget.value;
            this.validateSearchButton(this.inputData);
        },
        updateTaskName: function(event) {
            this.inputData.TaskNameValue = event.currentTarget.value;
            this.validateSearchButton(this.inputData);
        },

        search: function() {
            var projectid = $(globalize.taskInputBox).data('projectid');
            var projectno = $(globalize.taskInputBox).data('projectno');
            var lineid = $(globalize.taskInputBox).data('lineno');
            /* */
            var CartItems = JSON.parse(sessionStorage.getItem("saveCartDetails"));
            CartItems.forEach(function(item, index) {
                if (lineid == item.LINE_ID) {
                    projectid = item.PROJECT_ID;
                    projectno = item.PROJECT_NUMBER;
                }
            });

            var tasktype = $(globalize.taskInputBox).data('tasktype');
            var exptype = globalize.expedituretypeVal
            var dataInput = {
                "PROJECT_ID": (isValid(projectid)) ? projectid : sessionStorage.getItem("projectId"),
                "BUSINESS_UNIT": this.inputData.BUValue,
                "TASK_NUMBER": this.inputData.TaskNoValue,
                "TASK_NAME": this.inputData.TaskNameValue,
                "PROJECT_NUMBER": (isValid(projectno)) ? projectno : sessionStorage.getItem("projectNumber"),
                "TASK_TYPE": tasktype,
                "EXPENDITURE_TYPE": exptype,
                "REQUESTOR_NAME": getUsername()
            }
            showLoadingIndicator();
            this.taskNoResults.fetchData(dataInput);

        },
        renderTable: function() {
            this.$el.find('.load-results').html(this.searchtasknumber(this.taskNoResults.toJSON()));
            hideLoadingIndicator();
        },
        /* Record selection from table */
        selectRecord: function(element) {
            var selectedTemplate;
            var selectId = $(element.currentTarget).prop('id');
            var cur_row = selectId.split("_");
            $("#radioBtn_" + cur_row[1]).prop("checked", true);
            $(".mobile-select-btn").addClass("hidden");
            $("#mob-row_" + cur_row[1]).removeClass("hidden");

            var tasknumber = $("#tasknumber_" + cur_row[1]).text();
            var list = this.taskNoResults.toJSON().EXC_DB_FETCH_TASK_DETAILSOutput;
            selectedTemplate = _.find(list, function(item) {
                return item.TASK_NUMBER === tasknumber;
            });
            this.selectedTemplate = selectedTemplate;
            this.selectedCode = selectedTemplate.TASK_NUMBER;
            enableDone();

        },
        populateProjectNumber: function() {
            $(globalize.taskInputBox).val(this.selectedCode);
            /* update cart details json */
            var keyparam = $(globalize.taskInputBox).data("keyparam");
            var lineno = $(globalize.taskInputBox).data("lineno");
            var updatevalue = this.selectedCode;
            saveCartDetails(keyparam, updatevalue, lineno);
            /*included as per business requirement given by Sathya*/
            $(globalize.expedituretypeInputBox).val(this.selectedTemplate.EXPENDITURE_TYPE);
            var keyparam = $(globalize.expedituretypeInputBox).data("keyparam");
            var lineno = $(globalize.expedituretypeInputBox).data("lineno");
            var updatevalue = this.selectedTemplate.EXPENDITURE_TYPE;
            saveCartDetails(keyparam, updatevalue, lineno);
            /* logic ends*/
            /* update cart details json */
            this.$el.empty();
            this.close(); //to kill the current view
            updateBreadcrumbsToParent() //to update the parent page breadcrumb
            showHeaderButtons(false, true, "Reset", "Submit");
            if ($('.mobile-update-cart-lines').children().length > 0) {
                $('.mobile-update-cart-lines').show();
                showHeaderButtons(false, true, "", "Done")
                $(globalize.taskInputBox).removeClass('contain-error');
                enableDone();
                AppView.currentView = globalView;
                return;
            }
            globalView.taskNoResult = true;
            AppView.currentView = globalView;
            $('.shoppingcart-page').show();
            $(globalize.taskInputBox).removeClass('contain-error');
            $('#update_submit').removeClass('button-disable-opacity');
        },
        closeSearchWindow: function(element) {
            $('.shoppingcart-page').show();
            this.$el.empty();
            this.close(); //to kill the current view
            updateBreadcrumbsToParent() //to update the parent page breadcrumb
        },
        backButtonAction: function(element) {
            if (globalize.updateCartLine != undefined && globalize.updateCartLine == true) {
                $('.mobile-update-cart-lines').show();
                AppView.currentView = globalView;
            } else {
                $('.shoppingcart-page').show();
                removeBackButton();
                showHeaderButtons(false, true, "Reset", "Submit");
            }
            globalView.delegateEvents(globalView.events);
            this.$el.empty();
            this.close(); //to kill the current view
            updateBreadcrumbsToParent() //to update the parent page breadcrumb
        },
        rightbuttonAction: function() {
            this.populateProjectNumber();
        }
    });

    return SelectTaskNumberView;
});