
/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var AdminAddRegionsModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        addRegion: function(dataInput) {
            var me = this;
            this.fetch({
                type: 'POST',
                data: JSON.stringify(dataInput),
                success: function(collection, response, options) {
                    //me.trigger('change');
                },
                error: function(collection, response, options) {
                   
                }
            });

        },

        parse: function(response, options) {
            this.responseAddRegionData = response;
            return response;
        },

        url: config.urls[config.mode] + config.service["adminaddregion"]
    });

    return AdminAddRegionsModel;
});