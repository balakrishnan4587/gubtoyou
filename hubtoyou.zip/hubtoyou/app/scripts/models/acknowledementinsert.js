/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var AcknowledgementInsertModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        fetchData: function(dataInput) {
            this.fetch({
                data: JSON.stringify(dataInput),
                type: 'POST',
                success: function(collection, response, options) {
                    hideLoadingIndicator();
                    modalMsg(response.STATUS_MESSAGE, response.STATUS.toLowerCase());
                }
            });

        },
        fetchJson: function() {
            this.fetch({
                //url: 'scripts/stub/favourites.json',
                success: function(collection, response, options) {
                    //console.log(response);
                }
            });
        },
        parse: function(response, options) {
            return response;
        },

        url: config.urls[config.mode] + config.service["techAckInsertShipment"]
    });

    return AcknowledgementInsertModel;
});