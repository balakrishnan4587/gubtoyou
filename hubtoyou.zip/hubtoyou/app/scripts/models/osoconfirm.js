/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var OSOConfirmModel = Backbone.Model.extend({
        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        releaseBatchRequest: function(data) {
            showLoadingIndicator();
            this.fetch({
                type: 'POST',
                data: JSON.stringify(data),
                success: function(collection, response, options) {
                    hideLoadingIndicator();
                    modalMsg(response.OutputType[0].STATUS, "success");
                },
                error: function(collection, response, options) {
                    hideLoadingIndicator();
                    modalMsg(response.OutputType[0].STATUS, "error");
                }
            });
        },

        parse: function(response, options) {
            console.log(response);
            return response;
        },
        url: config.urls[config.mode] + config.service["releaseBatch"]
    });

    return OSOConfirmModel;
});