/*global define*/

define([
    'underscore',
    'backbone',
    'globalise'
], function(_, Backbone) {
    'use strict';

    var UserGrantedResModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        getUserGrantedResponsibility: function(dataInput, callback) {
            var me = this;
            this.fetch({
                type: 'POST',
                data: JSON.stringify(dataInput),
                success: function(collection, response, options) {
                    //modalMsg(response.STATUS_MESSAGE, "success");
                    if (callback) {
                        callback(response);
                    }
                },
                error: function(collection, response, options) {
                    //modalMsg(response.STATUS_MESSAGE, "error");
                }
            });

        },

        parse: function(response, options) {
            this.UserResponsibilityData = response;
            if (isOnline && offlineDB) {
                var user = getUsername();
                offlineDB.clearData("RESPONSIBILITIES", user);
                offlineDB.addData("RESPONSIBILITIES", user, response);
            }
            return response;
        },

        url: config.urls[config.mode] + config.service["adminuserresponsibility"]
    });

    return UserGrantedResModel;
});