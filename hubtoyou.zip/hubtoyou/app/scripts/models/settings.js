/*global define*/

define([
    'underscore',
    'backbone',
    'globalise'
], function(_, Backbone) {
    'use strict';

    var SettingsModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        fetchData: function() {
            //var userdata = JSON.parse(sessionStorage.getItem("_id"));
            var data = { "username": getUsername() };
            this.fetch({
                data: JSON.stringify(data),
                type: 'POST'
            });
        },

        fetchOfflineData: function() {
            var me = this;
            me.clear({ silent: true });
            var user = sessionStorage.getItem("offlineUser");
            offlineDB.getAllData("settings", user, function(items) {
                // items.forEach(function(item) {
                //     item.REQUISITION_NUMBER = item.REQUISITION_NUMBER + " *offline";
                // })
                //items[0].PreferencesSelectOutput[0].SUPERVISOR_EMAIL = "* Offline";
                me.set(items[0]);
                me.trigger('change', me);
            });
        },

        saveData: function(data) {
            this.fetch({
                url: config.urls[config.mode] + config.service["preferencesUpsert"],
                data: JSON.stringify(data),
                type: 'POST'
            });
        },

        parse: function(response, options) {
            if (typeof response.PreferencesSelectOutput !== "undefined") {
                sessionStorage.setItem("preferences", JSON.stringify(response.PreferencesSelectOutput[0]));
                var dateCount = (response.PreferencesSelectOutput[0].NEED_BY_DATE_TIME === null) ? 0 : response.PreferencesSelectOutput[0].NEED_BY_DATE_TIME;
                localStorage.setItem('offsetDate', dateCount);
                var date = new Date(); // Get current Date
                date.setDate(date.getDate() + dateCount);
                // date.setMonth(date.getMonth() + 1);
                // if (date.getDate() < 10) {
                //     date.getDate = "0" + date.getDate();
                // } else {
                //     date.getDate = date.getDate();
                // }
                // if (date.getMonth() < 10) {
                //     date.getMonth = "0" + (date.getMonth() + 1);
                // } else {
                //     date.getMonth = date.getMonth() + 1;
                // }                
                var needbyDate = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
                localStorage.setItem('needbyDate', needbyDate);
                if (isValid(response.PreferencesSelectOutput[0].DELIVERY_TO_LOCATION)) {
                    var region = response.PreferencesSelectOutput[0].DELIVERY_TO_LOCATION;
                    // if (isValid(region.split("-")[2])) {
                    //     localStorage.setItem('region_user', region.split("-")[2].trim());
                    // }
                    localStorage.setItem('region_user', region);
                } else {
                    localStorage.setItem('region_user', "");
                }

                if (isValid(response.PreferencesSelectOutput[0].ATTRIBUTE6)) {
                    localStorage.setItem('defaultBU', response.PreferencesSelectOutput[0].ATTRIBUTE6);
                } else {
                    localStorage.setItem('defaultBU', "");
                }

                if (isValid(response.PreferencesSelectOutput[0].ATTRIBUTE9)) {
                    localStorage.setItem('buNumber', response.PreferencesSelectOutput[0].ATTRIBUTE9);
                } else {
                    localStorage.setItem('buNumber', "");
                }

                if (isValid(response.PreferencesSelectOutput[0].PERSON_ID)) {
                    localStorage.setItem('personID', response.PreferencesSelectOutput[0].PERSON_ID);
                } else {
                    localStorage.setItem('personID', "");
                }
            } else if (response.STATUS == "ERROR") {
                hideLoadingIndicator();
                // window.location.href = "#error";
            } else {

                //window.location.href = "#error";
                return response;
                //window.location.href = "#settings";
            }

            return response;
        },
        url: config.urls[config.mode] + config.service["preferencesSelect"]
    });

    return SettingsModel;
});