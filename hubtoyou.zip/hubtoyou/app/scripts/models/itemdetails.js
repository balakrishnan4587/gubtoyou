/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var ItemDetailsModel = Backbone.Model.extend({
        initialize: function() {

        },
        defaults: {

        },

        validate: function(attrs, options) {},

        fetchData: function(id) {
            showLoadingIndicator();
            var data = {
                "Cifa_Item_Number": id
            };
            this.fetch({
                data: JSON.stringify(data),
                type: 'POST',
                success: function(collection, response, options) {},
                error: function() {
                    hideLoadingIndicator();
                    modalMsg("Unable to connect to the server. Please try again.", "error");
                }
            });
        },
        parse: function(response, options) {
            //console.log(response);
            this.responseData = response;
            return response;
        },
        url: config.urls[config.mode] + config.service["itemDetails"]
    });

    return ItemDetailsModel;
});