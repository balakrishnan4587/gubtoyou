/*global define*/

define([
  'underscore',
  'backbone'
], function (_, Backbone) {
  'use strict';

  var HomeModel = Backbone.Model.extend({

    initialize: function() {
    },

    defaults: {

    /* "itemNo":"",
     "qty":"",
     "uom":"",
     "region":"",
     "category":"",
     "template":"",
     "date":"",
     "desc":""  */
    },

    validate: function(attrs, options) {
    },

    parse: function(response, options)  {
      return response;
    }
  });

  return HomeModel;
});
