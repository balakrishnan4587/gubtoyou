
/*global define*/

define([
  'underscore',
  'backbone'
], function (_, Backbone) {
  'use strict';

  var NotificationModel = Backbone.Model.extend({
    initialize: function() {

    },
    defaults: {

    },

    validate: function(attrs, options) {
    },

    fetchData: function(){
        this.fetch({
            type:'GET'            
        });
    },

    parse: function(response, options)  {     
        //console.log(response);
      return response;
    },
   url:''
  });

  return NotificationModel;
});
