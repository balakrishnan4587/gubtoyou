/*global define*/

define([
    'underscore',
    'backbone',
], function(_, Backbone) {
    'use strict';

    var ClearCartModel = Backbone.Model.extend({
        initialize: function() {

        },
        defaults: {

        },

        validate: function(attrs, options) {},

        getHelpLink: function(data) {

            this.fetch({
                type: 'POST',
                data: JSON.stringify(data),
                success: function(collection, response, options) {


                },
                error: function(collection, response, options) {

                }
            });
        },

        parse: function(response, options) {
            this.responseData = response;
            return response;
        },
        url: config.urls[config.mode] + config.service["helpLink"]

    });

    return ClearCartModel;
});