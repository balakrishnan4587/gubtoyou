/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var WareHouseModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        fetchData: function(dataInput) {
            // var dataInput = {
            //   "ORGANIZATION_CODE" : data.orgCodeValue,
            // //  "LOCATION_DISPLAY" : data.orgCodeValue,
            //   "DESCRIPTION" : data.descValue,
            //   "LOCATION_CODE" : data.locCodeValue
            //   }
            this.fetch({ data: JSON.stringify(dataInput), type: 'POST' });

        },

        parse: function(response, options) {
            this.warehouseResponse = response;
            return response;
        },

        url: config.urls[config.mode] + config.service["getWarehouseDetails"]
    });

    return WareHouseModel;
});