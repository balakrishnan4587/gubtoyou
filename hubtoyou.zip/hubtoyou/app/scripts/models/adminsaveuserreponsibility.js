
/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var saveUserResponsibilityModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        saveUserResponsibility: function(dataInput) {
            var me = this;
            this.fetch({
                type: 'POST',
                data: JSON.stringify(dataInput),
                success: function(collection, response, options) {
                   //modalMsg(response.STATUS_MESSAGE, "success");
                },
                error: function(collection, response, options) {
                   //modalMsg(response.STATUS_MESSAGE, "error");
                }
            });

        },

        parse: function(response, options) {
            this.saveUserRespData = response;
            return response;
        },

        url: config.urls[config.mode] + config.service["adminsaveuserresponsibility"]
    });

    return saveUserResponsibilityModel;
});