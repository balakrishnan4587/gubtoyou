/*global define*/

define([
    'underscore',
    'backbone',
], function(_, Backbone) {
    'use strict';

    var Announcement = Backbone.Model.extend({
        initialize: function() {

        },
        defaults: {

        },

        validate: function(attrs, options) {},

        getAlertList: function(data, callback) {
            if (globalize.user == "normal") {
                this.fetch({
                    type: 'POST',
                    data: JSON.stringify(data),
                    url: config.urls[config.mode] + config.service["getAnnouncementsForUser"],
                    success: function(collection, response, options) {},
                    error: function(collection, response, options) {}
                });
            } else {
                this.fetch({
                    type: 'POST',
                    data: JSON.stringify(data),
                    url: config.urls[config.mode] + config.service["getAnnouncements"],
                    success: function(collection, response, options) {},
                    error: function(collection, response, options) {}
                });
            }

        },
        deleteAnnouncement: function(data, callback) {

            this.fetch({
                type: 'POST',
                data: JSON.stringify(data),
                url: config.urls[config.mode] + config.service["deleteAnnouncements"],
                success: function(collection, response, options) {},
                error: function(collection, response, options) {}
            });
        },

        parse: function(response, options) {
            this.responseData = response;
            //console.log(response);
            return response;
        }

    });

    return Announcement;
});