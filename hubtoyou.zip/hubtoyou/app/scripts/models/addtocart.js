/*global define*/

define([
    'underscore',
    'backbone',
    'models/shippingcartitemdetails',
], function(_, Backbone, CartItemModel) {
    'use strict';

    var AddToCartModel = Backbone.Model.extend({
        initialize: function() {

        },
        defaults: {

        },

        validate: function(attrs, options) {},

        addToCartRequest: function(data, callback) {

            this.fetch({
                type: 'POST',
                data: JSON.stringify(data),
                success: function(collection, response, options) {
                    hideLoadingIndicator();
                    modalMsg(response.STATUS_MESSAGE, response.STATUS.toLowerCase());
                    new CartItemModel().getCartItems();
                    //sessionStorage.setItem("cartItemsCount", Number(sessionStorage.getItem('cartItemsCount')) + 1);
                    //updateCartCount();
                    if (callback) {
                        callback(response.STATUS);
                    }
                },
                error: function(collection, response, options) {
                    hideLoadingIndicator();
                    modalMsg(response.STATUS_MESSAGE, "error");
                    if (callback) {
                        callback("fail");
                    }
                }
            });
        },

        parse: function(response, options) {
            this.responseData = response;
            //console.log(response);
            return response;
        },
        url: config.urls[config.mode] + config.service["upsertCartData"]
    });

    return AddToCartModel;
});