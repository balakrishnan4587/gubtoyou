/*global define*/

define([
    'underscore',
    'backbone',
], function(_, Backbone) {
    'use strict';

    var Announcement = Backbone.Model.extend({
        initialize: function() {

        },
        defaults: {

        },

        validate: function(attrs, options) {},

        insertAnnouncement: function(data, callback) {
            this.fetch({
                type: 'POST',
                data: JSON.stringify(data),
                success: function(collection, response, options) {},
                error: function(collection, response, options) {}
            });
        },
        revokeAnnouncement: function(data, callback) {

            this.fetch({
                type: 'POST',
                data: JSON.stringify(data),
                url: config.urls[config.mode] + config.service["revokeAnnouncements"],
                success: function(collection, response, options) {},
                error: function(collection, response, options) {}
            });
        },

        parse: function(response, options) {
            this.responseData = response;
            //console.log(response);
            return response;
        },
        url: config.urls[config.mode] + config.service["insertAnnouncements"]
    });

    return Announcement;
});