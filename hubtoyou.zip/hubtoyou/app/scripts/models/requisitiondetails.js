/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var RquisitionDetailsModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        fetchData: function(data) {
            var dataInput = { "requestor": getUsername(), "REQUISITION_NUMBER": data };
            this.fetch({ data: JSON.stringify(dataInput), type: 'POST' });
        },

        parse: function(response, options) {
            this.reDetailResponse = response;
            return response;
        },
        url: config.urls[config.mode] + config.service["requisitionLine"]
            // url: 'http://cifasoa-dt-a1d.ula.comcast.net:8301/soa-infra/resources/MobileApp/RequisitionHeaderLineProcess!1.0/RequisitionHeaderLineProcessRest/RequisitionLine'
    });

    return RquisitionDetailsModel;
});