/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var AcknowledgementDetailsModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        fetchData: function(dataInput) {
            this.fetch({
                data: JSON.stringify(dataInput),
                type: 'POST',
                success: function() {

                },
                error: function() {

                }
            });
        },
        fetchJson: function() {
            this.fetch({
                //url: 'scripts/stub/favourites.json',
                success: function() {
                    //console.log('success');
                    hideLoadingIndicator();
                },
                error: function() {
                    hideLoadingIndicator();
                }
            });
        },
        parse: function(response, options) {
            this.recDetailResponse = response;
            return response;
        },

        url: config.urls[config.mode] + config.service["techAckGetShipment"]
    });

    return AcknowledgementDetailsModel;
});