/*global define*/

define([
  'underscore',
  'backbone'
], function (_, Backbone) {
  'use strict';

  var LoginModel = Backbone.Model.extend({
    url: '',

    initialize: function() {
    },

    defaults: {
      userName:''
    },

    validate: function(attrs, options) {
    },

    parse: function(response, options)  {
      return response;
    }
  });

  return LoginModel;
});
