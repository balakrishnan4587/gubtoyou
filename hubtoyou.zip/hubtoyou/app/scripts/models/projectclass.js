/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var SettingsModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        fetchData: function() {
            this.fetch({ type: 'POST' });

        },
        // fetch:function(options){
        //   var dataInput = {"username": "MUPADH200"};
        //   var options = {
        //     data: JSON.stringify(dataInput),
        //       type: 'POST',
        //       success:function(data){
        //         //layout.renderChild(new SettingsView(),model);
        //       },
        //       error:function(){
        //         alert('service failure');
        //       }
        //   }

        //},

        parse: function(response, options) {

            return response;
        },
        url: config.urls[config.mode] + config.service["getProjectClass"]
    });

    return SettingsModel;
});