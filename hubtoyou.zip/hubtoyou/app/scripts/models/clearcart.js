/*global define*/

define([
    'underscore',
    'backbone',
], function(_, Backbone) {
    'use strict';

    var ClearCartModel = Backbone.Model.extend({
        initialize: function() {

        },
        defaults: {

        },

        validate: function(attrs, options) {},

        clearCartRequest: function(data, callback) {

            this.fetch({
                type: 'POST',
                data: JSON.stringify(data),
                success: function(collection, response, options) {
                    if (callback) {
                        callback();
                    }
                },
                error: function(collection, response, options) {

                }
            });
        },

        parse: function(response, options) {
            this.responseData = response;
            return response;
        },
        url: config.urls[config.mode] + config.service["clearCart"]

    });

    return ClearCartModel;
});