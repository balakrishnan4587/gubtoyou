/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var InventoryModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        fetchData: function(dataInput) {
            // var dataInput = {
            //   "ORGANIZATION_CODE" : data.orgCodeValue,
            //   "SUBINVENTORY_NAME" : data.subInventoryValue
            //   }
            this.fetch({ data: JSON.stringify(dataInput), type: 'POST' });

        },

        parse: function(response, options) {
            this.inventoryResponse = response;
            return response;
        },

        url: config.urls[config.mode] + config.service["getSubInventoryDetails"]
    });

    return InventoryModel;
});