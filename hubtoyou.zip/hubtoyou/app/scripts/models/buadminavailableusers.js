/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var AdminAvailableUserModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        fetchAvailableUsers: function(dataInput) {

            var me = this;
            this.fetch({
                type: 'POST',
                data: JSON.stringify(dataInput),
                //url: 'scripts/stub/favourites.json',
                success: function(collection, response, options) {
                    // me.trigger('change');
                },
                error: function(collection, response, options) {

                }
            });

        },
        addToSelectedUsers: function(dataInput) {
            this.fetch({
                type: 'POST',
                data: JSON.stringify(dataInput),
                url: config.urls[config.mode] + config.service["insertUsersToSelected"],
                //url: 'http://cifasoadev.ula.comcast.net:5301/BUAdministration/BUAdministrationPS/InsertUsersDetails',
                success: function(collection, response, options) {
                    // me.trigger('change');
                },
                error: function(collection, response, options) {

                }
            });
        },
        parse: function(response, options) {
            this.responseAvailableData = response;
            return response;
        },
        //url: 'http://cifasoadev.ula.comcast.net:5301/BUAdministration/BUAdministrationPS/GetOthersUsersList'
        url: config.urls[config.mode] + config.service["buadminavailableusers"]
    });

    return AdminAvailableUserModel;
});