/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var AdminAvailableRegionsModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        fetchAvailableTypes: function(dataInput) {

            var me = this;
            this.fetch({
                type: 'POST',
                data: JSON.stringify(dataInput),
                success: function(collection, response, options) {
                    // me.trigger('change');
                },
                error: function(collection, response, options) {

                }
            });

        },

        parse: function(response, options) {
            this.responseAvailableData = response;
            return response;
        },

        url: config.urls[config.mode] + config.service["messageTypes"]
    });

    return AdminAvailableRegionsModel;
});