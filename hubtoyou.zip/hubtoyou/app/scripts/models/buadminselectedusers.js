/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var AdminAvailableUserModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        fetchAvailableUsers: function(dataInput) {

            var me = this;
            this.fetch({
                type: 'POST',
                data: JSON.stringify(dataInput),
                //url: 'scripts/stub/buselectedusers.json',
                success: function(collection, response, options) {
                    // me.trigger('change');
                },
                error: function(collection, response, options) {

                }
            });

        },
        deleteSelectedUser: function(dataInput) {
            this.fetch({
                type: 'POST',
                data: JSON.stringify(dataInput),
                url: config.urls[config.mode] + config.service["deleteSelectedUser"],
                //url: 'http://cifasoadev.ula.comcast.net:5301/BUAdministration/BUAdministrationPS/DeleteUsersList',
                success: function(collection, response, options) {
                    // me.trigger('change');
                },
                error: function(collection, response, options) {

                }
            });
        },
        parse: function(response, options) {
            this.responseAvailableData = response;
            return response;
        },
        url: config.urls[config.mode] + config.service["buadminselectedusers"]
    });

    return AdminAvailableUserModel;
});