/*global define*/

define([
    'jquery',
    'underscore',
    'backbone'
], function($, _, Backbone) {
    'use strict';

    var ShippingCartItemDetailsModel = Backbone.Model.extend({
        initialize: function() {

        },
        defaults: {

        },

        validate: function(attrs, options) {},

        fetchOfflineData: function() {
            var me = this;
            me.clear({ silent: true });
            var user = sessionStorage.getItem("offlineUser");
            offlineDB.getAllData("CART", user, function(items) {
                // items.forEach(function(item) {
                //     item.REQUISITION_NUMBER = item.REQUISITION_NUMBER + " *offline";
                // })
                //items[0].PreferencesSelectOutput[0].SUPERVISOR_EMAIL = "* Offline";
                me.responseData = {
                    ShoppingCartDetails: items
                }
                me.set(me.responseData);
                //me.trigger('change', me);
            });
        },

        getCartItems: function() {
            var dataInput = { "USER_NAME": getUsername() };
            $('#spinner_canvas').fadeIn({
                duration: 100
            });
            $('body').addClass('masked');
            this.fetch({
                type: 'POST',
                data: JSON.stringify(dataInput),
                url: config.urls[config.mode] + config.service["selectCartDetails"],
                success: function(collection, response, options) {
                    (typeof response.ShoppingCartDetails == "undefined") ? sessionStorage.setItem("cartItemsCount", 0): sessionStorage.setItem("cartItemsCount", response.ShoppingCartDetails.length);
                    updateCartCount();
                },
                error: function(collection, response, options) {
                    modalMsg(response.STATUS_MESSAGE, "error");
                }
            });
        },

        deleteCartItem: function(dataInput) {
            this.fetch({
                type: 'POST',
                data: JSON.stringify(dataInput),
                reset: true,
                url: config.urls[config.mode] + config.service["deleteCartEntry"],
                success: function(collection, response, options) {

                },
                error: function(collection, response, options) {
                    modalMsg(response.STATUS_MESSAGE, "error");
                }
            });
        },

        deleteAllItems: function() {
            this.fetch({
                type: 'POST',
                data: JSON.stringify(dataInput),
                reset: true,
                url: config.urls[config.mode] + config.service["deleteAllCartEntry"],
                success: function(collection, response, options) {

                },
                error: function(collection, response, options) {
                    modalMsg(response.STATUS_MESSAGE, "error");
                }
            });
        },

        parse: function(response, options) {
            this.responseData = response;
            //console.log(response);
            return response;
        },
        url: config.urls[config.mode] + config.service["selectCartDetails"]
    });

    return ShippingCartItemDetailsModel;
});