
/*global define*/

define([
  'underscore',
  'backbone'
], function (_, Backbone) {
  'use strict';

  var PreviewImageModel = Backbone.Model.extend({
    initialize: function() {

    },
    defaults: {

    },

    validate: function(attrs, options) {
    },

    fetchData: function(data, callback){
        this.fetch({
            type:'POST',
            data: JSON.stringify(data),
            success: function(collection, response, options) {                
               
            },
            error: function(collection, response, options) {
                //modalMsg(response.STATUS_MESSAGE, "error");
                //console.log("error..."+response.STATUS_MESSAGE);
            }
        });
    },

    parse: function(response, options)  {
        this.responseData = response;  
        //console.log(response);
      return response;
    },
   url:config.urls[config.mode] + config.service["previewImage"]
  });

  return PreviewImageModel;
});
