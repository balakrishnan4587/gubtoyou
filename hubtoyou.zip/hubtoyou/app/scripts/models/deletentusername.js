




/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var DeleteNTUserNameModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        deleteNTUserName: function(dataInput) {
            var me = this;
            this.fetch({
                type: 'POST',
                data: JSON.stringify(dataInput),
                success: function(collection, response, options) {
                   modalMsg(response.STATUS_MESSAGE, "success");
                },
                error: function(collection, response, options) {
                   modalMsg(response.STATUS_MESSAGE, "error");
                }
            });

        },

        parse: function(response, options) {
            this.deleteNTUserData = response;
            return response;
        },

        url: config.urls[config.mode] + config.service["adminDelNTUsername"]
    });

    return DeleteNTUserNameModel;
});