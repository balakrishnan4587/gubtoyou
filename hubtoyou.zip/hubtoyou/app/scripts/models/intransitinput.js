
/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var InTransitModel = Backbone.Model.extend({
        initialize: function() {

        },
        defaults: {

        },

        validate: function(attrs, options) {},

        inTransitRequest: function(data) {
            this.fetch({
                type: 'POST',
                data: JSON.stringify(data),
                success: function(collection, response, options) {
                    //modalMsg(response.STATUS_MESSAGE, response.STATUS.toLowerCase());
                },
                error: function(collection, response, options) {
                    modalMsg(response.STATUS_MESSAGE, "error");
                }
            });
        },

        parse: function(response, options) {
            this.responseData = response;
            console.log(response);
            return response;
        },
        url: config.urls[config.mode] + config.service["inTransit"]
    });

    return InTransitModel;
});