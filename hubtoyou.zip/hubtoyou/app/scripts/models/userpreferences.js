/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var SettingsModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        fetchData: function(data) {
            //var userdata = JSON.parse(sessionStorage.getItem("_id"));
            var data = { "username": data };
            this.fetch({
                data: JSON.stringify(data),
                type: 'POST'
            });
        },

        fetchUserName: function(data) {
            var data = { "USER_NAME": data };
            this.fetch({
                data: JSON.stringify(data),
                //url: config.urls[config.mode] + config.service["preferencesUpsert"],
                url: 'http://cifasoadev.ula.comcast.net:5301/HUB2UAdminModule/HUB2UAdminModulePS/FetchUserDetails',
                type: 'POST'
            });
        },

        fetchOfflineData: function() {
            var me = this;
            me.clear({ silent: true });
            var user = sessionStorage.getItem("offlineUser");
            offlineDB.getAllData("settings", user, function(items) {
                // items.forEach(function(item) {
                //     item.REQUISITION_NUMBER = item.REQUISITION_NUMBER + " *offline";
                // })
                //items[0].PreferencesSelectOutput[0].SUPERVISOR_EMAIL = "* Offline";
                me.set(items[0]);
                me.trigger('change', me);
            });
        },

        saveData: function(data) {
            this.fetch({
                url: config.urls[config.mode] + config.service["preferencesUpsert"],
                data: JSON.stringify(data),
                type: 'POST'
            });
        },

        parse: function(response, options) {
            this.userPrefResponse = response;
            return response;
        },
        url: config.urls[config.mode] + config.service["preferencesSelect"]
    });

    return SettingsModel;
});