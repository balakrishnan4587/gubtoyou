/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone, HomeModel, HomeView) {
    'use strict';

    var ReportModel = Backbone.Model.extend({

        fetchOfflineData: function() {
            var me = this;
            var user = sessionStorage.getItem("offlineUser");
            offlineDB.getAllData("requisitions", user, function(items) {
                items.forEach(function(item) {
                    item.REQUISITION_NUMBER = item.REQUISITION_NUMBER + " *offline";
                })
                me.reset(items);
            });
        },
        fetchData: function(data) {
            var that = this;
            var dataInput = {
                "requestor": getUsername(),
                "REQUISITION_NUMBER": data.reqNo,
                "REQ_HEADER_DESCRIPTION": data.desc,
                "STATUS": data.status,
                "START_DATE": data.sd,
                "END_DATE": data.ed,
                "ISO_ORDER_NUMBER": data.iso
            };
            this.fetch({
                data: JSON.stringify(dataInput),
                type: 'POST',
                success: function(collection, response, options) {},
                error: function() {
                    //alert('service failure');
                }
            });
        },
        parse: function(response) {
            this.reportResponse = response.ReportOutput;
            return response;
        },
        //url:'http://cifasoa-dt-a1d.ula.comcast.net:8301/soa-infra/resources/MobileApp/TechnicianFavorite!1.0/TechnicianFavoriteRest/GetFavorite'
        url: config.urls[config.mode] + config.service["getReport"]

    });

    return ReportModel;
});