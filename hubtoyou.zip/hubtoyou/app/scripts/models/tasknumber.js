/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var TaskNumberModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        fetchData: function(dataInput) {

            this.fetch({ data: JSON.stringify(dataInput), type: 'POST' });

        },

        parse: function(response, options) {
            this.tasknumberResponse = response;
            return response;
        },

        url: config.urls[config.mode] + config.service["getTaskNumber"]
    });

    return TaskNumberModel;
});