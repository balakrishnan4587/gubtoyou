/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var ExpenditureModel = Backbone.Model.extend({


        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        fetchData: function(dataInput) {

            this.fetch({ data: JSON.stringify(dataInput), type: 'POST' });

        },

        parse: function(response, options) {
            this.expenditureTypeResponse = response;
            return response;
        },

        url: config.urls[config.mode] + config.service["expenditureType"]
    });

    return ExpenditureModel;
});