/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var FavoritesModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {
            "REQUESTOR_USER_NAME": ""
        },

        validate: function(attrs, options) {},
        // getCustomUrl: function(method) {
        //     switch (method) {
        //         case 'create':
        //             return config.urls[config.mode] + config.service["insertFavorite"];
        //             // case 'delete':
        //             //     return 'http://localhost:51377/api/Books/' + this.id;
        //             //     break;
        //     }
        // },
        // sync: function(method, model, options) {
        //     options || (options = {});
        //     options.url = this.getCustomUrl(method.toLowerCase());

        //     // Lets notify backbone to use our URLs and do follow default course
        //     return Backbone.sync.apply(this, arguments);
        // },
        insertFavorite: function(data) {
            showLoadingIndicator();
            this.fetch({
                url: config.urls[config.mode] + config.service["insertFavorite"],
                data: JSON.stringify(data),
                type: 'POST',
                success: function(model, response, options) {
                    modalMsg(response.InsertFavoriteOutput.STATUS_MESSAGE, response.InsertFavoriteOutput.STATUS.toLowerCase());
                    hideLoadingIndicator();
                    //$('#' + globalize.temp.selectedRecord).next().html('Item added to favorites');
                    //console.log("The model has been saved to the server");
                },
                error: function(model, xhr, options) {
                    modalMsg(response.InsertFavoriteOutput.STATUS_MESSAGE, "error");
                    hideLoadingIndicator();
                    //console.log("Something went wrong while saving the model");
                }
            });
            //this.save(null, options);
        },
        parse: function(response, options) {
            return response;
        }

    });

    return FavoritesModel;
});