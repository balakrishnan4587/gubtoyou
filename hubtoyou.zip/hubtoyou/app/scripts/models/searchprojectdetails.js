/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var SettingsModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        fetchData: function(dataInput) {
            // var dataInput = {
            //   "ProjectNumber" : data.projectNo,
            //   "ProjectName" : data.projectName,
            //   "ProjectDescription" : data.descCodeValue,
            //   "ProjectType" : data.type,
            //   "ProjectClassCode" : data.projectType,
            //   "ProjectStatusName" :data.status,
            //   "BusinessUnit" : data.bu
            //   }
            this.fetch({ data: JSON.stringify(dataInput), reset: true, type: 'POST' });

        },

        parse: function(response, options) {
            this.detailsResponse = response;
            return response;
        },

        url: config.urls[config.mode] + config.service["getProjectsDetails"]
    });

    return SettingsModel;
});