/*global define*/

define([
    'underscore',
    'backbone',
], function(_, Backbone) {
    'use strict';

    var CheckoutModel = Backbone.Model.extend({
        initialize: function() {

        },
        defaults: {

        },

        validate: function(attrs, options) {},

        checkoutRequest: function(data) {

            this.fetch({
                type: 'POST',
                data: JSON.stringify(data),
                success: function(collection, response, options) {

                },
                error: function(collection, response, options) {
                    modalMsg(response.STATUS_MESSAGE, "error");
                }
            });
        },

        parse: function(response, options) {
            this.responseData = response;
            return response;
        },
        url: config.urls[config.mode] + config.service["checkout"]
            //url: 'http://cifasoadev.ula.comcast.net:5301/CheckOutService/CheckOutServicePS/ProcessCheckOut'
    });

    return CheckoutModel;
});