/*global define*/

define([
    'underscore',
    'backbone',
    'models/shippingcartitemdetails',
], function(_, Backbone, CartItemModel) {
    'use strict';

    var AddToCartModel = Backbone.Model.extend({
        initialize: function() {

        },
        defaults: {

        },

        validate: function(attrs, options) {},

        addToCartRequest: function(data) {
            this.fetch({
                type: 'POST',
                data: JSON.stringify(data),
                success: function(collection, response, options) {

                },
                error: function(collection, response, options) {
                    modalMsg(response.STATUS_MESSAGE, "error");
                }
            });
        },

        parse: function(response, options) {
            this.responseData = response;
            //console.log(response);
            return response;
        },
        url: config.urls[config.mode] + config.service["requisitionAddToCart"]
    });

    return AddToCartModel;
});