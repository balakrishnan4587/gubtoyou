/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var SettingsModel = Backbone.Model.extend({


        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        fetchData: function() {
            this.fetch({ type: 'POST' });

        },

        parse: function(response, options) {

            return response;
        },
        url: config.urls[config.mode] + config.service["getProjectType"]
    });

    return SettingsModel;
});