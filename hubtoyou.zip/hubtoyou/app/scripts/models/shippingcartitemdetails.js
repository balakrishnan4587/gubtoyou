/*global define*/

define([
    'jquery',
    'underscore',
    'backbone',
    'globalise'
], function($, _, Backbone) {
    'use strict';

    var ShippingCartItemDetailsModel = Backbone.Model.extend({
        initialize: function() {

        },
        defaults: {

        },

        validate: function(attrs, options) {},

        getCartItems: function() {
            var data = { "USER_NAME": getUsername() };
            this.fetch({
                type: 'POST',
                data: JSON.stringify(data),
                url: config.urls[config.mode] + config.service["cartItemCount"],
                success: function(collection, response, options) {
                    (typeof response.RECORD_COUNT == "undefined") ? sessionStorage.setItem("cartItemsCount", 0): sessionStorage.setItem("cartItemsCount", response.RECORD_COUNT);
                    updateCartCount();
                },
                error: function(collection, response, options) {
                    modalMsg(response.STATUS_MESSAGE, "error");
                }
            });
        },

        parse: function(response, options) {
            this.responseData = response;
            //console.log(response);
            return response;
        },
        url: config.urls[config.mode] + config.service["selectCartDetails"]
    });

    return ShippingCartItemDetailsModel;
});