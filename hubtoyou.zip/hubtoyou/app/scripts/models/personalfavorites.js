/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var FavoritesModel = Backbone.Model.extend({

        initialize: function() {},

        // defaults: {
        //  "REQUESTOR_USER_NAME":""
        // },

        validate: function(attrs, options) {},
        getCustomUrl: function(method) {
            switch (method) {
                case 'create':
                    return config.urls[config.mode] + config.service["insertFavorite"];
                case 'read':
                    return config.urls[config.mode] + config.service["deleteFavorite"];
            }
        },
        sync: function(method, model, options) {
            options || (options = {});
            options.url = this.getCustomUrl(method.toLowerCase());

            // Lets notify backbone to use our URLs and do follow default course
            return Backbone.sync.apply(this, arguments);
        },
        deleteFavorite: function(options) {
            this.fetch(null, options);
        },
        parse: function(response, options) {
            return response;
        }

    });

    return FavoritesModel;
});