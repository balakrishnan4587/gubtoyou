/*global define*/

define([
    'underscore',
    'backbone',
    'globalise'
], function(_, Backbone) {
    'use strict';

    var ProfileDetailsModel = Backbone.Model.extend({

        initialize: function() {},

        defaults: {},

        validate: function(attrs, options) {},

        fetchData: function(data, callback) {
            this.fetch({
                type: 'POST',
                data: JSON.stringify(data),
                success: function(collection, response, options) {
                    if (response.STATUS.toLowerCase() === "success") {
                        if (response.IMAGE_BINARY != null) {
                            var imageurl = "data:image/jpeg;base64," + response.IMAGE_BINARY;
                            sessionStorage.setItem(getUsername() + "profileImage", imageurl);
                            var profileImage = sessionStorage.getItem(getUsername() + "profileImage");
                            if (profileImage !== null) {
                                if (profileImage !== "") {
                                    $(".profile-image-mob").css('background', 'url(' + profileImage + ') no-repeat center');
                                    $("#desk-user-icon").css('background', 'url(' + profileImage + ') no-repeat center').addClass("small-profile-image");
                                }
                            }
                        } else {
                            sessionStorage.setItem(getUsername() + "profileImage", "");
                        }
                    } else {
                        //console.log("Failed to fetch profile details");
                    }
                },
                error: function(collection, response, options) {

                }
            });
        },

        parse: function(response, options) {
            return response;
        },
        url: config.urls[config.mode] + config.service["getProfileDetails"]

    });

    return ProfileDetailsModel;
});