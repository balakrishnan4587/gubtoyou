/* Offline storage specific code */
var isOnline = true;

var offlineDB = {

    db: null,

    initDB: function() {
        try {
            if (!window.openDatabase) {
                console.log('Databases are not supported in this browser.');
            } else {
                this.db = openDatabase('offlinedb', '1.0', 'Offline DB', 2 * 1024 * 1024);

                this.db.transaction(function(tx) {
                    tx.executeSql('CREATE TABLE IF NOT EXISTS LOGS (id INTEGER PRIMARY KEY AUTOINCREMENT, log)');
                    tx.executeSql('CREATE TABLE IF NOT EXISTS REQUISITIONS (id INTEGER PRIMARY KEY AUTOINCREMENT, username, data)');
                    tx.executeSql('CREATE TABLE IF NOT EXISTS FAVORITES (id INTEGER PRIMARY KEY AUTOINCREMENT, username, data)');
                    tx.executeSql('CREATE TABLE IF NOT EXISTS SETTINGS (id INTEGER PRIMARY KEY AUTOINCREMENT, username, data)');
                    tx.executeSql('CREATE TABLE IF NOT EXISTS CART (id INTEGER PRIMARY KEY AUTOINCREMENT, username, data)');
                    tx.executeSql('CREATE TABLE IF NOT EXISTS CARTOFFLINE (id INTEGER PRIMARY KEY AUTOINCREMENT, username, data)');
                    tx.executeSql('CREATE TABLE IF NOT EXISTS RESPONSIBILITIES (id INTEGER PRIMARY KEY AUTOINCREMENT, username, data)');
                    tx.executeSql('CREATE TABLE IF NOT EXISTS PROFILE (id INTEGER PRIMARY KEY AUTOINCREMENT, username, data)');
                    tx.executeSql('CREATE TABLE IF NOT EXISTS CARTLOGS (id INTEGER PRIMARY KEY AUTOINCREMENT, username, data)');
                });
                console.log("Offline DB initialized");
                return;
            }
        } catch (e) {
            if (e == 2) {
                // Version number mismatch.
                console.log("Invalid database version.");
            } else {
                console.log("Unknown error " + e + ".");
            }
            return;
        }
    },

    addData: function(table, user, data) {
        if (this.db) {
            this.db.transaction(
                function(tx) {
                    tx.executeSql('INSERT INTO ' + table + ' (username, data) VALUES (?, ?)', [user.toLowerCase(), JSON.stringify(data)]);
                },
                function(error) {
                    console.log("Transaction Error: " + error.message);
                },
                function() {
                    //console.log("Transaction Success");
                });
        }
    },

    clearData: function(table, user) {
        if (this.db) {
            this.db.transaction(
                function(tx) {
                    tx.executeSql('DELETE FROM ' + table + ' where username = ?', [user]);
                }
            );
        }
    },

    getAllData: function(table, user, callBack) {
        if (this.db) {
            var result = [];
            this.db.transaction(function(tx) {
                tx.executeSql('SELECT * from ' + table + ' where username = ?', [user], function(tx, rs) {
                    for (var i = 0; i < rs.rows.length; i++) {
                        var row = rs.rows.item(i);
                        result[i] = JSON.parse(row['data']);
                    }
                    callBack(result);
                }, function(error) {
                    //console.log(error);
                });
            });
        }
    },


    getOfflineCartCount: function(user, callback) {
        if (this.db) {
            var count = 0;
            this.db.transaction(function(tx) {
                tx.executeSql('SELECT * from CARTOFFLINE where username = ?', [user], function(tx, results) {
                    count = results.rows.length;
                    callback(count);
                });
            });
        }
    },

    syncOfflineCart: function(user, callback, view) {
        if (this.db) {
            var result = [];
            this.db.transaction(function(tx) {
                tx.executeSql('SELECT * from CARTOFFLINE where username = ?', [user], function(tx, rs) {
                    for (var i = 0; i < rs.rows.length; i++) {
                        result[i] = JSON.parse(rs.rows[i].data);
                    }
                    callback(result, view);
                });
            });
        }
    }
};