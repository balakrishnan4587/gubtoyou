var AppView = {
        currentView: null,
        setCurrentView: function(view) {
            if (this.currentView) {
                if (this.currentView.childView) {
                    this.currentView.childView.close();
                }
                this.currentView.close();
            }
            /*to kill the parent views/Top most view */
            if (globalPreviousView !== undefined) {
                globalPreviousView.close();
            }
            /*ends */
            this.currentView = view;
        }
    }
    // Opera 8.0+
var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;
// Firefox 1.0+
var isFirefox = typeof InstallTrigger !== 'undefined';
// At least Safari 3+: "[object HTMLElementConstructor]"
var isSafari = Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0;
// Internet Explorer 6-11
var isIE = /*@cc_on!@*/ false || !!document.documentMode;
// Edge 20+
var isEdge = !isIE && !!window.StyleMedia;
// Chrome 1+
var isChrome = !!window.chrome && !!window.chrome.webstore;
// Blink engine detection
var isBlink = (isChrome || isOpera) && !!window.CSS;





var config = {

    "mode": "local",//getBaseUrlMode(),


    "urls": {
        "local": "http://cifasoatest.ula.comcast.net:5101/",
        "dev": "http://cifasoadev.ula.comcast.net:5301/", //HTTP URL
        "dev-https": "https://cifasoadev.ula.comcast.net:5302/", //HTTPS URL
        "test": "https://cifasoatest.ula.comcast.net:5102/",
        "uat": "http://cifaintstg.cable.comcast.com:5302/",
        "uat-https": "https://cifaintstg.cable.comcast.com:5102/",
        "cloud": "https://cifasoadev.ula.comcast.net:5302/",

        "production": "https://cifasoaprd.cable.comcast.com:5102/"
    },

    "service": {
        "getFavorites": "TechnicianFavorite/TechnicianFavoritePS/GetFavorite",
        "getRegionalFavorites": "RegionFavListProcess/RegionFavListProcessPS/RegionFavList",
        "insertFavorite": "TechnicianFavorite/TechnicianFavoritePS/InsertFavorite",
        "deleteFavorite": "TechnicianFavorite/TechnicianFavoritePS/DeleteFavorite",
        "regionList": "RegionList/RegionListPS/RegionList",
        "templateList": "TemplateList/TemplateListPS/TemplateList",
        "itemDetails": "ItemDetails/ItemDetailsPS/ItemDetails",
        "requisitionHeader": "RequistionHeaderLineProcess/RequistionHeaderLineProcessPS/RequisitionHeader",
        "itemInquiry": "OnHandInquiry/OnHandInquiryPS/ItemInquiry",
        /* Acknowledgement */
        "techAckGetShipment": "ComcastTechnicianAcknowledgement/ComcastTechnicianAcknowledgementPS/ComcastTechnicianAcknowledgementGetShipmentRest",
        "techAckInsertShipment": "ComcastTechnicianAcknowledgement/ComcastTechnicianAcknowledgementPS/ComcastTechnicianAcknowledgementInsertShipmentRest",


        "upsertCartData": "ComcastShoppingCartSvc/ComcastShoppingCartSvcPS/UpsertCartData",
        "expenditureType": "ExpenditureType/ExpenditureTypePS/ExpenditureType",
        "requisitionInsertFeedback": "ComcastTechinicianRequisitionFeedback/ComcastTechinicianRequisitionFeedbackPS/ComcastTechnicianRequisitionInsertFeedback",
        "inTransit": "InTransit/InTransitPS/InTransit",
        "getProjectClass": "ProjectsDetails/ProjectsDetailsPS/GetProjectsClass",
        "getProjectStatus": "ProjectsDetails/ProjectsDetailsPS/GetProjectsStatus",
        "getProjectType": "ProjectsDetails/ProjectsDetailsPS/GetProjectsType",
        "requisitionAddToCart": "ComcastRequisitionToShoppingCart/ComcastRequisitionToShoppingCartPS/ComcastRequisitionToShoppingCart",
        "requisitionLine": "RequistionHeaderLineProcess/RequistionHeaderLineProcessPS/RequisitionLine",
        "getSubInventoryDetails": "SubInventory/SubInventoryPS/GetSubInventoryDetails",
        "getProjectsDetails": "ProjectsDetails/ProjectsDetailsPS/GetProjectsDetails",
        "getWarehouseDetails": "WareHouseAndLocation/WareHouseAndLocationPS/GetDetails",
        "preferencesUpsert": "PreferencesProcess/PreferencesProcessPS/PreferencesUpsert",
        "selectCartDetails": "ComcastShoppingCartSvc/ComcastShoppingCartSvcPS/SelectCartDetails",
        "deleteCartEntry": "ComcastShoppingCartSvc/ComcastShoppingCartSvcPS/DeleteCartEntry",
        "deleteAllCartEntry": "ComcastShoppingCartSvc/ComcastShoppingCartSvcPS/ClearCart",
        "getTaskNumber": "TaskDetails/TaskDetailsPS/FetchData",
        "preferencesSelect": "PreferencesProcess/PreferencesProcessPS/PreferencesSelect",
        "cartItemCount": "ComcastShoppingCartSvc/ComcastShoppingCartSvcPS/GetCartCount",
        "getFeedback": "ComcastTechinicianRequisitionFeedback/ComcastTechinicianRequisitionFeedbackPS/ComcastTechnicianRequisitionGetFeedback",
        "getReport": "RequistionHeaderLineProcess/RequistionHeaderLineProcessPS/GetReport",
        "checkout": "CheckOutService/CheckOutServicePS/ProcessCheckOut",
        "clearCart": "ComcastShoppingCartSvc/ComcastShoppingCartSvcPS/ClearCart",
        "previewImage": "CatalogImage/CatalogImagePS/GetPreviewImage",
        "uploadImages": "CatalogImage/CatalogImagePS/UploadImages",
        /* OUTSTANDING SALES */
        "selectReserve": "Hub2uSalesOrderDetails/Hub2uSalesOrderDetailsPS/SelectReserve",
        "selectUnreserve": "Hub2uSalesOrderDetails/Hub2uSalesOrderDetailsPS/SelectUnReserve",
        "reserveQuantity": "Hub2uSalesOrderDetails/Hub2uSalesOrderDetailsPS/SelectReserveQuantity",
        "releaseBatch": "Hub2uSalesOrderDetails/Hub2uSalesOrderDetailsPS/SelectReleaseBatch",
        "uploadImages": "CatalogImage/CatalogImagePS/UploadImages",

        /* PROFILE IMAGE */
        "getProfileDetails": "ProfileDetails/ProfileDetailsPS/GetProfilePicture",
        /****/
        "responsibilityChoiceList": "HUB2UAdminModule/HUB2UAdminModulePS/RespChoiceList",
        "responsibilityEnabledUsers": "HUB2UAdminModule/HUB2UAdminModulePS/RespEnabled",
        "adminNTUsernameSearch": "HUB2UAdminModule/HUB2UAdminModulePS/FetchUserDetails",
        "adminAddNTUsername": "HUB2UAdminModule/HUB2UAdminModulePS/AddUserFromRespo",
        "adminDelNTUsername": "HUB2UAdminModule/HUB2UAdminModulePS/RemoveUserFromRespo",
        "adminuserresponsibility": "HUB2UAdminModule/HUB2UAdminModulePS/FetchUserResp",
        "adminsaveuserresponsibility": "HUB2UAdminModule/HUB2UAdminModulePS/AddUpdateUserResp",
        "adminaddregion": "HUB2UAdminModule/HUB2UAdminModulePS/AddRegFromResponsibility",
        "admindeleteregion": "HUB2UAdminModule/HUB2UAdminModulePS/RemoveRegResp",
        "adminavailselectedregions": "HUB2UAdminModule/HUB2UAdminModulePS/RegUsingResp",
        "buadminavailableusers": "BUAdministration/BUAdministrationPS/GetOthersUsersList",
        "buadminselectedusers": "BUAdministration/BUAdministrationPS/GetSelectedUsersList",
        "readonlyusers": "BUAdministration/BUAdministrationPS/GetReadOnlyUsersList",
        "deleteSelectedUser": "BUAdministration/BUAdministrationPS/DeleteUsersList",
        "insertUsersToSelected": "BUAdministration/BUAdministrationPS/InsertUsersDetails",
        "getAnnouncements": "AnnouncementDetails/AnnouncementDetailsPS/GetAnnouncementsForAdminList",
        "getAnnouncementsForUser": "AnnouncementDetails/AnnouncementDetailsPS/GetAnnouncementsForUserList",
        "deleteAnnouncements": "AnnouncementDetails/AnnouncementDetailsPS/DeleteAnnouncements",
        "insertAnnouncements": "AnnouncementDetails/AnnouncementDetailsPS/SaveAnnouncements",
        "revokeAnnouncements": "AnnouncementDetails/AnnouncementDetailsPS/RevokeAnnouncements",
        "acknowldgeAnnouncements": "AnnouncementDetails/AnnouncementDetailsPS/AcknowledgeAnnouncements",
        "messageTypes": "AnnouncementDetails/AnnouncementDetailsPS/AnnouncementsType",
        /*HelpLink */
        "helpLink": "UPKDocumentLink/UPKDocumentLinkPS/UPKDocumentDetails"
    }
}

var USER_FUNCTIONS = [];


var globalize = {
    /* user params */
    "user_id": "",
    /////////////////

    "uom": "UOM:",
    "quantity": "Quantity:",
    "region": "Region:",
    "cifaItem": "CIFA Item:",
    "_cifaItem": "CIFA Item",
    "needByDate": "Need By Date:",
    "category": "Category:",
    "_category": "Category",
    "template": "Template:",
    "requisitionNo": "Requisition No.:",
    "salesOrderNo": "Sales Order No.:",
    "date": "Date:",
    "status": "Status:",
    "description": "Description:",
    "_description": "Description",
    "regionalDescription": "Regional Description:",
    "settings": "Settings",
    "employeeDetails": "Employee Details",
    "supervisorDetails": "Supervisor Details",
    "name": "Name:",
    "mailId": "Email Id:",

    "monthNames": ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ],
    /*Header and footer*/
    "hub2u": "Hub2U",
    "home": "Home",
    "favorites": "Favorites",
    "reports": "Reports",
    "settings": "Settings",
    "search": "Search",
    "searchBy": "Search by",
    "searchHere": "Search here",
    "copyright": "Copyright 2016. Comcast XfinityHub2u",
    "termsAndConditions": "This system is solely for the use of authorized Comcast employees and contractors. Comcast reserves the right at any time to monitor usage of this system to ensure compliance with the Comcast Access Control and Acceptable Use Policies, all applicable Comcast policies that apply to electronic communications and all applicable laws. Your use of this system constitutes your acceptance of and agreement to all applicable Comcast electronic communications policies, your consent to monitoring by Comcast, and your express agreement to use this system in compliance with all applicable laws. Any unauthorized use of or access to this system may result in a revocation of your user privileges, other disciplinary action up to and including termination of employment or contract, or referrals to law enforcement officials including the provision of evidence of any unauthorized use or access to law enforcement.Enter your network credentials and click login to access the system.",

    /* favorites */
    "sortByField": "Sort By Field:",
    "value": "Value",
    "favoritesCaps": "FAVORITES",
    "personalFavorites": "Personal Favorites",
    "regionalFavorites": "Regional Favorites",
    "filter": "Filter",
    "pleaseSelect": "Please Select",
    "_cifaItem": "CIFA Item",
    "_category": "Category",

    /*catalog Search*/

    "catsearchCaps": "CATALOG SEARCH",
    "basicSearch": "Basic Search",
    "advSearch": "Advanced Search",
    "manPartNumber": "Manufacturing Part Number",

    /* Modal window labels*/
    "selectProjectNo": "SEARCH AND SELECT PROJECT NUMBER",
    "selectSrc": "SEARCH AND SELECT SOURCE WAREHOUSE",
    "selectToLocation": "SEARCH AND SELECT DELIVERY TO LOCATION",
    "selectSubInventory": "SEARCH AND SELECT SUB INVENTORY",

    /* Outstanding Sales Order */
    "outstandingSalesCaps": "OUTSTANDING SALES ORDERS",
    "outstandingSales": "Outstanding Sales Orders",
    "inquiryReserve": "Inquiry Reserve",
    "confirmShipping": "Confirm Shipping",
    "reserveAll": "Reserve All",
    "confirmAll": "Confirm All",
    "enterItemNo": "Enter Item Number",
    "salesOrderNo": "Sales Order No.",
    "salesOrderLine": "Sales Order Line",
    "orderedQty": "Ordered Qty.",
    "oderedDate": "Ordered Date",
    "fulfilledQty": "Fulfilled Qty.",
    "lineStatus": "Line Status",
    "qtyToShip": "Quantity To Ship",
    "qtyToReserve": "Quantity To Reserve",
    "confirm": "Confirm",
    "reserve": "Reserve",
    "scanItemCode": "Scan Item Code",
    "go": "GO",
    "or": "-- OR --",
    "tapToScan": "Tap Here To Scan Item Code",
    "enterISO": "Enter ISO Number",
    "reqNo": "Requisition Number",
    "reservedQty": "Reserved Qty",

    /*BU ADMIN */
    "buadminCaps": "BU ADMINISTRATION",
    "regionEmployees": "Region Employees",
    "userPreferences": "User Preferences",
    "businessUnit": "Business Unit",

    /* Acknowledgement */
    "selectAll": "Select All"

}


function getBaseUrlMode() {
    var app = document.URL.indexOf('http://') === -1 && document.URL.indexOf('https://') === -1;
    if (app) {
        return "dev-https";
    } else {
        if (location.href.lastIndexOf("https://hub2u.u1.app.cloud.comcast.net", 0) === 0) {
            return "dev-https";
        } else if (location.href.lastIndexOf("http://cifasoa-dt-a1q.ula.comcast.net:7777/hub2u/", 0) === 0) {
            return "test";
        } else {
            return "dev-https";
        }
    }
}