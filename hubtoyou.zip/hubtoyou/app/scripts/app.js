// Filename: app.js
define([
    'jquery',
    'underscore',
    'backbone',
    'routes/app_router',
    //'touchswipe'
], function($, _, Backbone, AppRouter) {
    var initialize = function() {
        localStorage.setItem("hub2uTimeout", "0");
        console.log("Found router = " + AppRouter);
        if (getUsername() === "") {
            location.href = "#";
            return;
        }
        //initOfflineDb(); // Initialize offlineDb
        $('.slide-menu').show();
        // $(document).ajaxStart(function() {
        //     if (getUsername() !== "") {
        //         $('#spinner_canvas').fadeIn({
        //             duration: 100
        //         });
        //         $('body').addClass('masked');
        //     }
        // });

        // $(document).ajaxStop(function() {
        //     $('#spinner_canvas').fadeOut({
        //         duration: 100
        //     });
        //     $('body').removeClass('masked');
        // });
        // $(document).ajaxError(function() {
        //     $('#spinner_canvas').fadeOut({
        //         duration: 100
        //     });
        //     $('body').removeClass('masked');
        // });
        //var myElement = document.getElementById('page-container');

        // create a simple instance
        // by default, it only adds horizontal recognizers
        //var mc = new Hammer(myElement);

        // listen to events...
        // mc.on("swiperight", function(ev) {
        //     if (window.innerWidth < 992) {
        //         openNav();
        //     }
        // });
        // mc.on("swipeleft", function(ev) {
        //     if (window.innerWidth < 992) {
        //         closeNav();
        //     }
        // });
        // $("#page-container").swipe({
        //     //Generic swipe handler for all directions
        //     swipe: function(event, direction, distance, duration, fingerCount, fingerData) {
        //         if (window.innerWidth < 768) {
        //             if (direction == "right") {
        //                 openNav();
        //             } else {
        //                 closeNav();
        //             }
        //         }

        //     }
        // });
    }
    return {
        initialize: initialize
    };
});