var data = {

    "STATUS": "STATUS64",

    "STATUS_MESSAGE": "STATUS_MESSAGE65",

    "UsersListOutput": [{

        "PERSON_ID": 66,

        "PERNR": "PERNR67",

        "EMPLOYEE_NAME": "EMPLOYEE_NAME68",

        "TITLE": "TITLE69",

        "EMAIL_ADDRESS": "EMAIL_ADDRESS70",

        "BUSINESS_UNIT": "BUSINESS_UNIT71",

        "NTID": "NTID72"

    }]

};