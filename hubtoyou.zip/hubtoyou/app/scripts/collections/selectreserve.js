/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone, FavoritesModel) {
    'use strict';
    var SelectReserveModel = Backbone.Model.extend();
    var SelectReserveCollection = Backbone.Collection.extend({
        model: SelectReserveModel,
        selectedStrategy: "requisition_number",

        search: function(value) {
            if (value == "") return this;
            var pattern = new RegExp(value, "gi");
            var filtered = this.filter(function(data) {
                return (
                    pattern.test(data.get('order_number')) ||
                    pattern.test(data.get('flow_status_code')) ||
                    pattern.test(data.get('line_number')) ||
                    pattern.test(DateFormatter(data.get('ordered_date')))
                );
            });
            return new SelectReserveCollection(filtered);
        },

        changeSort: function(value) {
            this.comparator = function(model) {
                return model.get(value);
            }
            this.sort();
        },

        fetchData: function(dataInput) {
            showLoadingIndicator();
            var that = this;
            this.fetch({
                data: JSON.stringify(dataInput),
                type: 'POST',
                reset: true,
                success: function(collection, response, options) {

                },
                error: function() {
                    hideLoadingIndicator();
                }
            });
        },

        parse: function(response) {
            if (typeof response.EXC_DB_SELECT_SO_RESERVEOutput !== "undefined") {
                return response.EXC_DB_SELECT_SO_RESERVEOutput;
            } else {
                hideLoadingIndicator();
                return null;
            }
        },

        url: config.urls[config.mode] + config.service["selectReserve"]
    });

    return SelectReserveCollection;
});