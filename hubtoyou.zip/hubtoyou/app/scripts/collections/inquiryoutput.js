/*global define*/

define([
  'underscore',
  'backbone',
  'models/inquiryoutput'
], function (_, Backbone, InquiryOutputModel) {
  'use strict';

  var InquiryOutputCollection = Backbone.Collection.extend({
      model: InquiryOutputModel,
      url: config.urls[config.mode] + config.service["itemInquiry"],
      fetchData: function(data) {
        // var data = {
        //   "Cifa_Item_Number" : "000032702",
        //   "username" : "MUPADH200"
        // }
        this.fetch({
          data: JSON.stringify(data),
          type: 'POST',
          reset: true
        });
      },
      parse: function(response){
        return response;
      },
      initialize: function() {

      }
  });

  return InquiryOutputCollection;
});
