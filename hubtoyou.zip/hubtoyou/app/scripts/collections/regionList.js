/*global define*/

define([
    'underscore',
    'backbone',
    'models/shippingcartitemdetails'
], function(_, Backbone, cartItemDetailsModel) {
    'use strict';

    var Region = Backbone.Model.extend();

    var RegionListCollection = Backbone.Collection.extend({
        model: Region,
        url: config.urls[config.mode] + config.service["regionList"],
        fetchData: function() {
            var userdata = JSON.parse(sessionStorage.getItem("_id"));
            var dataInput = {
                "Requestor_User_Name": getUsername()
            };
            // var data = {
            //   "Requestor_User_Name" : "MUPADH200"
            // }
            showLoadingIndicator();
            this.fetch({
                data: JSON.stringify(dataInput),
                type: 'POST',
                reset: true,
                success: function(collection, response, options) {
                    hideLoadingIndicator();
                },
                error: function() {
                    hideLoadingIndicator();
                    //modalMsg("Unable to connect to the server. Please try again.", "error");
                }
            });
        },
        parse: function(response) {
            // if(!isRegionNameAvailable){
            //   sessionStorage.setItem("regionName", JSON.stringify(response.RegonListOutput[0].Lookup_Code));
            //   isRegionNameAvailable = true;
            //   var cartDetails = new cartItemDetailsModel();
            //   var dataInput = {"USER_NAME" : "MUPADH200","REGION_NAME" : sessionStorage.getItem('regionName')};
            //   cartDetails.getCartItems(dataInput);
            // }

            return response.RegonListOutput;
        },
        initialize: function() {

        }
    });

    return RegionListCollection;
});