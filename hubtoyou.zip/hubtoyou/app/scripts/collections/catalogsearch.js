/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var Template = Backbone.Model.extend();

    var CatalogSearchCollection = Backbone.Collection.extend({
        model: Template,
        selectedStrategy: "itemNumber",

        url: config.urls[config.mode] + config.service["itemDetails"],
        fetchData: function(data) {
            showLoadingIndicator();
            this.fetch({
                data: JSON.stringify(data),
                type: 'POST',
                reset: true,
                success: function(collection, response, options) {
                    //hideLoadingIndicator();
                },
                error: function() {
                    hideLoadingIndicator();
                    modalMsg("Unable to connect to the server. Please try again.", "error");
                }
            });
        },
        parse: function(response) {
            return response.ItemDetailsOutput;
        },
        initialize: function() {

        },

        search: function(value) {
            if (value == "") return this;
            var pattern = new RegExp(value, "gi");
            var filtered = this.filter(function(data) {
                return (
                    pattern.test(data.get('CIFA_ITEM_NUMBER')) ||
                    pattern.test(data.get('CATEGORY')) ||
                    //pattern.test(data.get('REGION_NAME')) ||
                    //pattern.test(data.get('TEMPLATE_NAME')) ||
                    pattern.test(data.get('ITEM_DESCRIPTION'))
                );
            });
            return new CatalogSearchCollection(filtered);
        },

        changeSort: function(value) {
            this.comparator = function(model) {
                return model.get(value);
            }
            this.sort();
        }
    });

    return CatalogSearchCollection;
});