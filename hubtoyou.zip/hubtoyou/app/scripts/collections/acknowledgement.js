/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';
    var ackModel = Backbone.Model.extend();
    var AcknowledgementCollection = Backbone.Collection.extend({
        model: ackModel,
        selectedStrategy: "itemNumber",
        fetchData: function(dataInput) {
            var that = this;
            this.fetch({
                data: JSON.stringify(dataInput),
                type: 'POST',
                reset: true,
                success: function(collection, response, options) {},
                error: function() {
                    //alert('service failure');
                }
            });
        },
        parse: function(response) {
            if (response != null) {
                //return response.GetFavoriteOutput;
                console.log(response);
            } else {
                return null;
            }
        },
        url: config.urls[config.mode] + config.service["techAckGetShipment"]
    });

    return AcknowledgementCollection;
});