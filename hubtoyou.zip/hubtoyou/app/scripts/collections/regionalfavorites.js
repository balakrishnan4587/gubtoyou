/*global define*/

define([
    'underscore',
    'backbone',
    'models/personalfavorites',
    'stub/favourites'
], function(_, Backbone, FavoritesModel) {
    'use strict';

    var RegionalFavoritesCollection = Backbone.Collection.extend({
        model: FavoritesModel,
        url: config.urls[config.mode] + config.service["getRegionalFavorites"],
        searchBy: function(attribute, value) {
            if (value == "") return this;
            var pattern = new RegExp(value, "gi");
            var filtered = this.filter(function(data) {
                return pattern.test(data.get(attribute));
            });
            return new RegionalFavoritesCollection(filtered);
        },
        search: function(value) {
            if (value == "") return this;
            var pattern = new RegExp(value, "gi");
            var filtered = this.filter(function(data) {
                return (
                    pattern.test(data.get('CIFA_ITEM_NUMBER')) ||
                    pattern.test(data.get('ITEM_CATEGORY')) ||
                    pattern.test(data.get('REGION_NAME')) ||
                    pattern.test(data.get('TEMPLATE_NAME')) ||
                    pattern.test(data.get('ITEM_DESCRIPTION'))
                );
            });
            return new RegionalFavoritesCollection(filtered);
        },
        // comparator: function (model) {
        //   return model.get("CIFA_ITEM_NUMBER");
        // },
        changeSort: function(value) {
            this.comparator = function(model) {
                return model.get(value);
            }
            this.sort();
        },
        fetchData: function(data) {
            showLoadingIndicator();
            this.fetch({
                data: JSON.stringify(data),
                type: 'POST',
                reset: true,
                success: function(collection, response, options) {},
                error: function() {
                    hideLoadingIndicator();
                    //modalMsg("Unable to connect to the server. Please try again.", "error");
                }
            });
        },
        parse: function(response) {
            if (response != null) {
                if (response.RegonFavListOutput === undefined) {
                    hideLoadingIndicator();
                    return null;
                }
                return response.RegonFavListOutput;
            } else {
                return null;
            }
        },

    });

    return RegionalFavoritesCollection;
});