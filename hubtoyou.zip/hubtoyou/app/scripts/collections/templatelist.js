/*global define*/

define([
    'underscore',
    'backbone'
], function(_, Backbone) {
    'use strict';

    var Template = Backbone.Model.extend();

    var TemplateListCollection = Backbone.Collection.extend({
        model: Template,
        url: config.urls[config.mode] + config.service["templateList"],
        fetchData: function(data) {
            showLoadingIndicator();
            this.fetch({
                data: JSON.stringify(data),
                type: 'POST',
                reset: true,
                success: function(collection, response, options) {
                    hideLoadingIndicator();
                },
                error: function() {
                    hideLoadingIndicator();
                    modalMsg("Unable to connect to the server. Please try again.", "error");
                }
            });
        },
        parse: function(response) {
            return response.TemplateListOutput;
        },
        initialize: function() {

        }
    });

    return TemplateListCollection;
});