/*global define*/

define([
    'underscore',
    'backbone',
    'models/home',
    'views/home',
    'stub/favourites',

], function(_, Backbone, HomeModel, HomeView) {
    'use strict';

    var HomeCollection = Backbone.Collection.extend({
        model: HomeModel,
        selectedStrategy: "itemNumber",

        search: function(obj) {
            var filtered = this.filter(function(data) {
                var param = false;
                if (obj.approved) {
                    param = param || data.get('STATUS') == 'Approved'
                }
                if (obj.pending) {
                    param = param || data.get('STATUS') == 'In Process'
                }
                if (obj.declined) {
                    param = param || data.get('STATUS') == 'Incomplete'
                }
                if (obj.onProjectHold) {
                    param = param || data.get('STATUS') == 'On Project Hold'
                }
                return param;
            });
            return new HomeCollection(filtered).sort();
        },
        comparator: function(model) {
            return -new Date(model.get("CREATION_DATE"));
        },
        // filterBy: function(attribute, value) {
        //   var filtered = this.filter(function(data) {
        //     if(value == "") return this;
        //   	var pattern = new RegExp(value,"gi");
        //     return pattern.test(data.get(attribute));
        //   });
        //   return new PersonalFavoritesCollection(filtered);
        // },

        // comparator: function (model) {
        //   return model.get("REQUISITION_NUMBER");
        // },
        // changeSort: function(value){
        //   this.comparator = function(model) {
        //     return model.get(value);
        //   }
        //   this.sort();
        // },
        fetchOfflineData: function() {
            var me = this;
            var user = sessionStorage.getItem("offlineUser") || getUsername();
            offlineDB.getAllData("requisitions", user, function(items) {
                // items.forEach(function(item) {
                //     item.REQUISITION_NUMBER = item.REQUISITION_NUMBER + " *offline";
                // });
                me.reset(items, { silent: true });
                me.trigger("offlineReset", me);
            });
        },
        fetchData: function() {
            var that = this;
            var dataInput = { "requestor": getUsername() };
            this.fetch({
                data: JSON.stringify(dataInput),
                type: 'POST',
                success: function(collection, response, options) {
                    var user = getUsername();
                    if (isOnline) {
                        offlineDB.clearData("requisitions", user);
                    }
                    collection.models.forEach(function(model) {
                        if (isOnline && offlineDB) {
                            var item = model.toJSON();
                            item.username = user;
                            offlineDB.addData("requisitions", user, item);
                        }
                    });
                },
                error: function() {
                    //alert('service failure');
                }
            });
        },
        parse: function(response) {
            if (typeof response.RequisitionHeaderOutput == "undefined") {
                //this.reset();
            }
            //this.homeHeaderResposne = response.RequisitionHeaderOutput;
            return response.RequisitionHeaderOutput;
        },
        //url:'http://cifasoa-dt-a1d.ula.comcast.net:8301/soa-infra/resources/MobileApp/TechnicianFavorite!1.0/TechnicianFavoriteRest/GetFavorite'
        url: config.urls[config.mode] + config.service["requisitionHeader"]
    });

    return HomeCollection;
});