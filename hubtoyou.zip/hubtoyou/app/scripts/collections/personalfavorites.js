/*global define*/

define([
    'underscore',
    'backbone',
    'models/personalfavorites',
    'stub/favourites'
], function(_, Backbone, FavoritesModel) {
    'use strict';

    var PersonalFavoritesCollection = Backbone.Collection.extend({
        model: FavoritesModel,
        selectedStrategy: "itemNumber",

        search: function(value) {
            if (value == "") return this;
            var pattern = new RegExp(value, "gi");
            var filtered = this.filter(function(data) {
                return (
                    pattern.test(data.get('CIFA_ITEM_NUMBER')) ||
                    pattern.test(data.get('ITEM_CATEGORY')) ||
                    pattern.test(data.get('REGION_NAME')) ||
                    pattern.test(data.get('TEMPLATE_NAME')) ||
                    pattern.test(data.get('ITEM_DESCRIPTION'))
                );
            });
            return new PersonalFavoritesCollection(filtered);
        },

        // filterBy: function(attribute, value) {
        //   var filtered = this.filter(function(data) {
        //     if(value == "") return this;
        //   	var pattern = new RegExp(value,"gi");
        //     return pattern.test(data.get(attribute));
        //   });
        //   return new PersonalFavoritesCollection(filtered);
        // },

        // comparator: function (model) {
        //   return model.get("CIFA_ITEM_NUMBER");
        // },
        changeSort: function(value) {
            this.comparator = function(model) {
                return model.get(value);
            }
            this.sort();
        },
        fetchOfflineData: function() {
            var me = this;
            var user = sessionStorage.getItem("offlineUser");
            offlineDB.getAllData("favorites", user, function(items) {
                me.reset(items);
            });
        },
        fetchData: function() {
            showLoadingIndicator();
            var dataInput = {
                "REQUESTOR_USER_NAME": getUsername()
            };
            var that = this;
            this.fetch({
                data: JSON.stringify(dataInput),
                type: 'POST',
                reset: true,
                success: function(collection, response, options) {},
                error: function() {
                    // hideLoadingIndicator();
                    // modalMsg("Unable to connect to the server. Please try again.", "error");
                }
            });
        },
        parse: function(response) {
            if (response != null) {
                if (response.GetFavoriteOutput === undefined) {
                    hideLoadingIndicator();
                    return null;
                }
                return response.GetFavoriteOutput;
            } else {
                return null;
            }
        },
        url: config.urls[config.mode] + config.service["getFavorites"]
    });

    return PersonalFavoritesCollection;
});