/*global define*/

define([
    'underscore',
    'backbone',
    'models/favorites',
    'stub/favourites'
], function(_, Backbone, FavoritesModel) {
    'use strict';

    var FavoritesCollection = Backbone.Collection.extend({
        model: FavoritesModel,

        // sortByField: function(field, direction) {
        //   sorted = _.sortBy(this.models, function(model) {
        //     return model.get(field);
        //   });
        //
        //   if (direction === 'descending') {
        //     sorted = sorted.reverse()
        //   }
        //   this.models = sorted;
        // },

        fetchData: function(options) {
            var userdata = JSON.parse(sessionStorage.getItem("_id"));
            var dataInput = {
                "REQUESTOR_USER_NAME": userdata.sub
            };
            this.fetch({
                data: JSON.stringify(dataInput),
                type: 'POST'
            });
        },
        url: config.urls[config.mode] + config.service["getRegionalFavorites"]

    });

    return FavoritesCollection;
});