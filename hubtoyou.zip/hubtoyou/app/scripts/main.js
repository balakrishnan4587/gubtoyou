/*global require*/
'use strict';

require.config({
    shim: {
        bootstrap: {
            deps: ['jquery'],
            exports: 'jquery'
        },
        datepicker: {
            deps: ["jquery", "bootstrap"],
            exports: "$.fn.datepicker"
        }
    },
    paths: {
        jquery: '../bower_components/jquery/dist/jquery',
        backbone: '../bower_components/backbone/backbone',
        underscore: '../bower_components/lodash/dist/lodash',
        bootstrap: '../bower_components/bootstrap-sass-official/assets/javascripts/bootstrap.min',
        //touchswipe: '../bower_components/jquery-touchswipe/jquery.touchSwipe.min',
        datepicker: '../scripts/vendor/bootstrap-datepicker.min',
        hammer: '../scripts/vendor/hammer',
        numberspinner: '../scripts/vendor/jquery.bootstrap-touchspin.min',
        jqueryui: '../scripts/vendor/jquery-ui.min',
        xpull: '../scripts/vendor/xpull',
        globalise: '../scripts/globalise/globalise',
        helper: '../scripts/helper',
        auth_helper: '../scripts/oauth_helper',
        db_helper: '../scripts/offline_db_helper',
        templates: 'templates',
        AppView: '../scripts/routes/AppView'
    }
});

require([
    'app'
], function(App) {
    // Initialize our application.
    // if (isAndroid()) {
    //     $("script").attr("src", "cordova.js").appendTo("head");
    // } else if (isiOS()) {
    //     $("script").attr("src", "cordova.js").appendTo("head");
    // }
    document.addEventListener("deviceready", onDeviceReady, false);
    document.getElementById("termsAndConds").addEventListener("click", popupModalTermsCond, false);
    document.getElementById("helpMobileLink").addEventListener("click", fetchHelpLink, false);

    function onDeviceReady() {
        var _curStatus = false;

        function toggleStatus(newVal) {
            console.log('Setting internet connection state to: ' + newVal);
            _curStatus = newVal;
            isOnline = newVal;
            if (newVal === false) {
                sessionStorage.setItem("loggedIn", false);
                location.href = "#offlinelogin";
            } else {
                //location.reload();
            }
        }

        var conType = navigator.network.connection.type;
        toggleStatus((conType != Connection.NONE) && (conType != Connection.UNKNOWN));
        document.addEventListener("online", function() { toggleStatus(true); }, false);
        document.addEventListener("offline", function() { toggleStatus(false); }, false);
        App.initialize();
    }
    if (typeof cordova === "undefined") {
        App.initialize();
    }
});