define([
    'jquery',
    'backbone',
    'bootstrap',
    'auth_helper',
    'db_helper',
    'models/profiledetails',
    'views/layout',
    'views/login',
    'views/home',
    'collections/home',
    'views/favorites',
    'views/personalfavorites',
    'views/reports',
    'views/settings',
    'views/selectsource',
    'views/requisitiondetails',
    'views/itemDetails',
    'views/notification',
    'views/catalogsearch',
    'views/shoppingcart',
    'views/selectprojectnumber',
    'views/checkout',
    'views/logout',
    'views/acknowledgement',
    'views/loginoffline',
    'views/intransit',
    'views/catalogimages',
    'views/oustandingsalesorder',
    'views/buadministration',
    'views/administration',
    'views/adminresponseadduser',
    'views/error',
    'views/announcement',
    'models/admingrantedresponsibility',
    'models/settings',
    'views/viewNotAuthorized',
    'models/shippingcartitemdetails',
    'globalise'


], function($, Backbone, Bootstrap, Auth_helper, DB_helper, ProfileModel, LayoutView, LoginView, HomeView, HomeCollection,
    FavoritesView, PersonalFavoritesView, ReportsView, SettingsView, SelectsourceView, RequisitionDetailsView, ItemDetailsView, NotificationView, SearchView, ShoppingCartView, SelectProjectNumberView, CheckoutView, LogoutView, AcknowledgementView, OfflineLoginView, IntransitView, CatalogImagesView, OutstandingSalesView, BUAdministrationView, AdministrationView, AdminAddNTUserView, ErrorView, AnnouncementView, GrantedResponsibilityModel, SettingsModel, ViewNotAuthorized, CartItemDetailsModel) {

    'use strict';
    Backbone.Router.prototype.before = function() {};
    Backbone.Router.prototype.after = function() {};

    var grantedResponsibilityModel = new GrantedResponsibilityModel();

    Backbone.Router.prototype.route = function(route, name, callback) {
        if (!_.isRegExp(route)) route = this._routeToRegExp(route);
        if (_.isFunction(name)) {
            callback = name;
            name = '';
        }
        if (!callback) callback = this[name];

        var router = this;

        Backbone.history.route(route, function(fragment) {
            var args = router._extractParameters(route, fragment);

            // var next = function() {
            //     callback && callback.apply(router, args);
            //     router.trigger.apply(router, ['route:' + name].concat(args));
            //     router.trigger('route', name, args);
            //     Backbone.history.trigger('route', router, name, args);
            //     router.after.apply(router, args);
            // }
            // router.before.apply(router, [args, next]);

            router.before.apply(router, arguments);
            callback && callback.apply(router, args);
            router.after.apply(router, arguments);

            router.trigger.apply(router, ['route:' + name].concat(args));
            router.trigger('route', name, args);
            Backbone.history.trigger('route', router, name, args);
        });
        return this;
    };

    var AppRouter = Backbone.Router.extend({
        routeParams: {},

        //rolebasedroutes: ['#administration', '#addntusername'],
        responsibilities: {
            '#administration': 1,
            '#catalogimages': 2,
            '#buadmin': 6,
            //'#announcement': 13,
            '#outstandingsalesorders': 14,
            '#announcement?manage': 13
        },

        routes: {

            '': 'viewLogin',
            'login': 'viewLogin',
            'authenticate': 'authenticate',
            'logout': 'logout',
            'logout_success': 'logoutSuccess',
            'home': 'viewHome',
            'home?=:viewType': 'viewHome',
            'requisitionDetail?=:viewType': 'viewReqDetail',
            'homeFilter': 'viewHomeFilter',
            'favorites': 'viewFavorites',
            'favorites?=:viewType': 'viewFavorites',
            'reports': 'viewReports',
            'settings?view=:viewType': 'viewSettings',
            'settings': 'viewSettings',
            'select_source?=:viewType': 'viewSelectSource',
            'notification': 'notificationView',
            'item_details?=:viewType': 'viewItemDetails',
            'search': 'viewSearch',
            'search?:viewType': 'viewSearch',
            'shoppingcart': 'viewShoppingCart',
            'shoppingcart?=:viewType': 'viewShoppingCart',
            'checkout': 'viewCheckout',
            'acknowledgement': 'viewAcknowledgement',
            'offlinelogin': 'viewOfflineLogin',
            'intransit': 'viewIntransit',
            'outstandingsalesorders': 'ViewOutstandingSalesOrder',
            'buadmin': 'viewBUADmin',
            'catalogimages': 'viewCatalogImages',
            'administration': 'viewAdministration',
            'addntusername': 'viewAddNTUserName',
            'error': 'viewErrorPage',
            'announcement?:viewType': 'viewAnnouncement',
            'notauthorized': 'ViewNotAuthorized',
            '*path': 'viewLogin'
        },

        initialize: function(options) {
            this.route(/^access_token/, 'accesstoken');
            this.profileModel = new ProfileModel();
            this.cartItemDetailsModel = new CartItemDetailsModel();
            this.settingsModel = new SettingsModel();
        },

        accesstoken: function() {
            var access_token = window.location.href.match(/\#(?:access_token)\=([\S\s]*?)\&/)[1];
            auth0.decodeToken(access_token);
            config.isFirstLogin = true;
        },

        before: function(params, next) {
            var path = Backbone.history.location.hash;

            setHamburgerIcon();
            $('#mob-btn-cart').show();
            hideHeaderButtons();

            if (auth0.isLoggedIn()) {
                if (sessionStorage.getItem(getUsername() + "responsibilities") === null) {
                    var dataInput = {
                        "BIND_APPLICATIONID": "1",
                        "USER_NAME": getUsername()
                    };
                    if (isOnline) {
                        grantedResponsibilityModel.getUserGrantedResponsibility(dataInput, function(data) {
                            sessionStorage.setItem(getUsername() + "responsibilities", JSON.stringify(data));
                            Backbone.history.navigate("#home", { trigger: true });
                            enableItemsForResponsibility();
                        });
                    } else {
                        var user = getUsername();
                        if (offlineDB.db) {
                            offlineDB.getAllData("RESPONSIBILITIES", user, function(items) {
                                sessionStorage.setItem(getUsername() + "responsibilities", JSON.stringify(items[0]));
                                enableItemsForResponsibility();
                            });

                            offlineDB.getAllData("PROFILE", user, function(items) {
                                sessionStorage.setItem("_id", items[0]);
                            });
                        }

                        Backbone.history.navigate("#home", { trigger: true });
                    }
                }
                if (sessionStorage.getItem(getUsername() + "profileImage") === null) {
                    var dataInput = {
                        "REQUESTOR_NAME": getUsername(),
                        "ACCESS_TOKEN": sessionStorage.getItem("token")
                    };
                    if (isOnline) {
                        this.profileModel.fetchData(dataInput);
                    }
                }
                if (sessionStorage.getItem("cartItemsCount") === null) {
                    if (isOnline) {
                        this.cartItemDetailsModel.getCartItems();
                    }
                }

                if (sessionStorage.getItem("preferences") === null) {
                    if (isOnline) {
                        this.settingsModel.fetchData();
                    }
                } else {
                    var preferences = JSON.parse(sessionStorage.getItem("preferences"));
                    if (getUsername().toLowerCase() !== preferences.USER_NAME.toLowerCase()) {
                        if (isOnline) {
                            this.settingsModel.fetchData();
                        }
                    }
                }

                updateCartCount();


                var hash = window.location.hash;

                if (typeof this.responsibilities[hash] != "undefined") {
                    if (USER_FUNCTIONS.indexOf(this.responsibilities[hash]) > -1) {
                        console.log("You have access");
                    } else {
                        console.log("You do not have access");
                        window.location.href = '#notauthorized';
                        return false;
                    }
                }
            }

            // var epath = path.indexOf('/') === -1 ? path : path.substring(0, path.indexOf('/'));
            // var checkpermission = _.contains(this.rolebasedroutes, epath);
            // if (checkpermission) {

            //     var resp_id = this.responsibilities[epath];

            //     if (!checkResponsibilityAccess(resp_id)) {
            //         //dont have access

            //         //window.location.href = "#notauthorized";
            //         Backbone.history.navigate('notauthorized', { trigger: true });
            //         return;
            //     }
            // }

            // var epath = path.indexOf('/') === -1 ? path : path.substring(0, path.indexOf('/'));
            // var checkpermission = _.contains(this.rolebasedroutes, epath);


            // if (checkpermission) {
            //     var resp_id = this.responsibilities[epath];
            //     if (!checkResponsibilityAccess(resp_id)) {
            //         //dont have access
            //         //window.location.href = "#notauthorized";
            //         Backbone.history.navigate('notauthorized', { trigger: true });
            //         return;
            //     }

            //     return next();
            // }

        },

        after: function() {
            var userdata = sessionStorage.getItem("_id");
            if (userdata != null) {
                setUserDetails();
            }

            var profileImage = sessionStorage.getItem(getUsername() + "profileImage");
            if (profileImage !== null) {
                if (profileImage !== "") {
                    $(".profile-image-mob").css('background', 'url(' + profileImage + ') no-repeat center');
                    $("#desk-user-icon").css('background', 'url(' + profileImage + ') no-repeat center').addClass("small-profile-image");
                }
            }
        },
        navigate: function(route, options) {
            var routeOption = {
                    trigger: true
                },
                params = (options && options.params) ? options.params : null;
            $.extend(routeOption, options);
            delete routeOption.params;

            //set the params for the route
            this.param(route, params);
            Backbone.Router.prototype.navigate(route, routeOption);
        },

        /*
         *Get or set parameters for a route fragment
         *@param {String} fragment Exact route hash. for example:
         *                   If you have route for 'profile/:id', then to get set param
         *                   you need to send the fragment 'profile/1' or 'profile/2'
         *@param {Any Type} params The parameter you to set for the route
         *@return param value for that parameter.
         **/
        param: function(fragment, params) {
            var matchedRoute;
            _.any(Backbone.history.handlers, function(handler) {
                if (handler.route.test(fragment)) {
                    matchedRoute = handler.route;
                }
            });
            if (params !== undefined) {
                this.routeParams[fragment] = params;
            }

            return this.routeParams[fragment];
        },
    });

    var initialize = function() {
        var router = new AppRouter();
        var layout = new LayoutView().render();
        enableItemsForResponsibility();

        Backbone.View.prototype.goTo = function(loc, params) {
            console.log("Navigating to: " + loc);
            router.navigate(loc, { params: params }, true);
        };

        Backbone.View.prototype.remove = function() {
            this.$el.empty().off(); /* off to unbind the events */
            this.stopListening();
            return this;
        };

        Backbone.View.prototype.close = function() {
            if (this.childView) {
                this.childView.remove();
                this.childView.unbind();
            }
            this.remove();
            this.unbind();
            if (this.onClose) {
                this.onClose();
            }
        };



        router.on("route:token", function() {
            var token = auth0.getParameterByName("access_token", location.hash);
            auth0.getToken(token);
        });

        router.on("route:authenticate", function() {
            var loginView = new LoginView();
            AppView.setCurrentView(loginView);
            layout.renderChild(loginView, '');
            // var code = auth0.getParameterByName("code", location.hash);
            // auth0.getToken(code);
        });
        router.on("route:logout", function() {
            if ($('#page-container').hasClass('menu-visible')) {
                closeNav();
            }
            auth0.logout();
        });
        router.on("route:logoutSuccess", function() {
            var logoutView = new LogoutView();
            AppView.setCurrentView(logoutView);
            layout.renderChild(logoutView, '');
        });

        router.on("route:ViewNotAuthorized", function() {
            var notAuthorizedView = new ViewNotAuthorized();
            AppView.setCurrentView(notAuthorizedView);
            notAuthorizedView.render();
        });



        router.on("route:viewLogin", function() {
            if (!isOnline) {
                setTimeout(function() {
                    var loginView = new OfflineLoginView();
                    AppView.setCurrentView(loginView);
                    layout.renderChild(loginView);
                }, 1000);
            } else {
                if (auth0.isLoggedIn()) {
                    location.href = "#home";
                } else {
                    var loginView = new LoginView();
                    AppView.setCurrentView(loginView);
                    layout.renderChild(loginView);
                    setTimeout(function() {
                        if (isOnline) {
                            console.log("authorizing...");
                            auth0.authorize();
                        }
                    }, 1000);
                }
            }
        });

        router.on("route:viewOfflineLogin", function() {
            var loginView = new OfflineLoginView();
            AppView.setCurrentView(loginView);
            layout.renderChild(loginView);
        });

        router.on("route:viewReqDetail", function(viewType) {
            breadCrumbs.push({
                "name": "Requisition Details",
                "href": "#" + previousView
            });

            updateBreadCrumbs();

            var requisitionDetailsView = new RequisitionDetailsView();
            AppView.setCurrentView(requisitionDetailsView);
            showLoadingIndicator();
            requisitionDetailsView.model.fetchData(viewType);
        });

        router.on("route:viewHome", function(viewType) {
            if (getUsername() != null) {
                localStorage.setItem("lastUsedBy", getUsername());
            }
            $("#header").show();
            $("#footer").show();

            // var profileImage = sessionStorage.getItem(getUsername() + "profileImage");
            // if (profileImage !== null) {
            //     if (profileImage !== "") {
            //         $(".profile-image-mob").css('background', 'url(' + profileImage + ') no-repeat center');
            //         $("#desk-user-icon").css('background', 'url(' + profileImage + ') no-repeat center').addClass("small-profile-image");
            //     }
            // }

            breadCrumbs = [];
            breadCrumbs.push({
                "name": "Home",
                "href": "#home"
            });


            $("#nav_home").parent().addClass('active').siblings().removeClass('active');
            // if (viewType !== undefined && viewType !== null) {
            //     var requisitionDetailsView = new RequisitionDetailsView();
            //     //AppView.setCurrentView(requisitionDetailsView);
            //     requisitionDetailsView.model.fetchData(viewType);
            //     breadCrumbs.push({
            //         "name": "Requisition Details",
            //         "href": "#home"
            //     });
            //     //new RequisitionDetailsView().render();
            // } else {
            var homeView = new HomeView();
            AppView.setCurrentView(homeView);
            // if (this.param('home') !== undefined && this.param('home') !== null) {
            //     var data = this.param('home');
            //     delete this.routeParams.home;
            //     //homeView.render(data);
            // } else {
            //     $("#header").show();
            //     $("#footer").show();
            //     //AppView.setCurrentView(homeView);
            //     homeView.collection.fetchData();
            // }
            //homeView.collection.fetchData();
            setTitle(globalize.home, "icon-home");
            // }
            $('.btn-home').addClass('active').siblings().removeClass('active');
            updateBreadCrumbs();
        });
        router.on("route:viewHomeFilter", function() {
            //new FilterView().render();
            $('#homeviewPage').hide();
            $('#filterviewPage').show();

            updateBreadCrumbs();
        });

        // router.on("route:viewAcknowledgement", function(viewType) {
        //     breadCrumbs.push({
        //         "name": "Acknowledgement",
        //         "href": "#acknowledgement"
        //     });
        //     updateBreadCrumbs();
        //     toggleBackButton();
        //     var acknowledgementView = new AcknowledgementView();

        //     AppView.setCurrentView(acknowledgementView);
        //     acknowledgementView.model.fetchData(JSON.parse(viewType));
        //     setTitle("Acknowledgement", "");
        // });

        router.on("route:viewFavorites", function(viewType) {
            setTitle("BU Admin", "");
            breadCrumbs = [];
            breadCrumbs.push({
                "name": "Favorites",
                "href": "#favorites?personal"
            });
            if (viewType === null) {
                viewType = "personal"
            }
            if (viewType === "personal") {
                breadCrumbs.push({
                    "name": "Personal Favorites",
                    "href": "#favorites?" + viewType
                });
            } else {
                breadCrumbs.push({
                    "name": "Regional Favorites",
                    "href": "#favorites?" + viewType
                });
            }

            $("#nav_favorites").parent().addClass('active').siblings().removeClass('active');
            var favoritesView = new FavoritesView();
            AppView.setCurrentView(favoritesView);
            favoritesView.renderFavoritesMain(viewType);
            setTitle(globalize.favorites, "icon-favorites");

            updateBreadCrumbs();
        });
        router.on("route:viewReports", function() {

            breadCrumbs = [];
            breadCrumbs.push({
                "name": "Reports",
                "href": "#reports"
            });

            $("#nav_reports").parent().addClass('active').siblings().removeClass('active');
            var reportsView = new ReportsView();
            AppView.setCurrentView(reportsView);
            reportsView.renderMain();
            //new ItemDetailsView().model.fetchData("000126225");
            setTitle(globalize.reports, "icon-reports");

            updateBreadCrumbs();
        });
        router.on("route:viewSettings", function(viewType) {
            if (getUsername() === "") {
                location.href = "#";
                return;
            }
            breadCrumbs = [];
            breadCrumbs.push({
                "name": "Settings",
                "href": "#settings"
            });

            $("#nav_settings").parent().addClass('active').siblings().removeClass('active');
            var settingsView = new SettingsView();
            AppView.setCurrentView(settingsView);
            if (viewType != undefined) {
                if (viewType === "project-selection") {
                    settingsView.loadProjectSelectionWindow();
                }
            } else {
                if (isOnline) {
                    showLoadingIndicator();
                    settingsView.model.fetchData();
                } else {
                    settingsView.model.fetchOfflineData();
                }
                setTitle(globalize.settings, "icon-settings");
            }

            updateBreadCrumbs();
        });

        router.on("route:viewSelectSource", function(viewType) {
            var selectSourceView = new SelectsourceView();
            AppView.setCurrentView(selectSourceView);
            showLoadingIndicator();
            selectSourceView.loadData(viewType);
            if (!_.findWhere(breadCrumbs, { name: 'Select Source' })) {
                breadCrumbs.push({
                    "name": "Select Source",
                    "href": "#select_source?=" + viewType
                });
            }
            setTitle("Select Source", "");
            updateBreadCrumbs();
            toggleBackButton();
        });

        router.on("route:notificationView", function() {
            layout.renderChild(new NotificationView());
            updateBreadCrumbs();
        });

        router.on("route:viewItemDetails", function(viewType) {
            var itemDetailsView = new ItemDetailsView()
            AppView.setCurrentView(itemDetailsView);
            if (viewType != undefined) {
                if (!_.findWhere(breadCrumbs, { name: 'CIFA Item Details' })) {
                    breadCrumbs.push({
                        "name": "CIFA Item Details",
                        "href": "#item_details?=" + viewType
                    });
                }
                showLoadingIndicator();
                itemDetailsView.model.fetchData(viewType);
            }
            setTitle("CIFA Item Details", "");
            updateBreadCrumbs();
            toggleBackButton();
        });

        router.on("route:viewSearch", function(viewType) {
            var searchView = new SearchView();
            AppView.setCurrentView(searchView);
            searchView.render(viewType);
            breadCrumbs = [];
            breadCrumbs.push({
                "name": "Catalog Search",
                "href": "#search"
            });
            updateBreadCrumbs();
            setTitle(globalize.search, "icon-search");
            $('.navbar-nav li').removeClass('active');
        });


        router.on("route:viewShoppingCart", function(viewType) {
            if (viewType != null && viewType == "projectNumber") {
                globalize.modalTitle = globalize.selectProjectNo;
                var projectDetailsView = new SelectProjectNumberView();
                breadCrumbs = [];
                breadCrumbs.push({ href: '#', name: 'Search And Select: Project Number' });
            } else {
                breadCrumbs = [];
                breadCrumbs.push({
                    "name": "ShoppingCart",
                    "href": "#shoppingcart"
                });
                updateBreadCrumbs();
                setTitle("Cart", "mob-cart");
                $('#mob-btn-cart').hide();
                var shoppingCartView = new ShoppingCartView();
                AppView.setCurrentView(shoppingCartView);
                showLoadingIndicator();
                if (isOnline) {
                    shoppingCartView.model.getCartItems();
                } else {
                    shoppingCartView.model.fetchOfflineData();
                }
            }
        });
        // router.on("route:viewShoppingCart", function() {
        //     //layout.renderChild(new ShoppingCartView());
        //     var shoppingCartView = new ShoppingCartView();
        //     shoppingCartView.model.getCartItems();
        //
        //     //AppView.setCurrentView(ShoppingCartView);
        //     //ShoppingCartView.render();
        //
        // });

        router.on("route:viewCheckout", function(viewType) {
            var checkoutView = new CheckoutView();
            AppView.setCurrentView(checkoutView);
            breadCrumbs = [];
            breadCrumbs.push({
                "name": "Checkout",
                "href": "#checkout"
            });
            setTitle("Checkout", "");
            updateBreadCrumbs();
            toggleBackButton();
            showLoadingIndicator();
            checkoutView.model.getCartItems();
        });
        router.on("route:viewIntransit", function(viewType) {
            var intransitView = new IntransitView();
            breadCrumbs.push({
                "name": "In-Transit Inventory",
                "href": "#intransit"
            });
            setTitle("In-Transit Inventory", "");
            updateBreadCrumbs();
            toggleBackButton();
            var temp = JSON.parse(localStorage.getItem("currentIntransit"));
            var datainput = {
                "CIFA_ITEM_NUMBER": temp.CIFA_ITEM_NUMBER,
                "ORG_CODE": temp.ORG_CODE
            };
            showLoadingIndicator();
            intransitView.model.inTransitRequest(datainput);

        });
        router.on("route:ViewOutstandingSalesOrder", function(viewType) {
            var outstandingsalesView = new OutstandingSalesView();
            AppView.setCurrentView(outstandingsalesView);
            outstandingsalesView.render();
            breadCrumbs = [];
            breadCrumbs.push({
                "name": "Outstanding Sales Orders",
                "href": "#outstandingsalesorders"
            });
            setTitle("In-Transit Inventory", "");
            updateBreadCrumbs();
            setTitle(globalize.outstandingSales);
            $('.navbar-nav li').removeClass('active');
        });

        router.on("route:viewBUADmin", function(viewType) {
            var buadminView = new BUAdministrationView();
            AppView.setCurrentView(buadminView);
            buadminView.render();
            breadCrumbs.push({
                "name": "BU Administration",
                "href": "#buadmin"
            });
            setTitle("BU Admin", "");
            updateBreadCrumbs();
            setTitle(globalize.buadminCaps);
            $('.navbar-nav li').removeClass('active');
        });
        router.on("route:viewCatalogImages", function(viewType) {
            var catalogimgView = new CatalogImagesView();
            breadCrumbs = [];
            breadCrumbs.push({
                "name": "Catalog Image Upload",
                "href": "#catalogimages"
            });
            breadCrumbs.push({
                "name": "Preview Image",
                "href": "#"
            });
            setTitle("Catalog Images", "");
            updateBreadCrumbs();
            $('.navbar-nav li').removeClass('active');
        });
        router.on("route:viewAdministration", function(viewType) {
            var administrationView = new AdministrationView();
            AppView.setCurrentView(administrationView);
            administrationView.render();
            breadCrumbs = [];
            breadCrumbs.push({
                "name": "Administration",
                "href": "#administration"
            });

            setTitle("Administration", "");
            updateBreadCrumbs();
            $('.navbar-nav li').removeClass('active');
        });

        router.on("route:viewAddNTUserName", function() {

            if (!_.findWhere(breadCrumbs, { name: 'Add User' })) {
                breadCrumbs.push({ href: '#', name: 'Add User' });
            }
            new AdminAddNTUserView();
            setTitle("Add User", "");
            updateBreadCrumbs();
            showHeaderButtons(false, true, "Reset", "Add");
            updateBreadCrumbs();
            showBackButton();
        });

        router.on("route:viewErrorPage", function() {
            var errorView = new ErrorView();
            AppView.setCurrentView(errorView);
            errorView.render();
            setTitle("Error!", "");
            $(".navbar a").removeClass('active');
        });
        router.on("route:viewAnnouncement", function(viewType) {
            var data = JSON.parse(sessionStorage.getItem(getUsername() + "responsibilities"));
            if (data === null) {
                data = "";
            }
            globalize.user = "normal";
            if (typeof data.EXC_DB_FETCH_USER_RESPOutput != "undefined") {
                var list = data.EXC_DB_FETCH_USER_RESPOutput;
                for (var i = 0; i < list.length; i++) {
                    //set user as normal
                    if (list[i].FUNCTION_ID == "13") {
                        globalize.user = "regional"; //must change after develpoemt
                        for (var j = 0; j < list.length; j++) {
                            if (list[j].FUNCTION_ID == "1") {
                                globalize.user = "admin";
                                break;
                            }
                        }
                    }
                }
                console.log(globalize.user);

            }
            var announcementView = new AnnouncementView({ userType: globalize.user, view: viewType });
            breadCrumbs = [];
            if (viewType === "manage") {
                breadCrumbs.push({
                    "name": "Notifications",
                    "href": "#announcement?home"
                }, {
                    "name": "Manage Notifications",
                    "href": "#announcement?manage"
                });
            } else {
                breadCrumbs.push({
                    "name": "Notifications",
                    "href": "#announcement?home"
                }, {
                    "name": "View Notifications",
                    "href": "#announcement?home"
                });
            }

            setTitle("Notifications", "");
            updateBreadCrumbs();
            $('.navbar-nav li').removeClass('active');
        });



        offlineDB.initDB();
        console.log("initializing the backbone history");
        Backbone.history.start();

        return AppRouter;
    }
    return initialize();
});