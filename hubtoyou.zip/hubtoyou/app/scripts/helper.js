var breadCrumbs = [];
var globalView; //Set view as global when having internal views
var previousView; //used in reports and requisitions for reusing the acknowdege and feedback
var globalPreviousView //to keep the previous view before setting current view



var IDLE_TIMEOUT = 900; //seconds
var _idleSecondsCounter = 0;
document.onclick = function() {
    _idleSecondsCounter = 0;
};
document.onmousemove = function() {
    _idleSecondsCounter = 0;
};
document.onkeypress = function() {
    _idleSecondsCounter = 0;
};
if (!isPhoneGap()) {
    window.setInterval(CheckIdleTime, 1000);
}



function checkResponsibilityAccess(id) {
    var data = JSON.parse(sessionStorage.getItem("responsibilities"));
    var check = false;
    if (data !== null && data.EXC_DB_FETCH_USER_RESPOutput !== undefined) {
        data.EXC_DB_FETCH_USER_RESPOutput.forEach(function(responsibility) {
            if (id === responsibility.FUNCTION_ID) {
                check = true;
            }
        });
    }
    return check;
}


function enableItemsForResponsibility() {
    var usr = sessionStorage.getItem(getUsername() + "responsibilities");
    if (usr == null) return;
    if (!IsJsonString(usr)) return;
    var data = JSON.parse(usr);
    if (data === null) {
        return;
    }
    if (data.EXC_DB_FETCH_USER_RESPOutput !== undefined) {
        data.EXC_DB_FETCH_USER_RESPOutput.forEach(function(responsibility) {
            USER_FUNCTIONS.push(responsibility.FUNCTION_ID);
            switch (responsibility.FUNCTION_ID) {
                case 1:
                    $(".menu_admin").removeClass("hidden");
                    break; //Administration
                case 2:
                    $(".menu_upload").removeClass("hidden");
                    break; //Catalog Image Upload
                case 3:
                    break;
                case 4:
                    break;
                case 5:
                    break;
                case 6:
                    $(".menu_buadmin").removeClass("hidden");
                    break; //BU Administration
                case 7:
                    break; //Technician Acknowledgement
                case 8:
                    break; //Technician Feedback
                case 9:
                    break;
                case 10:
                    break;
                case 11:
                    break;
                case 12:
                    break;
                case 13:
                    //$(".menu_announcement").removeClass("hidden");
                    break;
                case 14:
                    $(".menu_outsales").removeClass("hidden");
                    break; //Outstanding Sales
            }
        });
    }
}

function checkAccess(FUNCTION_ID) {
    var usr = sessionStorage.getItem(getUsername() + "responsibilities");
    if (usr == null) return;
    if (!IsJsonString(usr)) return;
    var data = JSON.parse(usr);
    if (data === null) {
        return;
    }
    if (data.EXC_DB_FETCH_USER_RESPOutput !== undefined) {
        data.EXC_DB_FETCH_USER_RESPOutput.forEach(function(responsibility) {
            USER_FUNCTIONS.push(responsibility.FUNCTION_ID);
            switch (responsibility.FUNCTION_ID) {
                case 1:
                    $(".menu_admin").removeClass("hidden");
                    break; //Administration
                case 2:
                    $(".menu_upload").removeClass("hidden");
                    break; //Catalog Image Upload
                case 3:
                    break;
                case 4:
                    break;
                case 5:
                    break;
                case 6:
                    $(".menu_buadmin").removeClass("hidden");
                    break; //BU Administration
                case 7:
                    break; //Technician Acknowledgement
                case 8:
                    break; //Technician Feedback
                case 9:
                    break;
                case 10:
                    break;
                case 11:
                    break;
                case 12:
                    break;
                case 13:
                    $(".menu_announcement").removeClass("hidden");
                    break;
                case 14:
                    $(".menu_outsales").removeClass("hidden");
                    break; //Outstanding Sales
            }
        });
    }
}





function CheckIdleTime() {
    _idleSecondsCounter++;
    var oPanel = document.getElementById("SecondsUntilExpire");
    if (oPanel && (_idleSecondsCounter >= 120)) {
        $('#timerContainer').show();
        oPanel.innerHTML = (IDLE_TIMEOUT - _idleSecondsCounter) + "";
    } else {
        $('#timerContainer').hide();
    }
    if (_idleSecondsCounter >= IDLE_TIMEOUT) {
        alert("Session Expired!");
        logout();
    }
}

function logout() {
    window.location.replace('#logout');
    window.location.reload();
}

function showLoadingIndicator() {
    $('#spinner_canvas').fadeIn({
        duration: 100
    });
    $('body').addClass('masked');
}

function hideLoadingIndicator() {
    $('#spinner_canvas').fadeOut({
        duration: 100
    });
    $('body').removeClass('masked').delay(500);
}

// function add() {
//     var db;
//     var request = db.transaction(["favorites"], "readwrite")
//         .objectStore("favorites")
//         .add({ id: "01", name: "prasad", age: 24, email: "prasad@tutorialspoint.com" });

//     request.onsuccess = function(event) {
//         alert("data has been added to your database.");
//     };

//     request.onerror = function(event) {
//         alert("Unable to add data\r\nRecord already exist in your database! ");
//     }
// }
/*********************/

function updateBreadCrumbs(keepLastLink) {
    $("#breadcrumb_list li").not(':first').remove();
    breadCrumbs.forEach(function(item) {
        $("#breadcrumb_list").append('<li><a href=' + item.href + '>' + item.name + '</a></li>');
    });
    if (!keepLastLink) {
        $("#breadcrumb_list li:last>a").removeAttr("href");
    }
}
/**
 * Determine whether the file loaded from PhoneGap or not
 */

window.mobileAndTabletcheck = function() {
    var check = false;
    (function(a) { if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4))) check = true; })(navigator.userAgent || navigator.vendor || window.opera);
    return check;
};


function fixEmpty(value) {
    if (value === null || value === "") {
        return "&nbsp;";
    } else {
        return value;
    }
}

function IsJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}

function getUsername() {
    if (!isOnline) {
        var userdata = sessionStorage.getItem("_id");
        var user = null;
        if (userdata && IsJsonString(userdata)) {
            user = JSON.parse(userdata).sub
        }
        return sessionStorage.getItem("offlineUser") || user;
    }
    if (sessionStorage.getItem("_id") === null) {
        //location.href = "#logout";
        return "";
    } else {
        var userdata = JSON.parse(sessionStorage.getItem("_id"));
        return userdata.sub;
    }
}



function toUTCDate(date) {
    var tempDate = new Date(date);
    var utcDate = new Date(tempDate.getUTCFullYear(), tempDate.getUTCMonth(), tempDate.getUTCDate());
    return utcDate;
}

function DateFormatter(date) {
    if (date === null || date === "") {
        return "&nbsp;";
    }
    var tempDate = new Date(date);
    var displayDate = tempDate.getMonth() + 1 + "/" + tempDate.getDate() + "/" + tempDate.getFullYear();
    return displayDate;
}

function DateFormatterHyphen(date) {
    var tempDate = new Date(date);
    var month = tempDate.getMonth() + 1;
    var displayDate = tempDate.getFullYear() + "-" + month + "-" + tempDate.getDate();
    return displayDate;
}

function GlobalTimeZone(date) {
    if (date === "") {
        return "";
    }
    if (date.match("T") === null) {
        date = date + "T00:00:00";
    }
    var changedDate
    if (date.match("T") != null) {
        date = date.replace(/-/g, '\/').replace(/T.+/, ''); //This will fix previous day issue
        var tempDate = new Date(date);
        var month = tempDate.getMonth() + 1;
        var displayDate = tempDate.getFullYear() + "-" + month + "-" + tempDate.getDate();
    } else {
        var sample = date.split("-");
        changedDate = sample[1] + "," + sample[2] + "," + sample[0];
        var tempDate = new Date(sample[0], sample[1], sample[2]);
        var month = tempDate.getMonth() + 1;
        var displayDate = tempDate.getFullYear() + "-" + month + "-" + tempDate.getDate();
    }

    return displayDate;

}

function updateBreadcrumbsToParent() {
    var len = breadCrumbs.length;
    breadCrumbs.splice(len - 1, 1);
    updateBreadCrumbs();
}

function setTitle(title, icon) {
    $('#mb_title').html(title);
    $('#mb_icon').removeClass().addClass(icon)
}

function isPhoneGap() {
    var phoneGap = (window.cordova || window.PhoneGap || window.phonegap) &&
        /^file:\/{3}[^\/]/i.test(window.location.href) &&
        /ios|iphone|ipod|ipad|android/i.test(navigator.userAgent)
    if (phoneGap) {
        return true
    } else {
        return false;
    }
}

function hideEmpty(value) {
    return (value == "" || value == null || value == undefined) ? "hidden" : "";
}

function isValid(value) {
    if (value === undefined || value === "" || value === null) {
        return false;
    }
    return true;
}

function popupModalMsg(msg, type, callback) {
    if (type == "success") {
        $('.statusMsgContainer').addClass('message-success');
    } else if (type == "error") {
        $('.statusMsgContainer').addClass('message-error');
    }
    $('.statusMsgContainer').html(msg);
    $('#myModal').modal();
    $('.close-button').off();
    $('.close-button').on('click', function() {
        $('.statusMsgContainer').removeClass('message-success');
        $('.statusMsgContainer').removeClass('message-error');
        $('.statusMsgContainer').empty();
        if (callback) {
            callback();
        }
    });
}

function popupModalTermsCond() {
    var msg = globalize.termsAndConditions;
    var type = "";
    if (type == "success") {
        $('.statusMsgContainer').addClass('message-success');
    } else if (type == "error") {
        $('.statusMsgContainer').addClass('message-error');
    }
    $('.statusMsgContainer').html(msg);
    $('#myModal').modal();
    $('.close-button').off();
    $('.close-button').on('click', function() {
        $('.statusMsgContainer').removeClass('message-success');
        $('.statusMsgContainer').removeClass('message-error');
        $('.statusMsgContainer').empty();
    });
}

/*** Show/Hide header buttons ***/
function showHeaderButtons(left, right, leftText, rightText) {
    if (left) {
        $('#mb_button_left').html(leftText).show();
    }
    if (right) {
        $('#mb_button_right').html(rightText).show();
    }
}

function enableSaveBtn() {
    $('#mb_button_right').removeClass('button-disable-opacity');
}

function disableSaveBtn() {
    $('#mb_button_right').addClass('button-disable-opacity');
}

function enableDone() {
    $('#mb_button_right').removeClass('button-disable-opacity');
}

function disableDone() {
    $('#mb_button_right').addClass('button-disable-opacity');
}

function hideHeaderButtons() {
    $('#mb_button_left').hide();
    $('#mb_button_right').hide();
}

function setHamburgerIcon() {
    $('#hamburger_menu').removeClass('icon-backbtn');
}

function toggleBackButton() {
    $('#hamburger_menu').toggleClass('icon-backbtn');
}

function showBackButton() {
    $('#hamburger_menu').addClass('icon-backbtn');
}

function removeBackButton() {
    $('#hamburger_menu').removeClass('icon-backbtn');
}

function modalImage(src) {
    $('#large-img-src').attr("src", src);
    $('#largeIMGModal').modal();
}

function updateCartCount() {
    var count = sessionStorage.getItem('cartItemsCount');
    if (count > 0) {
        $('.items-count').css('display', 'inline-block');
        $('.items-count').html(count);
    } else {
        $('.items-count').css('display', 'none');
    }

}

function sortByKey(array, key) {
    return array.sort(function(a, b) {
        var x = a[key];
        var y = b[key];
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    });
}


function saveCartDetails(keyparam, updatevalue, lineid, deleteflag) {
    deleteflag = deleteflag || false;
    lineid = lineid || 0;
    keyparam = keyparam || "";
    updatevalue = updatevalue || "";
    var CartDetails = JSON.parse(sessionStorage.getItem("saveCartDetails"));
    if (CartDetails.length > 0) { // update one line item attribute value
        if (isValid(keyparam)) {

            if (lineid > 0) {
                CartDetails.forEach(function(item, index) {
                    if (lineid == item.LINE_ID) {
                        item[keyparam] = updatevalue;
                    }
                });
            }

            if (lineid == 0) { // update all line item attribute value
                CartDetails.forEach(function(item, index) {
                    item[keyparam] = updatevalue;
                });
            }

        } else {
            // delete line item
            if (deleteflag == true) {
                CartDetails.forEach(function(item, index) {
                    if (lineid == item.LINE_ID) {
                        CartDetails.splice(index, 1);
                    }
                });

            }
        }
        sessionStorage.setItem("saveCartDetails", JSON.stringify(CartDetails));
        //console.log("saveCartDetails...", JSON.stringify(CartDetails));
    }
}

function getProfilePicture() {
    var username = getUsername();
    api_key = "6F1F6C083334CF8435B9C022820D3A93"
    $.ajax({
        type: "GET",
        url: "https://esl-stg.cable.comcast.com:11443/api/v1/person/getProfilePicture/?domain=CABLE&UserId=" + username,
        headers: {
            "API_KEY": api_key,
        },
        success: function(response) {
            //alert('Success!');
            //console.log(response)
        }
    });
}

function isObject(obj) {
    if (typeof obj === 'object') {
        return true;
    } else {
        return false;
    }
}


function setUserDetails() {
    if (sessionStorage.getItem("_id") === null) {
        return;
    } else {
        var t = sessionStorage.getItem("_id");
        if (!IsJsonString(t)) return;
        var userdata = JSON.parse(t);
        $('#span_user_id').html(userdata.COMCAST_FNAME + " " + userdata.COMCAST_LNAME);
        $('#side_menu_fname').html(userdata.COMCAST_FNAME + " " + userdata.COMCAST_LNAME);
        $('#side_menu_empid').html(userdata.COMCAST_USERNAME);
        $('#side_menu_userid').html(userdata.COMCAST_USERNAME);
    }
}


/**********Slide Navigation********* */


// function openNav() {
//     $("#mySidenav").addClass("menu-open");
//     //document.getElementById("mySidenav").style.width = "250px";
//     //$(".fixed-component").css({ "left": "250px", "right": "-250px" });
//     //$('#page_mask').fadeIn();
//     //document.getElementById("layout").style.left = "250px";
//     document.body.style.overflow = "hidden";
// }


// function closeNav() {
//     $("#mySidenav").addClass("menu-close");
//     //document.getElementById("mySidenav").style.width = "0";
//     //$(".fixed-component").css({ "left": "0", "right": "0" });
//     //document.getElementById("layout").style.left = "0";
//     $('#page_mask').fadeOut();
//     document.body.style.overflow = "scroll";
// }

$('#menu_mask').click(function() {
    closeNav();
});

$('#menu_items a').click(function(event) {
    $(event.currentTarget).parent().addClass("active").siblings().removeClass("active");
    closeNav();
});

function openNav(element) {
    $('#menu_mask').fadeIn();
    $('#page-container').addClass('fixed-fix');
    $('.page-content').addClass('menu-visible');
    $('.slide-menu').addClass('menu-visible');
    transitionEnd = 'transitionend webkitTransitionEnd otransitionend MSTransitionEnd';
    $('#page-container').on(transitionEnd, function() {
        $('#page-container').addClass('fixed-fix');
        $('#page-container').off(transitionEnd);
    });
}

function closeNav(element) {
    $('.slide-menu').removeClass('menu-visible');
    $('.page-content').removeClass('menu-visible');
    transitionEnd = 'transitionend webkitTransitionEnd otransitionend MSTransitionEnd';
    $('#page-container').on(transitionEnd, function() {
        $('#menu_mask').fadeOut();
        $('#page-container').removeClass('fixed-fix');
        $('#page-container').off(transitionEnd);
    });
}


//function showInlineMessage(type, message, autoHide, title) {
function modalMsg(message, type, title, callback, autoHide) {
    autoHide = autoHide || true;
    //title = title || "";
    callback = callback || "";
    switch (type) {
        case "error":
            $("#inline_error").removeClass().addClass("alert-danger");
            $('#inline_error .error-title').html("Error!");
            $('#inline_error .error-message').html("Something went wrong. Please try again.");
            break;
        case "success":
            $("#inline_error").removeClass().addClass("alert-success");
            $('#inline_error .error-title').html("Success!");
            $('#inline_error .error-message').html("Task completed successfully.");
            break;
        case "warning":
            $("#inline_error").removeClass().addClass("alert-warning");
            break;
        case "info":
            $("#inline_error").removeClass().addClass("alert-info");
            $('#inline_error .error-title').html("");
            break;
    }
    if (title) {
        $('#inline_error .error-title').html(title);
    } else if (title === "") {
        $('#inline_error .error-title').html(title);
    }
    if (message) {
        $('#inline_error .error-message').html(message);
    }
    $("#inline_error").addClass("alert alert-dismissible");
    $("#error_container").slideDown();
    if (autoHide) {
        setTimeout(function() {
            $("#error_container").slideUp();
        }, 5000);
    }

    if (callback) {
        callback();
    }
}
$("#error_container .close").on("click", function() {
    $("#error_container").slideUp();
});

// $(document).keyup(function(e) {
//     if (e.keyCode == 27) { // escape key maps to keycode `27`
//         modalMsg("You have closed the progress indicator by pressing escape button. The app may behave abnormally.", "warning")
//         hideLoadingIndicator();
//     }
// });

function truncateText(text, maxLength) {
    maxLength = maxLength || 25;
    var ret = text;
    var tooltiptext = '<span data-toggle="tooltip" data-placement="top" title="' + text + '">&nbsp;<span class="txt-blue cur-pointer">>></span></span>'
    if (ret.length > maxLength) {
        ret = ret.substr(0, maxLength - 3) + "..." + tooltiptext;
    }
    return ret;
}

function fetchHelpLink() {
    closeNav();
    globalize.FooterViewObject.fetchHelpLink();
}